<?php include("Connection.php");

$MousePricesResult = mysqli_query($_SESSION["conn"], "SELECT * FROM product_catalogue WHERE Product_Category = 'Mouse';");
?>
<!doctype html>
<html lang="en" class="js">

<head>
    
    <meta charset="UTF-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport"
        content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=0" />
    <meta name='HandheldFriendly' content='True'>
    <meta name='MobileOptimized' content='375'>
    <meta http-equiv="cleartype" content="on">
    <meta name="theme-color" content="#e60012">
    <link rel="canonical" href="https://redragonzone.pk/collections/gaming-mouse-price-in-pakistan" />

    <title>Redragon Gaming Mouse Price - Authorized Pakistan Reseller</title>
    <meta name="description"
        content="Buy Redragon Gaming Mouse in Pakistan. Latest &amp; wide range of gaming mouse at best prices with official support. Nationwide shipping with cash on delivery.">

    <meta property="og:site_name" content="RedragonZone.PK">
    <meta property="og:url" content="https://redragonzone.pk/collections/gaming-mouse-price-in-pakistan">
    <meta property="og:title" content="MOUSE">
    <meta property="og:type" content="product.group">
    <meta property="og:description"
        content="Buy Redragon Gaming Mouse in Pakistan. Latest &amp; wide range of gaming mouse at best prices with official support. Nationwide shipping with cash on delivery.">

    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="MOUSE">
    <meta name="twitter:description"
        content="Buy Redragon Gaming Mouse in Pakistan. Latest &amp; wide range of gaming mouse at best prices with official support. Nationwide shipping with cash on delivery.">

    <link rel="canonical" href="https://redragonzone.pk/collections/gaming-mouse-price-in-pakistan" />
    <link rel="preconnect dns-prefetch" href="https://cdn.shopify.com">
    <link rel="preconnect dns-prefetch" href="https://v.shopify.com">
    <link rel="preconnect dns-prefetch" href="https://cdn.shopifycloud.com">
    <link rel="preload" href="//redragonzone.pk/cdn/shop/t/5/assets/styles.scss.css?v=124980048740926497851703348189"
        as="style">
    <link rel="preload" href="//redragonzone.pk/cdn/shop/t/5/assets/themes.scss.css?v=58698413482323688401703348188"
        as="style">
    <link rel="preload" href="//redragonzone.pk/cdn/shop/t/5/assets/global.scss.css?v=125076772181967553861703348189"
        as="style">
    <link rel="preload" href="//redragonzone.pk/cdn/shop/t/5/assets/vendor.css?v=87675270813913945401581608572"
        as="style">
    <link rel="preload" href="//redragonzone.pk/cdn/shop/t/5/assets/arenafont.css?v=75023525835272796541703348189"
        as="style">
    <!-- header-css-file  ================================================== -->
    <link href="//redragonzone.pk/cdn/shop/t/5/assets/arenafont.css?v=75023525835272796541703348189" rel="stylesheet"
        type="text/css" media="all">
    <link href="//redragonzone.pk/cdn/shop/t/5/assets/vendor.css?v=87675270813913945401581608572" rel="stylesheet"
        type="text/css" media="all">
    <link href="//redragonzone.pk/cdn/shop/t/5/assets/styles.scss.css?v=124980048740926497851703348189" rel="stylesheet"
        type="text/css" media="all">
    <link href="//redragonzone.pk/cdn/shop/t/5/assets/themes.scss.css?v=58698413482323688401703348188" rel="stylesheet"
        type="text/css" media="all">
    <link href="//redragonzone.pk/cdn/shop/t/5/assets/global.scss.css?v=125076772181967553861703348189" rel="stylesheet"
        type="text/css" media="all">
    <link href="https://fonts.googleapis.com/css?family=Caveat:300,400,500,600,700&display=swap" rel='stylesheet'
        type='text/css'>

    <link href="//redragonzone.pk/cdn/shop/t/5/assets/bc_wl_cp_style.scss.css?v=172879242641943902421581608571"
        rel="stylesheet" type="text/css" media="all" />
    <!-------------------------------------------------------->
    <script crossorigin="anonymous"
        src="//redragonzone.pk/cdn/shop/t/5/assets/lazysizes.min.js?v=68594089956960822201581608511" async></script>
    <!-------------------------------------------------------->

    <meta name="google-site-verification" content="EWwwu38a_jv79ixFO-aQvD5pgJmEfotJ5jJy_vcPpQ4">
    <meta id="shopify-digital-wallet" name="shopify-digital-wallet" content="/33233961099/digital_wallets/dialog">
    <link rel="alternate" type="application/atom+xml" title="Feed"
        href="/collections/gaming-mouse-price-in-pakistan.atom" />
    <link rel="next" href="/collections/gaming-mouse-price-in-pakistan?page=2">
    <link rel="alternate" type="application/json+oembed"
        href="https://redragonzone.pk/collections/gaming-mouse-price-in-pakistan.oembed">

    <!-- END app app block -->
    <meta property="og:image"
        content="https://cdn.shopify.com/s/files/1/0332/3396/1099/files/redragon-pakistan-theme_63345c37-7358-4be7-83ce-fc84683d1de1.jpg?v=1600006452" />
    <meta property="og:image:secure_url"
        content="https://cdn.shopify.com/s/files/1/0332/3396/1099/files/redragon-pakistan-theme_63345c37-7358-4be7-83ce-fc84683d1de1.jpg?v=1600006452" />
    <meta property="og:image:width" content="3840" />
    <meta property="og:image:height" content="2160" />
    <link href="https://monorail-edge.shopifysvc.com" rel="dns-prefetch">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="icon" href="picc/redragon.png" type="image/x-icon">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="smile.css">
</head>

<body data-rtl="false" class="templateCollection mobile-bar-outside category-mode-false cata-grid-4 lazy-loading-img ">
    <header>
        <div class="top-bar-list  ">

            <p> DUE TO LARGE NUMBER OF ORDERS, PLEASE EXPECT 1 TO 2 DAYS DELAY IN DELIVERY</p>

        </div>


        <div class="d-flex justify-content-between top-bar-right">
            <div class="d-flex hello">
                <div>
                    <a href="https://redragonzone.pk/"> <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20"
                            fill="currentColor" class="bi bi-facebook" viewBox="0 0 16 16">
                            <path
                                d="M16 8.049c0-4.446-3.582-8.05-8-8.05C3.58 0-.002 3.603-.002 8.05c0 4.017 2.926 7.347 6.75 7.951v-5.625h-2.03V8.05H6.75V6.275c0-2.017 1.195-3.131 3.022-3.131.876 0 1.791.157 1.791.157v1.98h-1.009c-.993 0-1.303.621-1.303 1.258v1.51h2.218l-.354 2.326H9.25V16c3.824-.604 6.75-3.934 6.75-7.951">
                            </path>
                        </svg></a>
                </div>

                <div>
                    <a href="https://redragonzone.pk/"> <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20"
                            fill="currentColor" class="bi bi-twitter" viewBox="0 0 16 16">
                            <path
                                d="M5.026 15c6.038 0 9.341-5.003 9.341-9.334 0-.14 0-.282-.006-.422A6.685 6.685 0 0 0 16 3.542a6.658 6.658 0 0 1-1.889.518 3.301 3.301 0 0 0 1.447-1.817 6.533 6.533 0 0 1-2.087.793A3.286 3.286 0 0 0 7.875 6.03a9.325 9.325 0 0 1-6.767-3.429 3.289 3.289 0 0 0 1.018 4.382A3.323 3.323 0 0 1 .64 6.575v.045a3.288 3.288 0 0 0 2.632 3.218 3.203 3.203 0 0 1-.865.115 3.23 3.23 0 0 1-.614-.057 3.283 3.283 0 0 0 3.067 2.277A6.588 6.588 0 0 1 .78 13.58a6.32 6.32 0 0 1-.78-.045A9.344 9.344 0 0 0 5.026 15">
                            </path>
                        </svg></a>
                </div>

                <div>
                    <a href="https://redragonzone.pk/"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20"
                            fill="currentColor" class="bi bi-pinterest" viewBox="0 0 16 16">
                            <path
                                d="M8 0a8 8 0 0 0-2.915 15.452c-.07-.633-.134-1.606.027-2.297.146-.625.938-3.977.938-3.977s-.239-.479-.239-1.187c0-1.113.645-1.943 1.448-1.943.682 0 1.012.512 1.012 1.127 0 .686-.437 1.712-.663 2.663-.188.796.4 1.446 1.185 1.446 1.422 0 2.515-1.5 2.515-3.664 0-1.915-1.377-3.254-3.342-3.254-2.276 0-3.612 1.707-3.612 3.471 0 .688.265 1.425.595 1.826a.24.24 0 0 1 .056.23c-.061.252-.196.796-.222.907-.035.146-.116.177-.268.107-1-.465-1.624-1.926-1.624-3.1 0-2.523 1.834-4.84 5.286-4.84 2.775 0 4.932 1.977 4.932 4.62 0 2.757-1.739 4.976-4.151 4.976-.811 0-1.573-.421-1.834-.919l-.498 1.902c-.181.695-.669 1.566-.995 2.097A8 8 0 1 0 8 0">
                            </path>
                        </svg></a>
                </div>
                <div>
                    <a href="https://redragonzone.pk/"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20"
                            fill="currentColor" class="bi bi-instagram" viewBox="0 0 16 16">
                            <path
                                d="M8 0C5.829 0 5.556.01 4.703.048 3.85.088 3.269.222 2.76.42a3.917 3.917 0 0 0-1.417.923A3.927 3.927 0 0 0 .42 2.76C.222 3.268.087 3.85.048 4.7.01 5.555 0 5.827 0 8.001c0 2.172.01 2.444.048 3.297.04.852.174 1.433.372 1.942.205.526.478.972.923 1.417.444.445.89.719 1.416.923.51.198 1.09.333 1.942.372C5.555 15.99 5.827 16 8 16s2.444-.01 3.298-.048c.851-.04 1.434-.174 1.943-.372a3.916 3.916 0 0 0 1.416-.923c.445-.445.718-.891.923-1.417.197-.509.332-1.09.372-1.942C15.99 10.445 16 10.173 16 8s-.01-2.445-.048-3.299c-.04-.851-.175-1.433-.372-1.941a3.926 3.926 0 0 0-.923-1.417A3.911 3.911 0 0 0 13.24.42c-.51-.198-1.092-.333-1.943-.372C10.443.01 10.172 0 7.998 0h.003zm-.717 1.442h.718c2.136 0 2.389.007 3.232.046.78.035 1.204.166 1.486.275.373.145.64.319.92.599.28.28.453.546.598.92.11.281.24.705.275 1.485.039.843.047 1.096.047 3.231s-.008 2.389-.047 3.232c-.035.78-.166 1.203-.275 1.485a2.47 2.47 0 0 1-.599.919c-.28.28-.546.453-.92.598-.28.11-.704.24-1.485.276-.843.038-1.096.047-3.232.047s-2.39-.009-3.233-.047c-.78-.036-1.203-.166-1.485-.276a2.478 2.478 0 0 1-.92-.598 2.48 2.48 0 0 1-.6-.92c-.109-.281-.24-.705-.275-1.485-.038-.843-.046-1.096-.046-3.233 0-2.136.008-2.388.046-3.231.036-.78.166-1.204.276-1.486.145-.373.319-.64.599-.92.28-.28.546-.453.92-.598.282-.11.705-.24 1.485-.276.738-.034 1.024-.044 2.515-.045v.002zm4.988 1.328a.96.96 0 1 0 0 1.92.96.96 0 0 0 0-1.92zm-4.27 1.122a4.109 4.109 0 1 0 0 8.217 4.109 4.109 0 0 0 0-8.217zm0 1.441a2.667 2.667 0 1 1 0 5.334 2.667 2.667 0 0 1 0-5.334">
                            </path>
                        </svg></a>
                </div>


            </div>

            <div>
                <span>Need help?</span>
                <a href="mailto:info@redragonzone.pk">info@redragonzone.pk</a>
            </div>

        </div>

        <div class="d-flex justify-content-between  align-items-center box1 ">
            <div><img src="picc/redragon.png" width="130px" height="90px" alt=""></div>

            <div>
      <a href="cart.php"> <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-cart"
        viewBox="0 0 16 16">
        <path
          d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .491.592l-1.5 8A.5.5 0 0 1 13 12H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5M3.102 4l1.313 7h8.17l1.313-7H3.102zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4m7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4m-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2m7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2" />
      </svg></a>
  
    </div>
        </div>


        <div>
            <div class="d-flex justify-content-between box2 p-3">
                <div>
                    <p><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                            class="bi bi-truck" viewBox="0 0 16 16">
                            <path
                                d="M0 3.5A1.5 1.5 0 0 1 1.5 2h9A1.5 1.5 0 0 1 12 3.5V5h1.02a1.5 1.5 0 0 1 1.17.563l1.481 1.85a1.5 1.5 0 0 1 .329.938V10.5a1.5 1.5 0 0 1-1.5 1.5H14a2 2 0 1 1-4 0H5a2 2 0 1 1-3.998-.085A1.5 1.5 0 0 1 0 10.5zm1.294 7.456A1.999 1.999 0 0 1 4.732 11h5.536a2.01 2.01 0 0 1 .732-.732V3.5a.5.5 0 0 0-.5-.5h-9a.5.5 0 0 0-.5.5v7a.5.5 0 0 0 .294.456M12 10a2 2 0 0 1 1.732 1h.768a.5.5 0 0 0 .5-.5V8.35a.5.5 0 0 0-.11-.312l-1.48-1.85A.5.5 0 0 0 13.02 6H12zm-9 1a1 1 0 1 0 0 2 1 1 0 0 0 0-2m9 0a1 1 0 1 0 0 2 1 1 0 0 0 0-2">
                            </path>
                        </svg>
                        NATIONWIDE SHIPPING</p>
                </div>

                <div>
                    <p> <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                            class="bi bi-box2" viewBox="0 0 16 16">
                            <path
                                d="M2.95.4a1 1 0 0 1 .8-.4h8.5a1 1 0 0 1 .8.4l2.85 3.8a.5.5 0 0 1 .1.3V15a1 1 0 0 1-1 1H1a1 1 0 0 1-1-1V4.5a.5.5 0 0 1 .1-.3L2.95.4ZM7.5 1H3.75L1.5 4h6zm1 0v3h6l-2.25-3zM15 5H1v10h14z">
                            </path>
                        </svg>
                        GENUINE,BOX PACKED PRODUCTS</p>
                </div>

                <div>
                    <p><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                            class="bi bi-shield-shaded" viewBox="0 0 16 16">
                            <path fill-rule="evenodd"
                                d="M8 14.933a.615.615 0 0 0 .1-.025c.076-.023.174-.061.294-.118.24-.113.547-.29.893-.533a10.726 10.726 0 0 0 2.287-2.233c1.527-1.997 2.807-5.031 2.253-9.188a.48.48 0 0 0-.328-.39c-.651-.213-1.75-.56-2.837-.855C9.552 1.29 8.531 1.067 8 1.067zM5.072.56C6.157.265 7.31 0 8 0s1.843.265 2.928.56c1.11.3 2.229.655 2.887.87a1.54 1.54 0 0 1 1.044 1.262c.596 4.477-.787 7.795-2.465 9.99a11.775 11.775 0 0 1-2.517 2.453 7.159 7.159 0 0 1-1.048.625c-.28.132-.581.24-.829.24s-.548-.108-.829-.24a7.158 7.158 0 0 1-1.048-.625 11.777 11.777 0 0 1-2.517-2.453C1.928 10.487.545 7.169 1.141 2.692A1.54 1.54 0 0 1 2.185 1.43 62.456 62.456 0 0 1 5.072.56z">
                            </path>
                        </svg>
                        COMPREHENSIVE BRAND SUPPORT</p>
                </div>
            </div>
        </div>
    </header>
    <img alt="splash-img-tpt" id="splash-img-tpt"
        style="pointer-events: none; position: absolute; top: 0; left: 0; width: 96vw; height: 96vh;"
        src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48c3ZnIHdpZHRoPSI5OTk5OXB4IiBoZWlnaHQ9Ijk5OTk5cHgiIHZpZXdCb3g9IjAgMCA5OTk5OSA5OTk5OSIgdmVyc2lvbj0iMS4xIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIj48ZyBzdHJva2U9Im5vbmUiIGZpbGw9Im5vbmUiIGZpbGwtb3BhY2l0eT0iMCI+PHJlY3QgeD0iMCIgeT0iMCIgd2lkdGg9Ijk5OTk5IiBoZWlnaHQ9Ijk5OTk5Ij48L3JlY3Q+IDwvZz4gPC9zdmc+">

    <div id="page-body" class="breadcrumb-color wide">
        <div id="body-content">
            <!-------------------------------main c-------------------------------------->
            <div class="main-content" id="main-content">
                <div class="wrap-breadcrumb bw-color ">
                    <div id="breadcrumb" class="breadcrumb-holder container">
                        <ul class="breadcrumb">
                            <li itemscope itemtype="http://data-vocabulary.org/Breadcrumb">
                                <a itemprop="url" href="/">
                                    <span itemprop="title" class="d-none">RedragonZone.PK</span>Home
                                </a>
                            </li>
                            <li itemscope itemtype="http://data-vocabulary.org/Breadcrumb" class="d-none">
                                <a href="/collections/gaming-mouse-price-in-pakistan" itemprop="url">
                                    <span itemprop="title">MOUSE</span>
                                </a>
                            </li>
                            <li class="active">MOUSE</li>
                        </ul>
                    </div>
                </div>
                <div class="page-cata active-sidebar" data-logic="false">
                    <div class="container">
                        <div class="row">
                            <div id="sidebar" class="left-column-container col-lg-3 col-md-12">
                                <div class="f-close d-lg-none" title="Close">
                                    <i class="demo-icon icon-close">
                                    </i>
                                </div>
                                <div class="sb-widget d-none d-lg-block">
                                    <div class="sb-menu">
                                        <h5 class="sb-title">SHOP</h5>
                                        <ul class="categories-menu">
                                            <li>
                                                <a href="combo.php">COMBO</a>
                                            </li>
                                            <li>
                                                <a href="headset.php">HEADSET</a>
                                            </li>
                                            <li>
                                                <a href="keyboard.php">KEYBOARD</a>
                                            </li>
                                            <li>
                                                <a href="mouse.php">MOUSE</a>
                                            </li>
                                            <li>
                                                <a href="mousepad.php">MOUSE PAD</a>
                                            </li>
                                            <li>
                                                <a href="headsetstand.php">HEADSET STAND</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="sb-widget d-none d-lg-block">
                                    <div class="sb-banner">
                                        <a href="/products/redragon-k530-rgb-draconic-gaming-keyboard-white">
                                            <span class="image-lazysize" style="position:relative;padding-top:100.0%;">
                                                <img class="img-lazy "
                                                    src="//redragonzone.pk/cdn/shop/files/redragon-k530-draconic-gaming-keyboard-redragonzone-pk-redragon-pakistan_330x.jpg?v=1691194943"
                                                    alt="redragon k530 draconic gaming keyboard at redragonzone.pk redragon pakistan" />
                                            </span>
                                        </a>
                                    </div>
                                </div>
                                <div class="sb-widget d-none d-lg-block">
                                    <div class="sb-banner">
                                        <a href="/products/redragon-k552-rgb-1-kumara-mechanical-gaming-keyboard">
                                            <span class="image-lazysize"
                                                style="position:relative;padding-top:73.33333333333334%;">
                                                <img class="img-lazy "
                                                    src="//redragonzone.pk/cdn/shop/files/redragon-k552-redragonzone-pk-redragon-pakistan-banner-mobile_330x.jpg?v=1691192420" />
                                            </span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="main-cata-page col-lg-9 col-md-12 col-sm-12 col-12">
                                <div class="block-banner subcollections-three-banners">
                                    <div class="row">
                                    </div>
                                </div>
                                <div class="cata-toolbar">
                                    <div class="group-toolbar">
                                        <div class="cata-title">
                                            <h1>MOUSE</h1>
                                        </div>
                                        <div class="grid-list">
                                            <span class="text">View</span>
                                        </div>
                                        <div class="sort-by bc-toggle">
                                            <div class="sort-by-inner">

                                                <label class="d-none d-md-block">Products</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
<!------------------------------------------p new---------------------------------------------------------------->
                                <div id="col-main">
                                    <div class="cata-product cp-grid">
                                        <div class="product-grid-item mode-view-item">
                                            <div class="product-wrapper effect-overlay ">
                                                <div class="product-head">
                                                    <div class="product-image">
                                                        <div class="featured-img product-ratio-auto">
                                                            <a
                                                                href="/collections/gaming-mouse-price-in-pakistan/products/redragon-m711-cobra-gaming-mouse">
                                                                <span class="image-lazysize">
                                                                    <noscript>
                                                                        <img class="img-lazy product-ratio-auto featured-image front"
                                                                            src="//redragonzone.pk/cdn/shop/products/Redragon_M711_COBRA_Gaming_Mouse-1_420x.png?v=1627383035"
                                                                            alt="Redragon M711 COBRA Gaming Mouse with 16.8 Million RGB, 10,000 DPI Adjustable, 7 Programmable Buttons - Redragon Pakistan" />
                                                                    </noscript>
                                                                    <img class="img-lazy product-ratio-auto featured-image front"
                                                                        src="//redragonzone.pk/cdn/shop/products/Redragon_M711_COBRA_Gaming_Mouse-1_420x.png?v=1627383035"
                                                                        alt="Redragon M711 COBRA Gaming Mouse with 16.8 Million RGB, 10,000 DPI Adjustable, 7 Programmable Buttons - Redragon Pakistan" />
                                                                </span>
                                                            </a>
                                                        </div>
                                                        
                                                    </div>
                                                    

                                                </div>

                                                <div class="product-content">
                                                    <div class="pc-inner">
                                                        <div class="list-v2-label">
                                                            
                                                        </div>
                                                        <div class="product-group-vendor-name">
                                                            <div class="product-vendor"><a
                                                                    href="/collections/vendors?q=REDRAGON"
                                                                    title="REDRAGON">REDRAGON</a></div>
                                                            <h5 class="product-name balance-false"><a
                                                                    href="mouse1.php">Redragon
                                                                    M711 COBRA Gaming Mouse with 16.8
                                                                    Million RGB, 10,000 DPI Adjustable, 7
                                                                    Programmable Buttons (Black)</a></h5>
                                                            <div class="product-review">
                                                                <span class="shopify-product-reviews-badge"
                                                                    data-id="4543057887371"></span>
                                                            </div>
                                                        </div>
                                                        <div class="product-price notranslate">
                                                            <span class="price">Rs. <?php $MouseRow = mysqli_fetch_assoc($MousePricesResult); echo $MouseRow['Price']; ?></span>
                                                        </div>
                                                        <div class="product-list-mode-content">
                                                            
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="product-list-mode-content-v2">
                                                    <div class="list-v2-inner">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="product-grid-item mode-view-item">
                                            <div class="product-wrapper effect-overlay ">

                                                <div class="product-head">
                                                    <div class="product-image">

                                                        <div class="featured-img product-ratio-auto">
                                                            <a
                                                                href="/collections/gaming-mouse-price-in-pakistan/products/redragon-m607-7200-dpi-rgb-gaming-mouse">
                                                                <span class="image-lazysize">
                                                                    <!-- noscript pattern -->
                                                                    <noscript>
                                                                        <img class="img-lazy product-ratio-auto featured-image front"
                                                                            src="//redragonzone.pk/cdn/shop/products/Redragon_M607_Griffin_7200_DPI_RGB_Gaming_Mouse-1_420x.png?v=1581533584"
                                                                            alt="Redragon M607 GRIFFIN RGB Black 7200 DPI Gaming Mouse - Redragon Pakistan" />
                                                                    </noscript>

                                                                    <img class="lazyload featured-image front img-lazy blur-up auto-crop-false"
                                                                        data-src="//redragonzone.pk/cdn/shop/products/Redragon_M607_Griffin_7200_DPI_RGB_Gaming_Mouse-1_{width}x.png?v=1581533584"
                                                                        data-widths="[180, 320, 540, 720, 1080, 1366, 1920, 2048] "
                                                                        data-aspectratio="1.0" data-sizes="auto"
                                                                        data-parent-fit="cover"
                                                                        alt="Redragon M607 GRIFFIN RGB Black 7200 DPI Gaming Mouse - Redragon Pakistan" />
                                                                </span>
                                                            </a>
                                                        </div>
                                                        
                                                    </div>
                                                    
                                                </div>
                                                <div class="product-content">
                                                    <div class="pc-inner">
                                                        <div class="list-v2-label">
                                                            
                                                        </div>
                                                        <div class="product-group-vendor-name">
                                                            <div class="product-vendor"><a
                                                                    href="/collections/vendors?q=REDRAGON"
                                                                    title="REDRAGON">REDRAGON</a></div>
                                                            <h5 class="product-name balance-false"><a
                                                                    href="mouse2.php">Redragon
                                                                    M607 GRIFFIN RGB Black 7200 DPI Gaming
                                                                    Mouse</a></h5>
                                                            <div class="product-review">
                                                                <span class="shopify-product-reviews-badge"
                                                                    data-id="4543003033739"></span>
                                                            </div>
                                                        </div>
                                                        <div class="product-price notranslate">
                                                            <span class="price">Rs. <?php $MouseRow = mysqli_fetch_assoc($MousePricesResult); echo $MouseRow['Price']; ?></span>
                                                        </div>
                                                        <div class="product-list-mode-content">
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="product-list-mode-content-v2">
                                                    <div class="list-v2-inner">
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="product-grid-item mode-view-item">
                                            <div class="product-wrapper effect-overlay ">
                                                <div class="product-head">
                                                    <div class="product-image">
                                                        <div class="featured-img product-ratio-auto">
                                                            <a
                                                                href="/collections/gaming-mouse-price-in-pakistan/products/redragon-centrophorus-m601-rgb-gaming-mouse">
                                                                <span class="image-lazysize">
                                                                    <!-- noscript pattern -->
                                                                    <noscript>
                                                                        <img class="img-lazy product-ratio-auto featured-image front"
                                                                            src="//redragonzone.pk/cdn/shop/products/M601RGB-1_450x450_dec37a64-a9f3-4fc9-9bda-05c0efbebc15_420x.jpg?v=1630830408"
                                                                            alt="Redragon M601 CENTROPHORUS RGB Gaming Mouse, 6 Programmable Buttons - Redragon Pakistan" />
                                                                    </noscript>

                                                                    <img class="lazyload featured-image front img-lazy blur-up auto-crop-false"
                                                                        data-src="//redragonzone.pk/cdn/shop/products/M601RGB-1_450x450_dec37a64-a9f3-4fc9-9bda-05c0efbebc15_{width}x.jpg?v=1630830408"
                                                                        data-widths="[180, 320, 540, 720, 1080, 1366, 1920, 2048] "
                                                                        data-aspectratio="1.0" data-sizes="auto"
                                                                        data-parent-fit="cover"
                                                                        alt="Redragon M601 CENTROPHORUS RGB Gaming Mouse, 6 Programmable Buttons - Redragon Pakistan" />
                                                                </span>
                                                            </a>
                                                        </div>
                                                        
                                                    </div>
                                                    

                                                </div>

                                                <div class="product-content">
                                                    <div class="pc-inner">


                                                        <div class="list-v2-label">
                                                            
                                                        </div>


                                                        <div class="product-group-vendor-name">
                                                            <div class="product-vendor"><a
                                                                    href="/collections/vendors?q=REDRAGON"
                                                                    title="REDRAGON">REDRAGON</a></div>
                                                            <h5 class="product-name balance-false"><a
                                                                    href="mouse3.php">Redragon
                                                                    M601 CENTROPHORUS RGB Gaming Mouse, 6
                                                                    Programmable Buttons</a></h5>

                                                            <div class="product-review">

                                                                <span class="shopify-product-reviews-badge"
                                                                    data-id="6911206916247"></span>

                                                            </div>

                                                        </div>






                                                        <div class="product-price notranslate">

                                                            <span class="price">Rs. <?php $MouseRow = mysqli_fetch_assoc($MousePricesResult); echo $MouseRow['Price']; ?></span>

                                                        </div>



                                                        <div class="product-list-mode-content">


                                                            



                                                        </div>

                                                    </div>
                                                </div>

                                                <div class="product-list-mode-content-v2">
                                                    <div class="list-v2-inner">
                                                        



                                                    </div>
                                                </div>

                                            </div>


                                        </div>
                                        <div class="product-grid-item mode-view-item">
                                            <div class="product-wrapper effect-overlay ">
                                                <div class="product-head">
                                                    <div class="product-image">
                                                        <div class="featured-img product-ratio-auto">
                                                            <a
                                                                href="/collections/gaming-mouse-price-in-pakistan/products/redragon-m690-mirage-wireless-gaming-mouse">










                                                                <span class="image-lazysize">
                                                                    <!-- noscript pattern -->
                                                                    <noscript>
                                                                        <img class="img-lazy product-ratio-auto featured-image front"
                                                                            src="//redragonzone.pk/cdn/shop/products/M690_2-removebg-preview_420x.png?v=1630851013"
                                                                            alt="Redragon M690 MIRAGE 4800 DPI, 8 Buttons Wireless Gaming Mouse - Redragon Pakistan" />
                                                                    </noscript>

                                                                    <img class="lazyload featured-image front img-lazy blur-up auto-crop-false"
                                                                        data-src="//redragonzone.pk/cdn/shop/products/M690_2-removebg-preview_{width}x.png?v=1630851013"
                                                                        data-widths="[180, 320, 540, 720, 1080, 1366, 1920, 2048] "
                                                                        data-aspectratio="1.0" data-sizes="auto"
                                                                        data-parent-fit="cover"
                                                                        alt="Redragon M690 MIRAGE 4800 DPI, 8 Buttons Wireless Gaming Mouse - Redragon Pakistan" />
                                                                </span>










                                                            </a>
                                                        </div>



                                                        

                                                    </div>


                                                    

                                                </div>

                                                <div class="product-content">
                                                    <div class="pc-inner">


                                                        <div class="list-v2-label">
                                                            
                                                        </div>


                                                        <div class="product-group-vendor-name">
                                                            <div class="product-vendor"><a
                                                                    href="/collections/vendors?q=REDRAGON"
                                                                    title="REDRAGON">REDRAGON</a></div>
                                                            <h5 class="product-name balance-false"><a
                                                                    href="mouse4.php">Redragon
                                                                    M690 MIRAGE 4800 DPI, 8 Buttons Wireless
                                                                    Gaming Mouse</a></h5>

                                                            <div class="product-review">

                                                                <span class="shopify-product-reviews-badge"
                                                                    data-id="5893159649431"></span>

                                                            </div>

                                                        </div>






                                                        <div class="product-price notranslate">

                                                            <span class="price">Rs. <?php $MouseRow = mysqli_fetch_assoc($MousePricesResult); echo $MouseRow['Price']; ?></span>

                                                        </div>



                                                        <div class="product-list-mode-content">


                                                            


                                                        </div>

                                                    </div>
                                                </div>

                                                

                                            </div>


                                        </div>
                                        <div class="product-grid-item mode-view-item">







                                            <div class="product-wrapper effect-overlay ">

                                                <div class="product-head">
                                                    <div class="product-image">

                                                        <div class="featured-img product-ratio-auto">
                                                            <a
                                                                href="/collections/gaming-mouse-price-in-pakistan/products/redragon-nemeanlion-2-rgb-m602-1-gaming-mouse">










                                                                <span class="image-lazysize">
                                                                    <!-- noscript pattern -->
                                                                    <noscript>
                                                                        <img class="img-lazy product-ratio-auto featured-image front"
                                                                            src="//redragonzone.pk/cdn/shop/products/Redragon_NEMEANLION_2_RGB_M602-1_Gaming_Mouse-1_420x.png?v=1582850934"
                                                                            alt="Redragon M602-1 NEMEANLION 2 RGB 7200DPI, 7 Programmable Buttons Gaming Mouse - Redragon Pakistan" />
                                                                    </noscript>

                                                                    <img class="lazyload featured-image front img-lazy blur-up auto-crop-false"
                                                                        data-src="//redragonzone.pk/cdn/shop/products/Redragon_NEMEANLION_2_RGB_M602-1_Gaming_Mouse-1_{width}x.png?v=1582850934"
                                                                        data-widths="[180, 320, 540, 720, 1080, 1366, 1920, 2048] "
                                                                        data-aspectratio="1.0" data-sizes="auto"
                                                                        data-parent-fit="cover"
                                                                        alt="Redragon M602-1 NEMEANLION 2 RGB 7200DPI, 7 Programmable Buttons Gaming Mouse - Redragon Pakistan" />
                                                                </span>










                                                                <span class="product-label flex">












                                                                    <span class="label-sale">

                                                                        <span class="sale-text">Sale</span>

                                                                    </span>






                                                                </span>

                                                            </a>
                                                        </div>



                                                       

                                                    </div>


                                                    

                                                </div>

                                                <div class="product-content">
                                                    <div class="pc-inner">


                                                        <div class="list-v2-label">
                                                            
                                                        </div>


                                                        <div class="product-group-vendor-name">
                                                            <div class="product-vendor"><a
                                                                    href="/collections/vendors?q=REDRAGON"
                                                                    title="REDRAGON">REDRAGON</a></div>
                                                            <h5 class="product-name balance-false"><a
                                                                    href="mouse5.php">Redragon
                                                                    M602-1 NEMEANLION 2 RGB 7200DPI, 7
                                                                    Programmable Buttons Gaming Mouse</a>
                                                            </h5>

                                                            <div class="product-review">

                                                                <span class="shopify-product-reviews-badge"
                                                                    data-id="4542993236107"></span>

                                                            </div>

                                                        </div>






                                                        <div class="product-price notranslate">

                                                            <span class="price-compare">Rs. 4,875</span>
                                                            <span class="price-sale">Rs. <?php $MouseRow = mysqli_fetch_assoc($MousePricesResult); echo $MouseRow['Price']; ?></span>

                                                        </div>



                                                        <div class="product-list-mode-content">


                                                            




                                                        </div>

                                                    </div>
                                                </div>

                                                

                                            </div>


                                        </div>
                                        <div class="product-grid-item mode-view-item">







                                            <div class="product-wrapper effect-overlay ">

                                                <div class="product-head">
                                                    <div class="product-image">

                                                        <div class="featured-img product-ratio-auto">
                                                            <a
                                                                href="/collections/gaming-mouse-price-in-pakistan/products/redragon-m721-pro-lonewolf2-gaming-mouse">










                                                                <span class="image-lazysize">
                                                                    <!-- noscript pattern -->
                                                                    <noscript>
                                                                        <img class="img-lazy product-ratio-auto featured-image front"
                                                                            src="//redragonzone.pk/cdn/shop/products/M721-PRO-1_450x450_10b59db9-7b6e-4158-9ed8-0b383e36d157_420x.png?v=1630861527"
                                                                            alt="Redragon M721-PRO LONEWOLF 2 RGB Wired Gaming mouse - Redragon Pakistan" />
                                                                    </noscript>

                                                                    <img class="lazyload featured-image front img-lazy blur-up auto-crop-false"
                                                                        data-src="//redragonzone.pk/cdn/shop/products/M721-PRO-1_450x450_10b59db9-7b6e-4158-9ed8-0b383e36d157_{width}x.png?v=1630861527"
                                                                        data-widths="[180, 320, 540, 720, 1080, 1366, 1920, 2048] "
                                                                        data-aspectratio="1.0" data-sizes="auto"
                                                                        data-parent-fit="cover"
                                                                        alt="Redragon M721-PRO LONEWOLF 2 RGB Wired Gaming mouse - Redragon Pakistan" />
                                                                </span>










                                                            </a>
                                                        </div>



                                                       

                                                    </div>


                                                    

                                                </div>

                                                <div class="product-content">
                                                    <div class="pc-inner">


                                                        <div class="list-v2-label">
                                                            
                                                        </div>


                                                        <div class="product-group-vendor-name">
                                                            <div class="product-vendor"><a
                                                                    href="/collections/vendors?q=REDRAGON"
                                                                    title="REDRAGON">REDRAGON</a></div>
                                                            <h5 class="product-name balance-false"><a
                                                                    href="mouse6.php">Redragon
                                                                    M721-PRO LONEWOLF 2 RGB Wired Gaming
                                                                    mouse</a></h5>

                                                            <div class="product-review">

                                                                <span class="shopify-product-reviews-badge"
                                                                    data-id="5487118024855"></span>

                                                            </div>

                                                        </div>






                                                        <div class="product-price notranslate">

                                                            <span class="price">Rs. <?php $MouseRow = mysqli_fetch_assoc($MousePricesResult); echo $MouseRow['Price']; ?></span>

                                                        </div>



                                                        <div class="product-list-mode-content">


                                                           


                                                            




                                                        </div>

                                                    </div>
                                                </div>

                                                <div class="product-list-mode-content-v2">
                                                    <div class="list-v2-inner">
                                                        



                                                    </div>
                                                </div>

                                            </div>


                                        </div>
                                        <div class="product-grid-item mode-view-item">







                                            <div class="product-wrapper effect-overlay ">

                                                <div class="product-head">
                                                    <div class="product-image">

                                                        <div class="featured-img product-ratio-auto">
                                                            <a
                                                                href="/collections/gaming-mouse-price-in-pakistan/products/redragon-m808-white-rgb-storm-lunar-gaming-mouse">










                                                                <span class="image-lazysize">
                                                                    <!-- noscript pattern -->
                                                                    <noscript>
                                                                        <img class="img-lazy product-ratio-auto featured-image front"
                                                                            src="//redragonzone.pk/cdn/shop/products/51SAnAqc2BL._AC_SL1000_420x.jpg?v=1635257265"
                                                                            alt="Redragon M808W STORM LUNAR Lightweight RGB Gaming Mouse with 12400 DPI, 7 Programmable Buttons - Redragon Pakistan " />
                                                                    </noscript>

                                                                    <img class="lazyload featured-image front img-lazy blur-up auto-crop-false"
                                                                        data-src="//redragonzone.pk/cdn/shop/products/51SAnAqc2BL._AC_SL1000_{width}x.jpg?v=1635257265"
                                                                        data-widths="[180, 320, 540, 720, 1080, 1366, 1920, 2048] "
                                                                        data-aspectratio="1.0" data-sizes="auto"
                                                                        data-parent-fit="cover"
                                                                        alt="Redragon M808W STORM LUNAR Lightweight RGB Gaming Mouse with 12400 DPI, 7 Programmable Buttons - Redragon Pakistan " />
                                                                </span>














                                                                <span class="product-label flex">







                                                                    <span class="label-new">
                                                                        <span class="new-text">New</span>
                                                                    </span>



                                                                </span>
                                                            </a>
                                                        </div>
                                                        

                                                    </div>
                                                    

                                                </div>

                                                <div class="product-content">
                                                    <div class="pc-inner">


                                                        <div class="list-v2-label">
                                                            
                                                        </div>


                                                        <div class="product-group-vendor-name">
                                                            <div class="product-vendor"><a
                                                                    href="/collections/vendors?q=REDRAGON"
                                                                    title="REDRAGON">REDRAGON</a></div>
                                                            <h5 class="product-name balance-false"><a
                                                                    href="mouse7.php">Redragon
                                                                    M808W STORM LUNAR Lightweight RGB Gaming
                                                                    Mouse with 12400 DPI, 7 Programmable
                                                                    Buttons (White)</a></h5>

                                                            <div class="product-review">

                                                                <span class="shopify-product-reviews-badge"
                                                                    data-id="7239063240855"></span>

                                                            </div>

                                                        </div>






                                                        <div class="product-price notranslate">

                                                            <span class="price">Rs. <?php $MouseRow = mysqli_fetch_assoc($MousePricesResult); echo $MouseRow['Price']; ?></span>

                                                        </div>



                                                        <div class="product-list-mode-content">


                                                            


                                                            




                                                        </div>

                                                    </div>
                                                </div>

                                                <div class="product-list-mode-content-v2">
                                                    <div class="list-v2-inner">
                                                        



                                                    </div>
                                                </div>

                                            </div>


                                        </div>
                                        <div class="product-grid-item mode-view-item">







                                            <div class="product-wrapper effect-overlay ">

                                                <div class="product-head">
                                                    <div class="product-image">

                                                        <div class="featured-img product-ratio-auto">
                                                            <a
                                                                href="/collections/gaming-mouse-price-in-pakistan/products/redragon-m710-memeanlion-chroma-gaming-mouse">










                                                                <span class="image-lazysize">
                                                                    <!-- noscript pattern -->
                                                                    <noscript>
                                                                        <img class="img-lazy product-ratio-auto featured-image front"
                                                                            src="//redragonzone.pk/cdn/shop/products/Redragon_M710_MEMEANLION_Chroma_Gaming_Mouse-1_420x.jpg?v=1630853610"
                                                                            alt="Redragon M710 Memeanlion Chroma RGB Gaming Mouse - Redragon Pakistan" />
                                                                    </noscript>

                                                                    <img class="lazyload featured-image front img-lazy blur-up auto-crop-false"
                                                                        data-src="//redragonzone.pk/cdn/shop/products/Redragon_M710_MEMEANLION_Chroma_Gaming_Mouse-1_{width}x.jpg?v=1630853610"
                                                                        data-widths="[180, 320, 540, 720, 1080, 1366, 1920, 2048] "
                                                                        data-aspectratio="1.0" data-sizes="auto"
                                                                        data-parent-fit="cover"
                                                                        alt="Redragon M710 Memeanlion Chroma RGB Gaming Mouse - Redragon Pakistan" />
                                                                </span>










                                                            </a>
                                                        </div>



                                                        

                                                    </div>


                                                    

                                                </div>

                                                <div class="product-content">
                                                    <div class="pc-inner">


                                                        <div class="list-v2-label">
                                                            
                                                        </div>


                                                        <div class="product-group-vendor-name">
                                                            <div class="product-vendor"><a
                                                                    href="/collections/vendors?q=REDRAGON"
                                                                    title="REDRAGON">REDRAGON</a></div>
                                                            <h5 class="product-name balance-false"><a
                                                                    href="mouse8.php">Redragon
                                                                    M710 Memeanlion Chroma RGB Gaming
                                                                    Mouse</a></h5>

                                                            <div class="product-review">

                                                                <span class="shopify-product-reviews-badge"
                                                                    data-id="4543055167627"></span>

                                                            </div>

                                                        </div>






                                                        <div class="product-price notranslate">

                                                            <span class="price">Rs. <?php $MouseRow = mysqli_fetch_assoc($MousePricesResult); echo $MouseRow['Price']; ?></span>

                                                        </div>



                                                        <div class="product-list-mode-content">


                                                            


                                                            



                                                        </div>

                                                    </div>
                                                </div>

                                                <div class="product-list-mode-content-v2">
                                                    <div class="list-v2-inner">
                                                        



                                                    </div>
                                                </div>

                                            </div>


                                        </div>
                                        <div class="product-grid-item mode-view-item">







                                            <div class="product-wrapper effect-overlay ">

                                                <div class="product-head">
                                                    <div class="product-image">

                                                        <div class="featured-img product-ratio-auto">
                                                            <a
                                                                href="/collections/gaming-mouse-price-in-pakistan/products/redragon-m988-rgb-storm-elite-gaming-mouse">










                                                                <span class="image-lazysize">
                                                                    <!-- noscript pattern -->
                                                                    <noscript>
                                                                        <img class="img-lazy product-ratio-auto featured-image front"
                                                                            src="//redragonzone.pk/cdn/shop/products/6001039_a86f0640-25c5-4b0d-b068-95607bdb5496_450_450_420x.jpg?v=1613745545"
                                                                            alt="Redragon M988 RGB STORM ELITE Gaming Mouse 32000 DPI 7 Programmable Buttons - Redragon Pakistan " />
                                                                    </noscript>

                                                                    <img class="lazyload featured-image front img-lazy blur-up auto-crop-false"
                                                                        data-src="//redragonzone.pk/cdn/shop/products/6001039_a86f0640-25c5-4b0d-b068-95607bdb5496_450_450_{width}x.jpg?v=1613745545"
                                                                        data-widths="[180, 320, 540, 720, 1080, 1366, 1920, 2048] "
                                                                        data-aspectratio="1.0" data-sizes="auto"
                                                                        data-parent-fit="cover"
                                                                        alt="Redragon M988 RGB STORM ELITE Gaming Mouse 32000 DPI 7 Programmable Buttons - Redragon Pakistan " />
                                                                </span>














                                                                <span class="product-label flex">







                                                                    <span class="label-new">
                                                                        <span class="new-text">New</span>
                                                                    </span>
















                                                                    <span class="label-sale">

                                                                        <span class="sale-text">Sale</span>

                                                                    </span>






                                                                </span>

                                                            </a>
                                                        </div>



                                                        

                                                    </div>


                                                    

                                                </div>

                                                <div class="product-content">
                                                    <div class="pc-inner">


                                                        


                                                        <div class="product-group-vendor-name">
                                                            <div class="product-vendor"><a
                                                                    href="/collections/vendors?q=REDRAGON"
                                                                    title="REDRAGON">REDRAGON</a></div>
                                                            <h5 class="product-name balance-false"><a
                                                                    href="mouse9.php">Redragon
                                                                    M988 RGB STORM ELITE Gaming Mouse 32000
                                                                    DPI 7 Programmable Buttons (Black)</a>
                                                            </h5>

                                                            <div class="product-review">

                                                                <span class="shopify-product-reviews-badge"
                                                                    data-id="6473928605847"></span>

                                                            </div>

                                                        </div>






                                                        <div class="product-price notranslate">

                                                            <span class="price-compare">Rs. 7,150</span>
                                                            <span class="price-sale">Rs. <?php $MouseRow = mysqli_fetch_assoc($MousePricesResult); echo $MouseRow['Price']; ?></span>

                                                        </div>



                                                        <div class="product-list-mode-content">


                                                            


                                                            




                                                        </div>

                                                    </div>
                                                </div>

                                                <div class="product-list-mode-content-v2">
                                                    <div class="list-v2-inner">
                                                        



                                                    </div>
                                                </div>

                                            </div>


                                        </div>
                                        <div class="product-grid-item mode-view-item">
                                            <div class="product-wrapper effect-overlay ">

                                                <div class="product-head">
                                                    <div class="product-image">

                                                        <div class="featured-img product-ratio-auto">
                                                            <a
                                                                href="/collections/gaming-mouse-price-in-pakistan/products/redragon-m686-vampire-wireless-gaming-mouse">

                                                                <span class="image-lazysize">
                                                                    <!-- noscript pattern -->
                                                                    <noscript>
                                                                        <img class="img-lazy product-ratio-auto featured-image front"
                                                                            src="//redragonzone.pk/cdn/shop/products/m686gamingmouse_1_450x450_0794f274-bf2a-4f66-b839-901cf64e00de_420x.png?v=1634734408"
                                                                            alt="Redragon M686 VAMPIRE ELITE Wireless Gaming Mouse - Redragon Pakistan" />
                                                                    </noscript>

                                                                    <img class="lazyload featured-image front img-lazy blur-up auto-crop-false"
                                                                        data-src="//redragonzone.pk/cdn/shop/products/m686gamingmouse_1_450x450_0794f274-bf2a-4f66-b839-901cf64e00de_{width}x.png?v=1634734408"
                                                                        data-widths="[180, 320, 540, 720, 1080, 1366, 1920, 2048] "
                                                                        data-aspectratio="1.0" data-sizes="auto"
                                                                        data-parent-fit="cover"
                                                                        alt="Redragon M686 VAMPIRE ELITE Wireless Gaming Mouse - Redragon Pakistan" />
                                                                </span>
                                                                <span class="product-label flex">
                                                                    <span class="label-new">
                                                                        <span class="new-text">New</span>
                                                                    </span>
                                                                </span>

                                                            </a>
                                                        </div>



                                                        

                                                    </div>


                                                    

                                                </div>

                                                <div class="product-content">
                                                    <div class="pc-inner">


                                                        <div class="list-v2-label">
                                                            
                                                        </div>


                                                        <div class="product-group-vendor-name">
                                                            <div class="product-vendor"><a
                                                                    href="/collections/vendors?q=REDRAGON"
                                                                    title="REDRAGON">REDRAGON</a></div>
                                                            <h5 class="product-name balance-false"><a
                                                                    href="mouse10.php">Redragon
                                                                    M686 VAMPIRE ELITE Wireless Gaming
                                                                    Mouse</a></h5>

                                                            <div class="product-review">

                                                                <span class="shopify-product-reviews-badge"
                                                                    data-id="7228690858135"></span>

                                                            </div>

                                                        </div>






                                                        <div class="product-price notranslate">

                                                            <span class="price">Rs. <?php $MouseRow = mysqli_fetch_assoc($MousePricesResult); echo $MouseRow['Price']; ?></span>

                                                        </div>



                                                        <div class="product-list-mode-content">


                                                            


                                                            



                                                        </div>

                                                    </div>
                                                </div>

                                                <div class="product-list-mode-content-v2">
                                                    <div class="list-v2-inner">
                                                        



                                                    </div>
                                                </div>

                                            </div>


                                        </div>
                                        <div class="product-grid-item mode-view-item">

                                            <div class="product-wrapper effect-overlay ">

                                                <div class="product-head">
                                                    <div class="product-image">

                                                        <div class="featured-img product-ratio-auto">
                                                            <a
                                                                href="/collections/gaming-mouse-price-in-pakistan/products/redragon-m719-gaming-mouse">


                                                                <span class="image-lazysize">
                                                                    <!-- noscript pattern -->
                                                                    <noscript>
                                                                        <img class="img-lazy product-ratio-auto featured-image front"
                                                                            src="//redragonzone.pk/cdn/shop/products/Redragon_M719_1_420x.png?v=1630860690"
                                                                            alt="Redragon M719 INVADER Gaming Mouse with Fire Button, 7 Programmable Buttons, RGB Backlit, 10,000 DPI - Redragon Pakistan" />
                                                                    </noscript>

                                                                    <img class="lazyload featured-image front img-lazy blur-up auto-crop-false"
                                                                        data-src="//redragonzone.pk/cdn/shop/products/Redragon_M719_1_{width}x.png?v=1630860690"
                                                                        data-widths="[180, 320, 540, 720, 1080, 1366, 1920, 2048] "
                                                                        data-aspectratio="1.0" data-sizes="auto"
                                                                        data-parent-fit="cover"
                                                                        alt="Redragon M719 INVADER Gaming Mouse with Fire Button, 7 Programmable Buttons, RGB Backlit, 10,000 DPI - Redragon Pakistan" />
                                                                </span>

                                                            </a>
                                                        </div>



                                                        

                                                    </div>


                                                    

                                                </div>

                                                <div class="product-content">
                                                    <div class="pc-inner">


                                                        <div class="list-v2-label">
                                                            
                                                        </div>


                                                        <div class="product-group-vendor-name">
                                                            <div class="product-vendor"><a
                                                                    href="/collections/vendors?q=REDRAGON"
                                                                    title="REDRAGON">REDRAGON</a></div>
                                                            <h5 class="product-name balance-false"><a
                                                                    href="mouse11.php">Redragon
                                                                    M719 INVADER Gaming Mouse with Fire
                                                                    Button, 7 Programmable Buttons, RGB
                                                                    Backlit, 10,000 DPI</a></h5>

                                                            <div class="product-review">

                                                                <span class="shopify-product-reviews-badge"
                                                                    data-id="6071891525783"></span>

                                                            </div>

                                                        </div>






                                                        <div class="product-price notranslate">

                                                            <span class="price">Rs. <?php $MouseRow = mysqli_fetch_assoc($MousePricesResult); echo $MouseRow['Price']; ?></span>

                                                        </div>



                                                        <div class="product-list-mode-content">


                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="product-list-mode-content-v2">
                                                    <div class="list-v2-inner">
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="product-grid-item mode-view-item">
                                            <div class="product-wrapper effect-overlay ">
                                                <div class="product-head">
                                                    <div class="product-image">
                                                        <div class="featured-img product-ratio-auto">
                                                            <a
                                                                href="/collections/gaming-mouse-price-in-pakistan/products/redragon-m711-w-cobra-white-gaming-mouse">
                                                                <span class="image-lazysize">
                                                                    <!-- noscript pattern -->
                                                                    <noscript>
                                                                        <img class="img-lazy product-ratio-auto featured-image front"
                                                                            src="//redragonzone.pk/cdn/shop/products/M711_white_420x.png?v=1624531993"
                                                                            alt="Redragon M711 COBRA RGB Gaming Mouse - Redragon Pakistan" />
                                                                    </noscript>

                                                                    <img class="lazyload featured-image front img-lazy blur-up auto-crop-false"
                                                                        data-src="//redragonzone.pk/cdn/shop/products/M711_white_{width}x.png?v=1624531993"
                                                                        data-widths="[180, 320, 540, 720, 1080, 1366, 1920, 2048] "
                                                                        data-aspectratio="1.0" data-sizes="auto"
                                                                        data-parent-fit="cover"
                                                                        alt="Redragon M711 COBRA RGB Gaming Mouse - Redragon Pakistan" />
                                                                </span>
                                                            </a>
                                                        </div>
                                                        
                                                    </div>
                                                    
                                                </div>
                                                <div class="product-content">
                                                    <div class="pc-inner">
                                                        <div class="list-v2-label">
                                                           
                                                        </div>
                                                        <div class="product-group-vendor-name">
                                                            <div class="product-vendor"><a
                                                                    href="/collections/vendors?q=REDRAGON"
                                                                    title="REDRAGON">REDRAGON</a></div>
                                                            <h5 class="product-name balance-false"><a
                                                                    href="mouse12.php">Redragon
                                                                    M711 COBRA RGB Gaming Mouse (White)</a>
                                                            </h5>
                                                            <div class="product-review">
                                                                <span class="shopify-product-reviews-badge"
                                                                    data-id="6969363431575"></span>
                                                            </div>
                                                        </div>
                                                        <div class="product-price notranslate">
                                                            <span class="price">Rs. <?php $MouseRow = mysqli_fetch_assoc($MousePricesResult); echo $MouseRow['Price']; ?></span>
                                                        </div>
                                                        <div class="product-list-mode-content">
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="product-list-mode-content-v2">
                                                    <div class="list-v2-inner">
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="product-grid-item mode-view-item">
                                            <div class="product-wrapper effect-overlay ">
                                                <div class="product-head">
                                                    <div class="product-image">
                                                        <div class="featured-img product-ratio-auto">
                                                            <a
                                                                href="/collections/gaming-mouse-price-in-pakistan/products/redragon-gerberus-m703-wired-gaming-mouse">
                                                                <span class="image-lazysize">
                                                                    <!-- noscript pattern -->
                                                                    <noscript>
                                                                        <img class="img-lazy product-ratio-auto featured-image front"
                                                                            src="//redragonzone.pk/cdn/shop/products/Redragon_Gerberus_M703_High_Performance_Wired_Gaming_Mouse-1_420x.jpg?v=1630838467"
                                                                            alt="Redragon M703 GERBERUS, 7200DPI, 6 Programmable Wired Gaming Mouse - Redragon Pakistan" />
                                                                    </noscript>
                                                                    <img class="lazyload featured-image front img-lazy blur-up auto-crop-false"
                                                                        data-src="//redragonzone.pk/cdn/shop/products/Redragon_Gerberus_M703_High_Performance_Wired_Gaming_Mouse-1_{width}x.jpg?v=1630838467"
                                                                        data-widths="[180, 320, 540, 720, 1080, 1366, 1920, 2048] "
                                                                        data-aspectratio="1.0" data-sizes="auto"
                                                                        data-parent-fit="cover"
                                                                        alt="Redragon M703 GERBERUS, 7200DPI, 6 Programmable Wired Gaming Mouse - Redragon Pakistan" />
                                                                </span>
                                                            </a>
                                                        </div>
                                                        
                                                    </div>
                                                    
                                                </div>
                                                <div class="product-content">
                                                    <div class="pc-inner">
                                                        <div class="list-v2-label">
                                                            
                                                        </div>
                                                        <div class="product-group-vendor-name">
                                                            <div class="product-vendor"><a
                                                                    href="/collections/vendors?q=REDRAGON"
                                                                    title="REDRAGON">REDRAGON</a></div>
                                                            <h5 class="product-name balance-false"><a
                                                                    href="mouse13.php">Redragon
                                                                    M703 GERBERUS, 7200DPI, 6 Programmable
                                                                    Wired Gaming Mouse</a></h5>
                                                            <div class="product-review">
                                                                <span class="shopify-product-reviews-badge"
                                                                    data-id="4543049597067"></span>
                                                            </div>
                                                        </div>
                                                        <div class="product-price notranslate">
                                                            <span class="price">Rs. <?php $MouseRow = mysqli_fetch_assoc($MousePricesResult); echo $MouseRow['Price']; ?></span>
                                                        </div>
                                                        <div class="product-list-mode-content">
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="product-list-mode-content-v2">
                                                    <div class="list-v2-inner">
                                                       
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="product-grid-item mode-view-item">
                                            <div class="product-wrapper effect-overlay ">
                                                <div class="product-head">
                                                    <div class="product-image">
                                                        <div class="featured-img product-ratio-auto">
                                                            <a
                                                                href="/collections/gaming-mouse-price-in-pakistan/products/redragon-m907-inspirit-14400-dpi-gaming-mouse">
                                                                <span class="image-lazysize">
                                                                    <!-- noscript pattern -->
                                                                    <noscript>
                                                                        <img class="img-lazy product-ratio-auto featured-image front"
                                                                            src="//redragonzone.pk/cdn/shop/products/M907_1_450x450_5b65f60c-6d62-436d-b17a-e6db0366e0b6_420x.png?v=1630863643"
                                                                            alt="Redragon M907 INSPIRIT 14400 DPI Gaming Mouse - Redragon Pakistan " />
                                                                    </noscript>
                                                                    <img class="lazyload featured-image front img-lazy blur-up auto-crop-false"
                                                                        data-src="//redragonzone.pk/cdn/shop/products/M907_1_450x450_5b65f60c-6d62-436d-b17a-e6db0366e0b6_{width}x.png?v=1630863643"
                                                                        data-widths="[180, 320, 540, 720, 1080, 1366, 1920, 2048] "
                                                                        data-aspectratio="1.0" data-sizes="auto"
                                                                        data-parent-fit="cover"
                                                                        alt="Redragon M907 INSPIRIT 14400 DPI Gaming Mouse - Redragon Pakistan " />
                                                                </span>
                                                            </a>
                                                        </div>
                                                        
                                                    </div>
                                                    
                                                </div>
                                                <div class="product-content">
                                                    <div class="pc-inner">
                                                        <div class="list-v2-label">
                                                            
                                                        </div>
                                                        <div class="product-group-vendor-name">
                                                            <div class="product-vendor"><a
                                                                    href="/collections/vendors?q=REDRAGON"
                                                                    title="REDRAGON">REDRAGON</a></div>
                                                            <h5 class="product-name balance-false"><a
                                                                    href="mouse14.php">Redragon
                                                                    M907 INSPIRIT 14400 DPI Gaming Mouse</a>
                                                            </h5>
                                                            <div class="product-review">
                                                                <span class="shopify-product-reviews-badge"
                                                                    data-id="4543087771787"></span>
                                                            </div>
                                                        </div>
                                                        <div class="product-price notranslate">
                                                            <span class="price">Rs. <?php $MouseRow = mysqli_fetch_assoc($MousePricesResult); echo $MouseRow['Price']; ?></span>
                                                        </div>
                                                        <div class="product-list-mode-content">
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="product-list-mode-content-v2">
                                                    <div class="list-v2-inner">
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="product-grid-item mode-view-item">
                                            <div class="product-wrapper effect-overlay ">
                                                <div class="product-head">
                                                    <div class="product-image">
                                                        <div class="featured-img product-ratio-auto">
                                                            <a
                                                                href="/collections/gaming-mouse-price-in-pakistan/products/redragon-m988-white-rgb-storm-elite-gaming-mouse">
                                                                <span class="image-lazysize">
                                                                    <!-- noscript pattern -->
                                                                    <noscript>
                                                                        <img class="img-lazy product-ratio-auto featured-image front"
                                                                            src="//redragonzone.pk/cdn/shop/products/m988w-rgb-png-web-11-0696753b8d49a43e2b16235600069907-1024-1024_420x.png?v=1635258386"
                                                                            alt="Redragon M988 STORM ELITE RGB Gaming Mouse - Redragon Pakistan " />
                                                                    </noscript>
                                                                    <img class="lazyload featured-image front img-lazy blur-up auto-crop-false"
                                                                        data-src="//redragonzone.pk/cdn/shop/products/m988w-rgb-png-web-11-0696753b8d49a43e2b16235600069907-1024-1024_{width}x.png?v=1635258386"
                                                                        data-widths="[180, 320, 540, 720, 1080, 1366, 1920, 2048] "
                                                                        data-aspectratio="1.0" data-sizes="auto"
                                                                        data-parent-fit="cover"
                                                                        alt="Redragon M988 STORM ELITE RGB Gaming Mouse - Redragon Pakistan " />
                                                                </span>
                                                                <span class="product-label flex">
                                                                    <span class="label-new">
                                                                        <span class="new-text">New</span>
                                                                    </span>
                                                                </span>
                                                            </a>
                                                        </div>
                                                        
                                                    </div>
                                                    
                                                </div>
                                                <div class="product-content">
                                                    <div class="pc-inner">
                                                        <div class="list-v2-label">
                                                            
                                                        </div>
                                                        <div class="product-group-vendor-name">
                                                            <div class="product-vendor"><a
                                                                    href="/collections/vendors?q=REDRAGON"
                                                                    title="REDRAGON">REDRAGON</a></div>
                                                            <h5 class="product-name balance-false"><a
                                                                    href="mouse15.php">Redragon
                                                                    M988 STORM ELITE RGB Gaming Mouse
                                                                    (White)</a></h5>
                                                            <div class="product-review">
                                                                <span class="shopify-product-reviews-badge"
                                                                    data-id="7239096303767"></span>
                                                            </div>
                                                        </div>
                                                        <div class="product-price notranslate">
                                                            <span class="price">Rs. <?php $MouseRow = mysqli_fetch_assoc($MousePricesResult); echo $MouseRow['Price']; ?></span>
                                                        </div>
                                                        <div class="product-list-mode-content">
                                                            
                                                           
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="product-list-mode-content-v2">
                                                    <div class="list-v2-inner">
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="product-grid-item mode-view-item">
                                            <div class="product-wrapper effect-overlay ">
                                                <div class="product-head">
                                                    <div class="product-image">
                                                        <div class="featured-img product-ratio-auto">
                                                            <a
                                                                href="/collections/gaming-mouse-price-in-pakistan/products/redragon-m910-ranger-gaming-mouse-12400-dpi">
                                                                <span class="image-lazysize">
                                                                    <!-- noscript pattern -->
                                                                    <noscript>
                                                                        <img class="img-lazy product-ratio-auto featured-image front"
                                                                            src="//redragonzone.pk/cdn/shop/products/M910-1_450x450_228b8890-30d4-4b78-a2e1-86bb11a797bb_420x.jpg?v=1641901530"
                                                                            alt="Redragon M910 RANGER CHROMA Gaming Mouse with 16.8 Million RGB Backlit, 9 Programmable Buttons, Up to 12400 DPI User Adjustable - Redragon Pakistan " />
                                                                    </noscript>
                                                                    <img class="lazyload featured-image front img-lazy blur-up auto-crop-false"
                                                                        data-src="//redragonzone.pk/cdn/shop/products/M910-1_450x450_228b8890-30d4-4b78-a2e1-86bb11a797bb_{width}x.jpg?v=1641901530"
                                                                        data-widths="[180, 320, 540, 720, 1080, 1366, 1920, 2048] "
                                                                        data-aspectratio="1.0" data-sizes="auto"
                                                                        data-parent-fit="cover"
                                                                        alt="Redragon M910 RANGER CHROMA Gaming Mouse with 16.8 Million RGB Backlit, 9 Programmable Buttons, Up to 12400 DPI User Adjustable - Redragon Pakistan " />
                                                                </span>
                                                                <span class="product-label flex">
                                                                    <span class="label-new">
                                                                        <span class="new-text">New</span>
                                                                    </span>
                                                                </span>
                                                            </a>
                                                        </div>
                                                        
                                                    </div>
                                                    
                                                </div>
                                                <div class="product-content">
                                                    <div class="pc-inner">
                                                        <div class="list-v2-label">
                                                           
                                                        </div>
                                                        <div class="product-group-vendor-name">
                                                            <div class="product-vendor"><a
                                                                    href="/collections/vendors?q=REDRAGON"
                                                                    title="REDRAGON">REDRAGON</a></div>
                                                            <h5 class="product-name balance-false"><a
                                                                    href="mouse16.php">Redragon
                                                                    M910 RANGER CHROMA Gaming Mouse with
                                                                    16.8 Million RGB Backlit, 9 Programmable
                                                                    Buttons, Up to 12400 DPI User
                                                                    Adjustable</a></h5>
                                                            <div class="product-review">
                                                                <span class="shopify-product-reviews-badge"
                                                                    data-id="7363901227159"></span>
                                                            </div>
                                                        </div>
                                                        <div class="product-price notranslate">
                                                            <span class="price">Rs. <?php $MouseRow = mysqli_fetch_assoc($MousePricesResult); echo $MouseRow['Price']; ?></span>
                                                        </div>
                                                        <div class="product-list-mode-content">
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="product-list-mode-content-v2">
                                                    <div class="list-v2-inner">
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-------------------------------------- endp new----------------------------------------------------------------->
                            </div>
                            <div style="margin-bottom: 90px;"></div>
                        </div>
                    </div>
                </div>
            </div>
            <!-------------------------------main e---------------------------->
        </div>
    </div>
    </div>
    <footer>
        <div class="d-flex flex-wrap p-3 box6">
            <div class="flex-fill">
                <p>INFO@REDRAGONZONE.PK</p>
                <div class="top">
                    <a href="index.php"><img src="picc/redragon.png" width="210px" height="190px" alt=""></a>
                </div>
                <p>CUSTOMER CARE CENTER</p>
                <p>314 - AL-HAFEEZ SHOPPING MALL, GULBERG III,<br>
                    MAIN BOULEVARD, LAHORE - PAKISTAN</p>
                <p>(+92) 3111 000 135</p>
            </div>
            <div class="flex-fill">
                <p>PRODUCTS</p>
                <ul>
                    <a href="keyboard.php">
                        <li>KEYBOARD</li>
                    </a>

                    <a href="mouse.php">
                        <li>MOUSE</li>
                    </a>

                    <a href="combo.php">
                        <li>COMBO</li>
                    </a>

                    <a href="mousepad.php">
                        <li>MOUSE PAD</li>
                    </a>

                    <a href="headset.php">
                        <li>HEADSET</li>
                    </a>

                    <a href="stand1.php">
                        <li>HEADSET STAND</li>
                    </a>

                </ul>
            </div>

            <div class="flex-fill">
                <p> INFORMATION</p>
                <ul>
                    <li> <a href="Warranty.php">WARRANTY POLICY</a></li>
                    <li> <a href="payment.php">PAYMENT INFO</a></li>
                    <li> <a href="return.php">RETURN POLICY</a></li>
                </ul>

            </div>

            <div>
                <p>JOIN FOR EXCLUSIVE BENEFITS</p>
                <form action="/action_page.php">
                    <div class="d-flex box7">

                        <input type="email" class="form-control" id="email" placeholder="Your email address"
                            name="email">

                        <button type="submit" class="btn btn-danger ">Submit</button>
                    </div>
                </form>
            </div>

        </div>
    </footer>
</body>

</html>