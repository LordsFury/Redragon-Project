<?php include("Connection.php");
$_SESSION['PageTotal'] = 0;

if(isset($_SESSION['stringArray']) || isset($_SESSION['intArray'])){
  unset($_SESSION['stringArray']);
  unset($_SESSION['intArray']);
}
$_SESSION['stringArray'] = array();
$_SESSION['intArray'] = array();
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <title>Redragon</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="icon" href="picc/redragon.png" type="image/x-icon">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href="smile.css">
  <style>
    td{
      padding-left: 2vw;
      padding-right: 2vw;
    }
    table{
      margin-bottom: 3vh;
    }
  </style>
</head>


<body>

  <header>
    <div class="top-bar-list  ">

      <p> DUE TO LARGE NUMBER OF ORDERS, PLEASE EXPECT 1 TO 2 DAYS DELAY IN DELIVERY</p>

    </div>


    <div class="d-flex justify-content-between top-bar-right">
      <div class="d-flex hello">
        <div>
          <a href="https://redragonzone.pk/"> <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-facebook" viewBox="0 0 16 16">
              <path d="M16 8.049c0-4.446-3.582-8.05-8-8.05C3.58 0-.002 3.603-.002 8.05c0 4.017 2.926 7.347 6.75 7.951v-5.625h-2.03V8.05H6.75V6.275c0-2.017 1.195-3.131 3.022-3.131.876 0 1.791.157 1.791.157v1.98h-1.009c-.993 0-1.303.621-1.303 1.258v1.51h2.218l-.354 2.326H9.25V16c3.824-.604 6.75-3.934 6.75-7.951" />
            </svg></a>
        </div>

        <div>
          <a href="https://redragonzone.pk/"> <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-twitter" viewBox="0 0 16 16">
              <path d="M5.026 15c6.038 0 9.341-5.003 9.341-9.334 0-.14 0-.282-.006-.422A6.685 6.685 0 0 0 16 3.542a6.658 6.658 0 0 1-1.889.518 3.301 3.301 0 0 0 1.447-1.817 6.533 6.533 0 0 1-2.087.793A3.286 3.286 0 0 0 7.875 6.03a9.325 9.325 0 0 1-6.767-3.429 3.289 3.289 0 0 0 1.018 4.382A3.323 3.323 0 0 1 .64 6.575v.045a3.288 3.288 0 0 0 2.632 3.218 3.203 3.203 0 0 1-.865.115 3.23 3.23 0 0 1-.614-.057 3.283 3.283 0 0 0 3.067 2.277A6.588 6.588 0 0 1 .78 13.58a6.32 6.32 0 0 1-.78-.045A9.344 9.344 0 0 0 5.026 15" />
            </svg></a>
        </div>

        <div>
          <a href="https://redragonzone.pk/"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-pinterest" viewBox="0 0 16 16">
              <path d="M8 0a8 8 0 0 0-2.915 15.452c-.07-.633-.134-1.606.027-2.297.146-.625.938-3.977.938-3.977s-.239-.479-.239-1.187c0-1.113.645-1.943 1.448-1.943.682 0 1.012.512 1.012 1.127 0 .686-.437 1.712-.663 2.663-.188.796.4 1.446 1.185 1.446 1.422 0 2.515-1.5 2.515-3.664 0-1.915-1.377-3.254-3.342-3.254-2.276 0-3.612 1.707-3.612 3.471 0 .688.265 1.425.595 1.826a.24.24 0 0 1 .056.23c-.061.252-.196.796-.222.907-.035.146-.116.177-.268.107-1-.465-1.624-1.926-1.624-3.1 0-2.523 1.834-4.84 5.286-4.84 2.775 0 4.932 1.977 4.932 4.62 0 2.757-1.739 4.976-4.151 4.976-.811 0-1.573-.421-1.834-.919l-.498 1.902c-.181.695-.669 1.566-.995 2.097A8 8 0 1 0 8 0" />
            </svg></a>
        </div>
        <div>
          <a href="https://redragonzone.pk/"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-instagram" viewBox="0 0 16 16">
              <path d="M8 0C5.829 0 5.556.01 4.703.048 3.85.088 3.269.222 2.76.42a3.917 3.917 0 0 0-1.417.923A3.927 3.927 0 0 0 .42 2.76C.222 3.268.087 3.85.048 4.7.01 5.555 0 5.827 0 8.001c0 2.172.01 2.444.048 3.297.04.852.174 1.433.372 1.942.205.526.478.972.923 1.417.444.445.89.719 1.416.923.51.198 1.09.333 1.942.372C5.555 15.99 5.827 16 8 16s2.444-.01 3.298-.048c.851-.04 1.434-.174 1.943-.372a3.916 3.916 0 0 0 1.416-.923c.445-.445.718-.891.923-1.417.197-.509.332-1.09.372-1.942C15.99 10.445 16 10.173 16 8s-.01-2.445-.048-3.299c-.04-.851-.175-1.433-.372-1.941a3.926 3.926 0 0 0-.923-1.417A3.911 3.911 0 0 0 13.24.42c-.51-.198-1.092-.333-1.943-.372C10.443.01 10.172 0 7.998 0h.003zm-.717 1.442h.718c2.136 0 2.389.007 3.232.046.78.035 1.204.166 1.486.275.373.145.64.319.92.599.28.28.453.546.598.92.11.281.24.705.275 1.485.039.843.047 1.096.047 3.231s-.008 2.389-.047 3.232c-.035.78-.166 1.203-.275 1.485a2.47 2.47 0 0 1-.599.919c-.28.28-.546.453-.92.598-.28.11-.704.24-1.485.276-.843.038-1.096.047-3.232.047s-2.39-.009-3.233-.047c-.78-.036-1.203-.166-1.485-.276a2.478 2.478 0 0 1-.92-.598 2.48 2.48 0 0 1-.6-.92c-.109-.281-.24-.705-.275-1.485-.038-.843-.046-1.096-.046-3.233 0-2.136.008-2.388.046-3.231.036-.78.166-1.204.276-1.486.145-.373.319-.64.599-.92.28-.28.546-.453.92-.598.282-.11.705-.24 1.485-.276.738-.034 1.024-.044 2.515-.045v.002zm4.988 1.328a.96.96 0 1 0 0 1.92.96.96 0 0 0 0-1.92zm-4.27 1.122a4.109 4.109 0 1 0 0 8.217 4.109 4.109 0 0 0 0-8.217zm0 1.441a2.667 2.667 0 1 1 0 5.334 2.667 2.667 0 0 1 0-5.334" />
            </svg></a>
        </div>


      </div>

      <div>
        <span>Need help?</span>
        <a href="mailto:info@redragonzone.pk">info@redragonzone.pk</a>
      </div>

    </div>

    <div class="d-flex justify-content-between  align-items-center box1 ">
      <div><img src="picc/redragon.png" width="130px" height="90px" alt=""></div>

      <div>
        <a href="cart.php"> <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-cart" viewBox="0 0 16 16">
            <path d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .491.592l-1.5 8A.5.5 0 0 1 13 12H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5M3.102 4l1.313 7h8.17l1.313-7H3.102zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4m7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4m-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2m7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2" />
          </svg></a>

      </div>

    </div>


    <div>
      <div class="d-flex justify-content-between box2 p-3">
        <div>
          <p><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-truck" viewBox="0 0 16 16">
              <path d="M0 3.5A1.5 1.5 0 0 1 1.5 2h9A1.5 1.5 0 0 1 12 3.5V5h1.02a1.5 1.5 0 0 1 1.17.563l1.481 1.85a1.5 1.5 0 0 1 .329.938V10.5a1.5 1.5 0 0 1-1.5 1.5H14a2 2 0 1 1-4 0H5a2 2 0 1 1-3.998-.085A1.5 1.5 0 0 1 0 10.5zm1.294 7.456A1.999 1.999 0 0 1 4.732 11h5.536a2.01 2.01 0 0 1 .732-.732V3.5a.5.5 0 0 0-.5-.5h-9a.5.5 0 0 0-.5.5v7a.5.5 0 0 0 .294.456M12 10a2 2 0 0 1 1.732 1h.768a.5.5 0 0 0 .5-.5V8.35a.5.5 0 0 0-.11-.312l-1.48-1.85A.5.5 0 0 0 13.02 6H12zm-9 1a1 1 0 1 0 0 2 1 1 0 0 0 0-2m9 0a1 1 0 1 0 0 2 1 1 0 0 0 0-2" />
            </svg>
            NATIONWIDE SHIPPING</p>
        </div>

        <div>
          <p> <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-box2" viewBox="0 0 16 16">
              <path d="M2.95.4a1 1 0 0 1 .8-.4h8.5a1 1 0 0 1 .8.4l2.85 3.8a.5.5 0 0 1 .1.3V15a1 1 0 0 1-1 1H1a1 1 0 0 1-1-1V4.5a.5.5 0 0 1 .1-.3L2.95.4ZM7.5 1H3.75L1.5 4h6zm1 0v3h6l-2.25-3zM15 5H1v10h14z" />
            </svg>
            GENUINE,BOX PACKED PRODUCTS</p>
        </div>

        <div>
          <p><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-shield-shaded" viewBox="0 0 16 16">
              <path fill-rule="evenodd" d="M8 14.933a.615.615 0 0 0 .1-.025c.076-.023.174-.061.294-.118.24-.113.547-.29.893-.533a10.726 10.726 0 0 0 2.287-2.233c1.527-1.997 2.807-5.031 2.253-9.188a.48.48 0 0 0-.328-.39c-.651-.213-1.75-.56-2.837-.855C9.552 1.29 8.531 1.067 8 1.067zM5.072.56C6.157.265 7.31 0 8 0s1.843.265 2.928.56c1.11.3 2.229.655 2.887.87a1.54 1.54 0 0 1 1.044 1.262c.596 4.477-.787 7.795-2.465 9.99a11.775 11.775 0 0 1-2.517 2.453 7.159 7.159 0 0 1-1.048.625c-.28.132-.581.24-.829.24s-.548-.108-.829-.24a7.158 7.158 0 0 1-1.048-.625 11.777 11.777 0 0 1-2.517-2.453C1.928 10.487.545 7.169 1.141 2.692A1.54 1.54 0 0 1 2.185 1.43 62.456 62.456 0 0 1 5.072.56z" />
            </svg>
            COMPREHENSIVE BRAND SUPPORT</p>
        </div>
      </div>
    </div>
  </header>
  <!-- ======================main============================== -->
  <main class="cart">
    <h1>SHOPPING CART</h1>
    <hr style="color:black;  margin:0;">
    <br>
    <table class="carttable">
      <thead>
        <th>Product Name</th>
        <th>Unit Price</th>
        <th>Quantity</th>
        <th>Total</th>
      </thead>


      <?php if (isset($_SESSION['Finalcombo1'])) { array_push($_SESSION['stringArray'], "Redragon S101-BA-2 Wired Gaming Keyboard, Mouse, Headset, Mousepad Combo Set (4 in 1)"); array_push($_SESSION['intArray'], $_SESSION['Finalcombo1']);?>

        <tr>
          <td>Redragon S101-BA-2 Wired Gaming Keyboard,<br>Mouse, Headset, Mousepad Combo Set (4 in 1)</td>
          <td>Rs. 5163</td>
          <td><?php echo $_SESSION['Finalcombo1']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalcombo1'] * 5163);
              echo $_SESSION['Finalcombo1'] * 5163; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalcombo2'])) { array_push($_SESSION['stringArray'], "Redragon K585-BA RGB One-Handed Gaming Keyboard & M721-Pro RGB Gaming Mouse Combo Set (2 in 1)"); array_push($_SESSION['intArray'], $_SESSION['Finalcombo2']);
         ?>

        <tr>
          <td>Redragon K585-BA RGB One-Handed Gaming Keyboard <br>& M721-Pro RGB Gaming Mouse combo Set (2 in 1)</td>
          <td>Rs. 8701</td>
          <td><?php echo $_SESSION['Finalcombo2']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalcombo2'] * 8701);
              echo $_SESSION['Finalcombo2'] * 8701; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalcombo3'])) { array_push($_SESSION['stringArray'], "Redragon K552 RGB Keyboard & M607 Mouse Combo Set (2 in 1)"); array_push($_SESSION['intArray'], $_SESSION['Finalcombo3']);?>

        <tr>
          <td>Redragon K552 RGB Keyboard & M607 Mouse <br>Combo Set (2 in 1)</td>
          <td>Rs. 13216</td>
          <td><?php echo $_SESSION['Finalcombo3']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalcombo3'] * 13216);
              echo $_SESSION['Finalcombo3'] * 13216; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalcombo4'])) { array_push($_SESSION['stringArray'], "Redragon K552-BA-2 Keyboard, M601 Mouse, P001 XL Mousepad Combo Set (3 in 1)"); array_push($_SESSION['intArray'], $_SESSION['Finalcombo4']);?>

        <tr>
          <td>Redragon K552-BA-2 Keyboard, M601 Mouse, <br>P001 XL Mousepad Combo Set (3 in 1)</td>
          <td>Rs. 13216</td>
          <td><?php echo $_SESSION['Finalcombo4']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalcombo4'] * 13216);
              echo $_SESSION['Finalcombo4'] * 13216; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalcombo5'])) { array_push($_SESSION['stringArray'], "Redragon S129W Keyboard Mouse and Headsets Combo Set (3-in-1, White)"); array_push($_SESSION['intArray'], $_SESSION['Finalcombo5']);?>

        <tr>
          <td>Redragon S129W Keyboard Mouse and Headsets <br>Combo Set (3-in-1, White)</td>
          <td>Rs. 20200</td>
          <td><?php echo $_SESSION['Finalcombo5']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalcombo5'] * 20200);
              echo $_SESSION['Finalcombo5'] * 20200; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalheadset1'])) { array_push($_SESSION['stringArray'], "Redragon H120 ARES Wired Gaming Headset"); array_push($_SESSION['intArray'], $_SESSION['Finalheadset1']);?>

        <tr>
          <td>Redragon H120 ARES Wired Gaming Headset</td>
          <td>Rs. 2994</td>
          <td><?php echo $_SESSION['Finalheadset1']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalheadset1'] * 2994);
              echo $_SESSION['Finalheadset1'] * 2994; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalheadset2'])) { array_push($_SESSION['stringArray'], "Redragon H320 LAMIA 2 RGB 7.1 Gaming Headset with Noise-Cancellation (Black)"); array_push($_SESSION['intArray'], $_SESSION['Finalheadset2']);?>

        <tr>
          <td>Redragon H320W LAMIA 2 RGB 7.1 Gamign Headset with<br>Noise-Cancellation (White)</td>
          <td>Rs. 8493</td>
          <td><?php echo $_SESSION['Finalheadset2']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalheadset2'] * 8493);
              echo $_SESSION['Finalheadset2'] * 8493; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalheadset3'])) { array_push($_SESSION['stringArray'], "Redragon H350 PANDORA 2 RGB USB Gaming Headset (Black)"); array_push($_SESSION['intArray'], $_SESSION['Finalheadset3']);?>

        <tr>
          <td>Redragon H350 PANDORA 2 RGB USB Gaming Headset (Black)</td>
          <td>Rs. 8297</td>
          <td><?php echo $_SESSION['Finalheadset3']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalheadset3'] * 8297);
              echo $_SESSION['Finalheadset3'] * 8297; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalheadset4'])) { array_push($_SESSION['stringArray'], "Redragon H510W ZEUS 2 Wired Gaming Headset - 7.1 Surround Sound (White)"); array_push($_SESSION['intArray'], $_SESSION['Finalheadset4']);?>

        <tr>
          <td>Redragon H510W ZEUS 2 Wired Gaming Headset <br>- 7.1 Surround Sound (White)</td>
          <td>Rs. 12458</td>
          <td><?php echo $_SESSION['Finalheadset4']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalheadset4'] * 12458);
              echo $_SESSION['Finalheadset4'] * 12458; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalheadset5'])) { array_push($_SESSION['stringArray'], "Redragon H520 ICON Wired Gaming Headset - 7.1 Surround Sound"); array_push($_SESSION['intArray'], $_SESSION['Finalheadset5']);?>

        <tr>
          <td>Redragon H520 ICON Wired Gaming Headset <br>- 7.1 Surround Sound</td>
          <td>Rs. 14902</td>
          <td><?php echo $_SESSION['Finalheadset5']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalheadset5'] * 14902);
              echo $_SESSION['Finalheadset5'] * 14902; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalheadset6'])) { array_push($_SESSION['stringArray'], "Redragon H320W LAMIA 2 RGB 7.1 Gamign Headset with Noise-Cancellation (White)"); array_push($_SESSION['intArray'], $_SESSION['Finalheadset6']);?>

        <tr>
          <td>Redragon H320W LAMIA 2 RGB 7.1 Gamign Headset with <br>Noise-Cancellation (White)</td>
          <td>Rs. 8682</td>
          <td><?php echo $_SESSION['Finalheadset6']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalheadset6'] * 8682);
              echo $_SESSION['Finalheadset6'] * 8682; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalheadset7'])) { array_push($_SESSION['stringArray'], "Redragon H350W PANDORA 2 RGB USB Gaming Headset (White)"); array_push($_SESSION['intArray'], $_SESSION['Finalheadset7']);?>

        <tr>
          <td>Redragon H350W PANDORA 2 RGB USB Gaming Headset (White)</td>
          <td>Rs. 8750</td>
          <td><?php echo $_SESSION['Finalheadset7']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalheadset7'] * 8750);
              echo $_SESSION['Finalheadset7'] * 8750; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalheadset8'])) { array_push($_SESSION['stringArray'], "Redragon H301 SIREN 2 USB Gaming Headset"); array_push($_SESSION['intArray'], $_SESSION['Finalheadset8']);?>

        <tr>
          <td>Redragon H301 SIREN 2 USB Gaming Headset</td>
          <td>Rs. 8500</td>
          <td><?php echo $_SESSION['Finalheadset8']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalheadset8'] * 8500);
              echo $_SESSION['Finalheadset8'] * 8500; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalheadset9'])) { array_push($_SESSION['stringArray'], "Redragon H818 PELOPS Wireless Gaming Headset - 7.1 Surround Sound"); array_push($_SESSION['intArray'], $_SESSION['Finalheadset9']);?>

        <tr>
          <td>Redragon H818 PELOPS Wireless Gaming Headset <br>- 7.1 Surround Sound</td>
          <td>Rs. 13014</td>
          <td><?php echo $_SESSION['Finalheadset9']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalheadset9'] * 13014);
              echo $_SESSION['Finalheadset9'] * 13014; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalheadset10'])) { array_push($_SESSION['stringArray'], "Redragon H848 Bluetooth Wireless Gaming Headphone"); array_push($_SESSION['intArray'], $_SESSION['Finalheadset10']);?>

        <tr>
          <td>Redragon H848 Bluetooth Wireless Gaming Headphone</td>
          <td>Rs. 18856</td>
          <td><?php echo $_SESSION['Finalheadset10']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalheadset10'] * 18856);
              echo $_SESSION['Finalheadset10'] * 18856; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalheadset11'])) { array_push($_SESSION['stringArray'], "REDRAGON H386 DIOMEDES Gaming Headset"); array_push($_SESSION['intArray'], $_SESSION['Finalheadset11']);?>

        <tr>
          <td>REDRAGON H386 DIOMEDES Gaming Headset</td>
          <td>Rs. 9157</td>
          <td><?php echo $_SESSION['Finalheadset11']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalheadset11'] * 9157);
              echo $_SESSION['Finalheadset11'] * 9157; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalheadset12'])) { array_push($_SESSION['stringArray'], "Redragon H848 Bluetooth Wireless Gaming Headphone (Blue)"); array_push($_SESSION['intArray'], $_SESSION['Finalheadset12']);?>

        <tr>
          <td>Redragon H848 Bluetooth Wireless Gaming Headphone (Blue)</td>
          <td>Rs. 19888</td>
          <td><?php echo $_SESSION['Finalheadset12']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalheadset12'] * 19888);
              echo $_SESSION['Finalheadset12'] * 19888; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalheadset13'])) { array_push($_SESSION['stringArray'], "Redragon H380 Chiron RGB Gaming Headset - Black"); array_push($_SESSION['intArray'], $_SESSION['Finalheadset13']);?>

        <tr>
          <td>Redragon H380 Chiron RGB Gaming Headset - Black</td>
          <td>Rs. 10069</td>
          <td><?php echo $_SESSION['Finalheadset13']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalheadset13'] * 10069);
              echo $_SESSION['Finalheadset13'] * 10069; ?></td>
        </tr>

      <?php } ?>


      <?php if (isset($_SESSION['Finalkey1'])) { array_push($_SESSION['stringArray'], "Redragon K530 RGB Draconic Wireless Mechanical Gaming Keyboard with Tactile Brown Switches (Black)"); array_push($_SESSION['intArray'], $_SESSION['Finalkey1']);?>

        <tr>
          <td>Redragon K530 RGB Draconic Wireless Mechanical
          <br> Gaming Keyboard with Tactile Brown Switches (Black)</td>
          <td>Rs.  13800</td>
          <td><?php echo $_SESSION['Finalkey1']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalkey1'] *  13800);
              echo $_SESSION['Finalkey1'] *  13800; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalkey2'])) { array_push($_SESSION['stringArray'], "Redragon K530 RGB Draconic Wireless Mechanical Gaming Keyboard with Tactile Brown Switches (White)"); array_push($_SESSION['intArray'], $_SESSION['Finalkey2']);?>

        <tr>
          <td>Redragon K530 RGB Draconic Wireless Mechanical 
    <br>Gaming Keyboard with Tactile Brown Switches (White)</td>
          <td>Rs. 14430</td>
          <td><?php echo $_SESSION['Finalkey2']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalkey2'] * 14430);
              echo $_SESSION['Finalkey2'] * 14430; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalkey3'])) { array_push($_SESSION['stringArray'], "Redragon K630 Dragonborn RGB Mechanical Gaming Keyboard (White)"); array_push($_SESSION['intArray'], $_SESSION['Finalkey3']);?>

        <tr>
          <td>Redragon K630 Dragonborn RGB Mechanical 
    <br>Gaming Keyboard (White) </td>
          <td>Rs. 9175</td>
          <td><?php echo $_SESSION['Finalkey3']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalkey3'] * 9175);
              echo $_SESSION['Finalkey3'] * 9175; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalkey4'])) { array_push($_SESSION['stringArray'], "Redragon K552 RGB-1 KUMARA Full Anti Ghosting Mechanical Gaming Keyboard, 87 Keys"); array_push($_SESSION['intArray'], $_SESSION['Finalkey4']);?>

        <tr>
          <td>Redragon K552 RGB-1 KUMARA Full Anti
    Ghosting  <br>Mechanical Gaming Keyboard, 87 Keys </td>
          <td>Rs. 9932</td>
          <td><?php echo $_SESSION['Finalkey4']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalkey4'] * 9932);
              echo $_SESSION['Finalkey4'] * 9932; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalkey5'])) { array_push($_SESSION['stringArray'], "Redragon K512 SHIVA RGB Backlit Membrane Gaming Keyboard"); array_push($_SESSION['intArray'], $_SESSION['Finalkey5']);?>

        <tr>
          <td> Redragon K512 SHIVA RGB Backlit Membrane Gaming Keyboard</td>
          <td>Rs. 8365</td>
          <td><?php echo $_SESSION['Finalkey5']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalkey5'] * 8365);
              echo $_SESSION['Finalkey5'] * 8365; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalkey6'])) { array_push($_SESSION['stringArray'], "Redragon K582 SURARA RGB LED Backlit Mechanical Gaming Keyboard"); array_push($_SESSION['intArray'], $_SESSION['Finalkey6']);?>

        <tr>
          <td> Redragon K582 SURARA RGB LED Backlit 
   Mechanical  <br> Gaming Keyboard</td>
          <td>Rs. 11316</td>
          <td><?php echo $_SESSION['Finalkey6']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalkey6'] * 11316);
              echo $_SESSION['Finalkey6'] * 11316; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalkey7'])) { array_push($_SESSION['stringArray'], "Redragon K556 DEVARAJAS RGB Mechanical Gaming Keyboard with Brown Switches"); array_push($_SESSION['intArray'], $_SESSION['Finalkey7']);?>

        <tr>
          <td> Redragon K556 DEVARAJAS RGB Mechanical Gaming 
    <br>Keyboard with Brown Switches</td>
          <td>Rs. 14976</td>
          <td><?php echo $_SESSION['Finalkey7']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalkey7'] * 14976);
              echo $_SESSION['Finalkey7'] * 14976; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalkey8'])) { array_push($_SESSION['stringArray'], "Redragon K568 DARK AVENGER RGB Backlit Mechanical Gaming Keyboard, 87 Keys"); array_push($_SESSION['intArray'], $_SESSION['Finalkey8']);?>

        <tr>
          <td> Redragon K568 DARK AVENGER RGB Backlit Mechanical
    <br> Gaming Keyboard, 87 Keys</td>
          <td>Rs. 8756</td>
          <td><?php echo $_SESSION['Finalkey8']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalkey8'] * 8756);
              echo $_SESSION['Finalkey8'] * 8756; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalkey9'])) { array_push($_SESSION['stringArray'], "Redragon K585 DITI One-Handed RGB Mechanical Wired Gaming Keyboard with Blue Switches"); array_push($_SESSION['intArray'], $_SESSION['Finalkey9']);?>

        <tr>
          <td>Redragon K585 DITI One-Handed RGB Mechanical Wired 
    <br>Gaming Keyboard with Blue Switches </td>
          <td>Rs. 7405</td>
          <td><?php echo $_SESSION['Finalkey9']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalkey9'] * 7405);
              echo $_SESSION['Finalkey9'] * 7405; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalkey10'])) { array_push($_SESSION['stringArray'], "Redragon K552 KUMARA RGB Mechanical Gaming Keyboard (White)"); array_push($_SESSION['intArray'], $_SESSION['Finalkey10']);?>

        <tr>
          <td> Redragon K552 KUMARA RGB Mechanical 
    Gaming <br>Keyboard (White)</td>
          <td>Rs. 10358</td>
          <td><?php echo $_SESSION['Finalkey10']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalkey10'] * 10358);
              echo $_SESSION['Finalkey10'] * 10358; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalkey11'])) { array_push($_SESSION['stringArray'], "Redragon K580 VATA RGB Backlit Mechanical Gaming Keyboard"); array_push($_SESSION['intArray'], $_SESSION['Finalkey11']);?>

        <tr>
          <td>Redragon K580 VATA RGB Backlit Mechanical Gaming Keyboard </td>
          <td>Rs. 14566</td>
          <td><?php echo $_SESSION['Finalkey11']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalkey11'] * 14566);
              echo $_SESSION['Finalkey11'] * 14566; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalkey12'])) { array_push($_SESSION['stringArray'], "Redragon K589 SHRAPNEL RGB Backlit Mechanical Gaming Keyboard 104 Keys Anti-ghosting Red Switches"); array_push($_SESSION['intArray'], $_SESSION['Finalkey12']);?>

        <tr>
          <td>Redragon K589 SHRAPNEL RGB Backlit Mechanical  Gaming <br>Keyboard 
   104 Keys Anti-ghosting Red Switches </td>
          <td>Rs. 11695</td>
          <td><?php echo $_SESSION['Finalkey12']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalkey12'] * 11695);
              echo $_SESSION['Finalkey12'] * 11695; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalkey13'])) { array_push($_SESSION['stringArray'], "Redragon K621 HORUS TKL RGB Wireless Mechanical Gaming Keyboard"); array_push($_SESSION['intArray'], $_SESSION['Finalkey13']);?>

        <tr>
          <td>Redragon K621 HORUS TKL RGB Wireless Mechanical
    <br> Gaming Keyboard </td>
          <td>Rs. 16839</td>
          <td><?php echo $_SESSION['Finalkey13']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalkey13'] * 16839);
              echo $_SESSION['Finalkey13'] * 16839; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalkey14'])) { array_push($_SESSION['stringArray'], "Redragon K596 VISHNU RGB Wireless Mechanical Gaming Keyboard, 87 Keys TKL"); array_push($_SESSION['intArray'], $_SESSION['Finalkey14']);?>

        <tr>
          <td> Redragon K596 VISHNU RGB Wireless Mechanical 
    <br>Gaming Keyboard, 87 Keys TKL</td>
          <td>Rs. 17194</td>
          <td><?php echo $_SESSION['Finalkey14']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalkey14'] * 17194);
              echo $_SESSION['Finalkey14'] * 17194; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalkey15'])) { array_push($_SESSION['stringArray'], "Redragon K616 FIZZ PRO RGB Mechanical Gaming Keyboard (Black)"); array_push($_SESSION['intArray'], $_SESSION['Finalkey15']);?>

        <tr>
          <td> Redragon K616 FIZZ PRO RGB Mechanical 
    Gaming Keyboard (Black)</td>
          <td>Rs. 11707</td>
          <td><?php echo $_SESSION['Finalkey15']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalkey15'] * 11707);
              echo $_SESSION['Finalkey15'] * 11707; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalkey16'])) { array_push($_SESSION['stringArray'], "Redragon K557 KALA RGB Backlit Waterproof Mechanical Gaming Keyboard"); array_push($_SESSION['intArray'], $_SESSION['Finalkey16']);?>

        <tr>
          <td>Redragon K557 KALA RGB Backlit Waterproof Mechanical
    <br> Gaming Keyboard </td>
          <td>Rs. 11957</td>
          <td><?php echo $_SESSION['Finalkey16']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalkey16'] * 11957);
              echo $_SESSION['Finalkey16'] * 11957; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalmouse1'])) { array_push($_SESSION['stringArray'], "Redragon M711 COBRA Gaming Mouse with 16.8 Million RGB, 10,000 DPI Adjustable, 7 Programmable Buttons (Black)"); array_push($_SESSION['intArray'], $_SESSION['Finalmouse1']);?>

        <tr>
          <td>edragon M711 COBRA Gaming Mouse
          with 16.8 Million RGB, <br>
          10,000 DPI Adjustable, 7 Programmable3Buttons (Black) </td>
          <td>Rs. 4767</td>
          <td><?php echo $_SESSION['Finalmouse1']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalmouse1'] * 4767);
              echo $_SESSION['Finalmouse1'] * 4767; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalmouse2'])) { array_push($_SESSION['stringArray'], "Redragon M607 GRIFFIN RGB Black 7200 DPI Gaming Mouse"); array_push($_SESSION['intArray'], $_SESSION['Finalmouse2']);?>

        <tr>
          <td> Redragon M607 GRIFFIN RGB Black 7200 DPI Gaming Mouse</td>
          <td>Rs. 4179</td>
          <td><?php echo $_SESSION['Finalmouse2']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalmouse2'] * 4179);
              echo $_SESSION['Finalmouse2'] * 4179; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalmouse3'])) { array_push($_SESSION['stringArray'], "Redragon M601 CENTROPHORUS RGB Gaming Mouse, 6 Programmable Buttons"); array_push($_SESSION['intArray'], $_SESSION['Finalmouse3']);?>

        <tr>
          <td> Redragon M601 CENTROPHORUS RGB Gaming Mouse,<br> 6 Programmable Buttons</td>
          <td>Rs. 3802</td>
          <td><?php echo $_SESSION['Finalmouse3']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalmouse3'] * 3802);
              echo $_SESSION['Finalmouse3'] * 3802; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalmouse4'])) { array_push($_SESSION['stringArray'], "Redragon M690 MIRAGE 4800 DPI, 8 Buttons Wireless Gaming Mouse"); array_push($_SESSION['intArray'], $_SESSION['Finalmouse4']);?>

        <tr>
          <td> Redragon M690 MIRAGE 4800 DPI, 8 Buttons Wireless <br>Gaming Mouse</td>
          <td>Rs. 4626</td>
          <td><?php echo $_SESSION['Finalmouse4']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalmouse4'] * 4626);
              echo $_SESSION['Finalmouse4'] * 4626; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalmouse5'])) { array_push($_SESSION['stringArray'], "Redragon M602-1 NEMEANLION 2 RGB 7200DPI, 7 Programmable Buttons Gaming Mouse"); array_push($_SESSION['intArray'], $_SESSION['Finalmouse5']);?>

        <tr>
          <td> Redragon M602-1 NEMEANLION 2 RGB 7200DPI, <br>7 Programmable Buttons Gaming Mouse</td>
          <td>Rs. 4075</td>
          <td><?php echo $_SESSION['Finalmouse5']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalmouse5'] * 4075);
              echo $_SESSION['Finalmouse5'] * 4075; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalmouse6'])) { array_push($_SESSION['stringArray'], "Redragon M721-PRO LONEWOLF 2 RGB Wired Gaming mouse"); array_push($_SESSION['intArray'], $_SESSION['Finalmouse6']);?>

        <tr>
          <td>Redragon M721-PRO LONEWOLF 2 RGB Wired Gaming mouse </td>
          <td>Rs. 4998</td>
          <td><?php echo $_SESSION['Finalmouse6']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalmouse6'] * 4998);
              echo $_SESSION['Finalmouse6'] * 4998; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalmouse7'])) { array_push($_SESSION['stringArray'], "Redragon M808W STORM LUNAR Lightweight RGB Gaming Mouse with 12400 DPI, 7 Programmable Buttons (White)"); array_push($_SESSION['intArray'], $_SESSION['Finalmouse7']);?>

        <tr>
          <td>Redragon M808W STORM LUNAR Lightweight RGB Gaming Mouse 
    <br>with 12400 DPI, 7 Programmable Buttons (White) </td>
          <td>Rs. 6128</td>
          <td><?php echo $_SESSION['Finalmouse7']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalmouse7'] * 6128);
              echo $_SESSION['Finalmouse7'] * 6128; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalmouse8'])) { array_push($_SESSION['stringArray'], "Redragon M710 Memeanlion Chroma RGB Gaming Mouse"); array_push($_SESSION['intArray'], $_SESSION['Finalmouse8']);?>

        <tr>
          <td>Redragon M710 Memeanlion Chroma RGB Gaming Mouse </td>
          <td>Rs. 4320</td>
          <td><?php echo $_SESSION['Finalmouse8']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalmouse8'] * 4320);
              echo $_SESSION['Finalmouse8'] * 4320; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalmouse9'])) { array_push($_SESSION['stringArray'], "Redragon M988 RGB STORM ELITE Gaming Mouse 32000 DPI 7 Programmable Buttons (Black)"); array_push($_SESSION['intArray'], $_SESSION['Finalmouse9']);?>

        <tr>
          <td> Redragon M988 RGB STORM ELITE Gaming Mouse 32000 <br> DPI 7 Programmable Buttons (Black)</td>
          <td>Rs. 7150</td>
          <td><?php echo $_SESSION['Finalmouse9']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalmouse9'] * 7150);
              echo $_SESSION['Finalmouse9'] * 7150; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalmouse10'])) { array_push($_SESSION['stringArray'], "Redragon M686 VAMPIRE ELITE Wireless Gaming Mouse"); array_push($_SESSION['intArray'], $_SESSION['Finalmouse10']);?>

        <tr>
          <td> Redragon M686 VAMPIRE ELITE Wireless Gaming Mouse</td>
          <td>Rs. 10005</td>
          <td><?php echo $_SESSION['Finalmouse10']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalmouse10'] * 10005);
              echo $_SESSION['Finalmouse10'] * 10005; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalmouse11'])) { array_push($_SESSION['stringArray'], "Redragon M719 INVADER Gaming Mouse with Fire Button, 7 Programmable Buttons, RGB Backlit, 10,000 DPI"); array_push($_SESSION['intArray'], $_SESSION['Finalmouse11']);?>

        <tr>
          <td>Redragon M719 INVADER Gaming Mouse with Fire Button, <br>7 Programmable Buttons, RGB Backlit, 10,000 DPI </td>
          <td>Rs. 4039</td>
          <td><?php echo $_SESSION['Finalmouse11']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalmouse11'] * 4039);
              echo $_SESSION['Finalmouse11'] * 4039; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalmouse12'])) { array_push($_SESSION['stringArray'], "Redragon M711 COBRA RGB Gaming Mouse (White)"); array_push($_SESSION['intArray'], $_SESSION['Finalmouse12']);?>

        <tr>
          <td> Redragon M711 COBRA RGB Gaming Mouse (White)</td>
          <td>Rs. 5701</td>
          <td><?php echo $_SESSION['Finalmouse12']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalmouse12'] * 5701);
              echo $_SESSION['Finalmouse12'] * 5701; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalmouse13'])) { array_push($_SESSION['stringArray'], "Redragon M703 GERBERUS, 7200DPI, 6 Programmable Wired Gaming Mouse"); array_push($_SESSION['intArray'], $_SESSION['Finalmouse13']);?>

        <tr>
          <td>Redragon M703 GERBERUS, 7200DPI, 6 Programmable <br>Wired Gaming Mouse </td>
          <td>Rs. 3012</td>
          <td><?php echo $_SESSION['Finalmouse13']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalmouse13'] * 3012);
              echo $_SESSION['Finalmouse13'] * 3012; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalmouse14'])) { array_push($_SESSION['stringArray'], "Redragon M907 INSPIRIT 14400 DPI Gaming Mouse"); array_push($_SESSION['intArray'], $_SESSION['Finalmouse14']);?>

        <tr>
          <td> Redragon M907 INSPIRIT 14400 DPI Gaming Mouse</td>
          <td>Rs. 4790</td>
          <td><?php echo $_SESSION['Finalmouse14']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalmouse14'] * 4790);
              echo $_SESSION['Finalmouse14'] * 4790; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalmouse15'])) { array_push($_SESSION['stringArray'], "Redragon M907 INSPIRIT 14400 DPI Gaming Mouse"); array_push($_SESSION['intArray'], $_SESSION['Finalmouse15']);?>

        <tr>
          <td>Redragon M907 INSPIRIT 14400 DPI Gaming Mouse </td>
          <td>Rs. 7862</td>
          <td><?php echo $_SESSION['Finalmouse15']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalmouse15'] * 7862);
              echo $_SESSION['Finalmouse15'] * 7862; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalmouse16'])) { array_push($_SESSION['stringArray'], "Redragon M910 RANGER CHROMA Gaming Mouse with 16.8 Million RGB Backlit, 9 Programmable Buttons, Up to 12400 DPI User Adjustable"); array_push($_SESSION['intArray'], $_SESSION['Finalmouse16']);?>

        <tr>
          <td>Redragon M910 RANGER CHROMA Gaming Mouse  with <br> 16.8 Million RGB Backlit, 
   9 Programmable Buttons,  <br>Up to 12400 DPI User Adjustable </td>
          <td>Rs. 5767</td>
          <td><?php echo $_SESSION['Finalmouse16']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalmouse16'] * 5767);
              echo $_SESSION['Finalmouse16'] * 5767; ?></td>
        </tr>

      <?php } ?>


      <?php if (isset($_SESSION['Finalmousepad1'])) { array_push($_SESSION['stringArray'], "Redragon P016 PISCES Gaming Mouse pad"); array_push($_SESSION['intArray'], $_SESSION['Finalmousepad1']);?>

        <tr>
          <td> Redragon P016 PISCES Gaming Mouse pad</td>
          <td>Rs. 1095</td>
          <td><?php echo $_SESSION['Finalmousepad1']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalmousepad1'] * 1095);
              echo $_SESSION['Finalmousepad1'] * 1095; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalmousepad2'])) { array_push($_SESSION['stringArray'], "Redragon P001 ARCHELON Gaming Mouse Pad"); array_push($_SESSION['intArray'], $_SESSION['Finalmousepad2']);?>

        <tr>
          <td> Redragon P001 ARCHELON Gaming Mouse Pad</td>
          <td>Rs. 1448</td>
          <td><?php echo $_SESSION['Finalmousepad2']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalmousepad2'] * 1448);
              echo $_SESSION['Finalmousepad2'] * 1448; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalmousepad3'])) { array_push($_SESSION['stringArray'], "Redragon P012 CAPRICORN Mouse Pad with Stitched Edges"); array_push($_SESSION['intArray'], $_SESSION['Finalmousepad3']);?>

        <tr>
          <td>Redragon P012 CAPRICORN Mouse Pad with Stitched Edges </td>
          <td>Rs. 1564</td>
          <td><?php echo $_SESSION['Finalmousepad3']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalmousepad3'] * 1564);
              echo $_SESSION['Finalmousepad3'] * 1564; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalmousepad4'])) { array_push($_SESSION['stringArray'], "Redragon P018 TAURUS Gaming Mouse Pad Large Extended"); array_push($_SESSION['intArray'], $_SESSION['Finalmousepad4']);?>

        <tr>
          <td> Redragon P018 TAURUS Gaming Mouse Pad Large Extended</td>
          <td>Rs. 2566</td>
          <td><?php echo $_SESSION['Finalmousepad4']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalmousepad4'] * 2566);
              echo $_SESSION['Finalmousepad4'] * 2566; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalmousepad5'])) { array_push($_SESSION['stringArray'], "Redragon P006A KUNLUN Gaming Mouse Pad Large Sized"); array_push($_SESSION['intArray'], $_SESSION['Finalmousepad5']);?>

        <tr>
          <td>Redragon P006A KUNLUN Gaming Mouse Pad Large Sized </td>
          <td>Rs. 3513</td>
          <td><?php echo $_SESSION['Finalmousepad5']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalmousepad5'] * 3513);
              echo $_SESSION['Finalmousepad5'] * 3513; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalmousepad6'])) { array_push($_SESSION['stringArray'], "Redragon P003 SUZAKU Huge Gaming Mouse Pad Mat"); array_push($_SESSION['intArray'], $_SESSION['Finalmousepad6']);?>

        <tr>
          <td>Redragon P003 SUZAKU Huge Gaming Mouse Pad Mat </td>
          <td>Rs. 2353</td>
          <td><?php echo $_SESSION['Finalmousepad6']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalmousepad6'] * 2353);
              echo $_SESSION['Finalmousepad6'] * 2353; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalmousepad7'])) { array_push($_SESSION['stringArray'], "Redragon P029 FLICK S PC Mousepad"); array_push($_SESSION['intArray'], $_SESSION['Finalmousepad7']);?>

        <tr>
          <td>Redragon P029 FLICK S PC Mousepad </td>
          <td>Rs. 1381</td>
          <td><?php echo $_SESSION['Finalmousepad7']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalmousepad7'] * 1381);
              echo $_SESSION['Finalmousepad7'] * 1381; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalmousepad8'])) { array_push($_SESSION['stringArray'], "Redragon P026 PLUTO RGB"); array_push($_SESSION['intArray'], $_SESSION['Finalmousepad8']);?>

        <tr>
          <td>Redragon P026 PLUTO RGB </td>
          <td>Rs. 4033</td>
          <td><?php echo $_SESSION['Finalmousepad8']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalmousepad8'] * 4033);
              echo $_SESSION['Finalmousepad8'] * 4033; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalmousepad9'])) { array_push($_SESSION['stringArray'], "Redragon P037 METEOR Wristpad (Large)"); array_push($_SESSION['intArray'], $_SESSION['Finalmousepad9']);?>

        <tr>
          <td> Redragon P037 METEOR Wristpad (Large)</td>
          <td>Rs. 2866</td>
          <td><?php echo $_SESSION['Finalmousepad9']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalmousepad9'] * 2866);
              echo $_SESSION['Finalmousepad9'] * 2866; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalmousepad10'])) { array_push($_SESSION['stringArray'], "Redragon P036 METEOR Wrist Rest Pad (Medium)"); array_push($_SESSION['intArray'], $_SESSION['Finalmousepad10']);?>

        <tr>
          <td> Redragon P036 METEOR Wrist Rest Pad (Medium)</td>
          <td>Rs. 2328</td>
          <td><?php echo $_SESSION['Finalmousepad10']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalmousepad10'] * 2328);
              echo $_SESSION['Finalmousepad10'] * 2328; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalmousepad11'])) { array_push($_SESSION['stringArray'], "Redragon P040 Flick 3XL Mouse Mat (1219 x 610 mm)"); array_push($_SESSION['intArray'], $_SESSION['Finalmousepad11']);?>

        <tr>
          <td>Redragon P040 Flick 3XL Mouse Mat (1219 x 610 mm) </td>
          <td>Rs. 6037</td>
          <td><?php echo $_SESSION['Finalmousepad11']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalmousepad11'] * 6037);
              echo $_SESSION['Finalmousepad11'] * 6037; ?></td>
        </tr>

      <?php } ?>

      <?php if (isset($_SESSION['Finalstand1'])) { array_push($_SESSION['stringArray'], "REDRAGON HA300 SCEPTER RGB PRO GAMING HEADSET STAND"); array_push($_SESSION['intArray'], $_SESSION['Finalstand1']);?>

        <tr>
          <td>REDRAGON HA300 SCEPTER RGB PRO GAMING HEADSET STAND </td>
          <td>Rs. 5163</td>
          <td><?php echo $_SESSION['Finalstand1']; ?></td>
          <td><?php $_SESSION['PageTotal'] += ($_SESSION['Finalstand1'] * 5163);
              echo $_SESSION['Finalstand1'] * 5163; ?></td>
        </tr>

      <?php } ?>





    </table>
    <div class="d-flex justify-content-between">
      <div> <a href="index.php"><button class="stbutton">CONTINUE SHOPPING</button></a></div>
      <div><a href="clearCart.php" class="stbutton">CLEAR CART</a></div>
    </div>

    <br>
    <a href="checkout.php" class="stbutton">PROCEED TO CHECKOUT</a>
    <br>

  </main>

  <!-- footer -->
  <footer>
    <div>
      <hr style="color:#8b8989;  margin:0;">
    </div>
    <div class="d-flex flex-wrap p-3 box6">

      <div class="flex-fill">
        <p>INFO@REDRAGONZONE.PK</p>
        <div class="top">
          <a href="index.php"><img src="picc/redragon.png" width="210px" height="190px" alt=""></a>
        </div>
        <p>CUSTOMER CARE CENTER</p>
        <p>314 - AL-HAFEEZ SHOPPING MALL, GULBERG III,<br>
          MAIN BOULEVARD, LAHORE - PAKISTAN</p>
        <p>(+92) 3111 000 135</p>
      </div>
      <div class="flex-fill">
        <p>PRODUCTS</p>
        <ul>
          <a href="keyboard.php">
            <li>KEYBOARD</li>
          </a>

          <a href="mouse.php">
            <li>MOUSE</li>
          </a>

          <a href="combo.php">
            <li>COMBO</li>
          </a>

          <a href="mousepad.php">
            <li>MOUSE PAD</li>
          </a>

          <a href="headset.php">
            <li>HEADSET</li>
          </a>

          <a href="stand1.php">
            <li>ACCESSORIES</li>
          </a>

        </ul>
      </div>

      <div class="flex-fill">
        <p> INFORMATION</p>
        <ul>
          <li> <a href="Warranty.php">WARRANTY POLICY</a></li>
          <li> <a href="payment.php">PAYMENT INFO</a></li>
          <li> <a href="return.php">RETURN POLICY</a></li>
        </ul>

      </div>

      <div>
        <p>JOIN FOR EXCLUSIVE BENEFITS</p>
        <form action="/action_page.php">
          <div class="d-flex box7">

            <input type="email" class="form-control" id="email" placeholder="Your email address" name="email">

            <button type="submit" class="btn btn-danger ">Submit</button>
          </div>
        </form>
      </div>

    </div>
  </footer>
  </header>
</body>

</html>