<?php include("Connection.php");

$ComboPricesResult = mysqli_query($_SESSION["conn"], "SELECT * FROM product_catalogue WHERE Product_Category = 'COMBO';");
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <link rel="shortcut icon" href="//redragonzone.pk/cdn/shop/files/Redragon-pakistan-380x380_32x32.png?v=1615319941"
        type="image/png">
    <meta charset="UTF-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport"
        content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=0" />
    <meta name='HandheldFriendly' content='True'>
    <meta name='MobileOptimized' content='375'>
    <meta http-equiv="cleartype" content="on">
    <meta name="theme-color" content="#e60012">
    <link rel="canonical" href="https://redragonzone.pk/collections/gaming-combo-price-in-pakistan" />

    <title>Redragon Gaming Combo Set Price - REDRAGON PAKISTAN</title>
    <meta name="description"
        content="Buy Redragon Combo Sets in Pakistan. Latest &amp; wide range of gaming mouse, keyboards combo sets at best prices. Nationwide shipping. Cash on delivery.">





    <meta property="og:site_name" content="RedragonZone.PK">
    <meta property="og:url" content="https://redragonzone.pk/collections/gaming-combo-price-in-pakistan">
    <meta property="og:title" content="COMBO">
    <meta property="og:type" content="product.group">
    <meta property="og:description"
        content="Buy Redragon Combo Sets in Pakistan. Latest &amp; wide range of gaming mouse, keyboards combo sets at best prices. Nationwide shipping. Cash on delivery.">





    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="COMBO">
    <meta name="twitter:description"
        content="Buy Redragon Combo Sets in Pakistan. Latest &amp; wide range of gaming mouse, keyboards combo sets at best prices. Nationwide shipping. Cash on delivery.">


    <link rel="canonical" href="https://redragonzone.pk/collections/gaming-combo-price-in-pakistan" />
    <link rel="preconnect dns-prefetch" href="https://cdn.shopify.com">
    <link rel="preconnect dns-prefetch" href="https://v.shopify.com">
    <link rel="preconnect dns-prefetch" href="https://cdn.shopifycloud.com">
    <link rel="preload" href="//redragonzone.pk/cdn/shop/t/5/assets/styles.scss.css?v=124980048740926497851703348189"
        as="style">
    <link rel="preload" href="//redragonzone.pk/cdn/shop/t/5/assets/themes.scss.css?v=58698413482323688401703348188"
        as="style">
    <link rel="preload" href="//redragonzone.pk/cdn/shop/t/5/assets/global.scss.css?v=125076772181967553861703348189"
        as="style">

    <link rel="preload" href="//redragonzone.pk/cdn/shop/t/5/assets/vendor.css?v=87675270813913945401581608572"
        as="style">
    <link rel="preload" href="//redragonzone.pk/cdn/shop/t/5/assets/arenafont.css?v=75023525835272796541703348189"
        as="style">

    <!-- header-css-file  ================================================== -->

    <link href="//redragonzone.pk/cdn/shop/t/5/assets/arenafont.css?v=75023525835272796541703348189" rel="stylesheet"
        type="text/css" media="all">
    <link href="//redragonzone.pk/cdn/shop/t/5/assets/vendor.css?v=87675270813913945401581608572" rel="stylesheet"
        type="text/css" media="all">


    <link href="//redragonzone.pk/cdn/shop/t/5/assets/styles.scss.css?v=124980048740926497851703348189" rel="stylesheet"
        type="text/css" media="all">
    <link href="//redragonzone.pk/cdn/shop/t/5/assets/themes.scss.css?v=58698413482323688401703348188" rel="stylesheet"
        type="text/css" media="all">


    <link href="//redragonzone.pk/cdn/shop/t/5/assets/global.scss.css?v=125076772181967553861703348189" rel="stylesheet"
        type="text/css" media="all">
    <link href="https://fonts.googleapis.com/css?family=Caveat:300,400,500,600,700&display=swap" rel='stylesheet'
        type='text/css'>


    <link href="//redragonzone.pk/cdn/shop/t/5/assets/bc_wl_cp_style.scss.css?v=172879242641943902421581608571"
        rel="stylesheet" type="text/css" media="all" />
    <script crossorigin="anonymous"
        src="//redragonzone.pk/cdn/shop/t/5/assets/lazysizes.min.js?v=68594089956960822201581608511" async></script>
    <script crossorigin="anonymous"
        src="//redragonzone.pk/cdn/shop/t/5/assets/jquery-1.11.0.min.js?v=58211863146907186831581608499"></script>
    <script crossorigin="anonymous"
        src="//redragonzone.pk/cdn/shop/t/5/assets/cookies.js?v=124176070287646777851581608481"></script>


    <script crossorigin="anonymous"
        src="//redragonzone.pk/cdn/shop/t/5/assets/bootstrap.4x.min.js?v=35271929837704850651581608476" defer></script>


    <meta id="shopify-digital-wallet" name="shopify-digital-wallet" content="/33233961099/digital_wallets/dialog">
    <link rel="alternate" type="application/atom+xml" title="Feed"
        href="/collections/gaming-combo-price-in-pakistan.atom" />
    <link rel="alternate" type="application/json+oembed"
        href="https://redragonzone.pk/collections/gaming-combo-price-in-pakistan.oembed">


    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="icon" href="picc/redragon.png" type="image/x-icon">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

    <link rel="stylesheet" href="smile.css">
</head>


<body data-rtl="false" class="templateCollection mobile-bar-outside category-mode-false cata-grid-4 lazy-loading-img ">

    <header>
        <div class="top-bar-list  ">

            <p> DUE TO LARGE NUMBER OF ORDERS, PLEASE EXPECT 1 TO 2 DAYS DELAY IN DELIVERY</p>

        </div>


        <div class="d-flex justify-content-between top-bar-right">
            <div class="d-flex hello">
                <div>
                    <a href="https://redragonzone.pk/"> <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20"
                            fill="currentColor" class="bi bi-facebook" viewBox="0 0 16 16">
                            <path
                                d="M16 8.049c0-4.446-3.582-8.05-8-8.05C3.58 0-.002 3.603-.002 8.05c0 4.017 2.926 7.347 6.75 7.951v-5.625h-2.03V8.05H6.75V6.275c0-2.017 1.195-3.131 3.022-3.131.876 0 1.791.157 1.791.157v1.98h-1.009c-.993 0-1.303.621-1.303 1.258v1.51h2.218l-.354 2.326H9.25V16c3.824-.604 6.75-3.934 6.75-7.951" />
                        </svg></a>
                </div>

                <div>
                    <a href="https://redragonzone.pk/"> <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20"
                            fill="currentColor" class="bi bi-twitter" viewBox="0 0 16 16">
                            <path
                                d="M5.026 15c6.038 0 9.341-5.003 9.341-9.334 0-.14 0-.282-.006-.422A6.685 6.685 0 0 0 16 3.542a6.658 6.658 0 0 1-1.889.518 3.301 3.301 0 0 0 1.447-1.817 6.533 6.533 0 0 1-2.087.793A3.286 3.286 0 0 0 7.875 6.03a9.325 9.325 0 0 1-6.767-3.429 3.289 3.289 0 0 0 1.018 4.382A3.323 3.323 0 0 1 .64 6.575v.045a3.288 3.288 0 0 0 2.632 3.218 3.203 3.203 0 0 1-.865.115 3.23 3.23 0 0 1-.614-.057 3.283 3.283 0 0 0 3.067 2.277A6.588 6.588 0 0 1 .78 13.58a6.32 6.32 0 0 1-.78-.045A9.344 9.344 0 0 0 5.026 15" />
                        </svg></a>
                </div>

                <div>
                    <a href="https://redragonzone.pk/"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20"
                            fill="currentColor" class="bi bi-pinterest" viewBox="0 0 16 16">
                            <path
                                d="M8 0a8 8 0 0 0-2.915 15.452c-.07-.633-.134-1.606.027-2.297.146-.625.938-3.977.938-3.977s-.239-.479-.239-1.187c0-1.113.645-1.943 1.448-1.943.682 0 1.012.512 1.012 1.127 0 .686-.437 1.712-.663 2.663-.188.796.4 1.446 1.185 1.446 1.422 0 2.515-1.5 2.515-3.664 0-1.915-1.377-3.254-3.342-3.254-2.276 0-3.612 1.707-3.612 3.471 0 .688.265 1.425.595 1.826a.24.24 0 0 1 .056.23c-.061.252-.196.796-.222.907-.035.146-.116.177-.268.107-1-.465-1.624-1.926-1.624-3.1 0-2.523 1.834-4.84 5.286-4.84 2.775 0 4.932 1.977 4.932 4.62 0 2.757-1.739 4.976-4.151 4.976-.811 0-1.573-.421-1.834-.919l-.498 1.902c-.181.695-.669 1.566-.995 2.097A8 8 0 1 0 8 0" />
                        </svg></a>
                </div>
                <div>
                    <a href="https://redragonzone.pk/"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20"
                            fill="currentColor" class="bi bi-instagram" viewBox="0 0 16 16">
                            <path
                                d="M8 0C5.829 0 5.556.01 4.703.048 3.85.088 3.269.222 2.76.42a3.917 3.917 0 0 0-1.417.923A3.927 3.927 0 0 0 .42 2.76C.222 3.268.087 3.85.048 4.7.01 5.555 0 5.827 0 8.001c0 2.172.01 2.444.048 3.297.04.852.174 1.433.372 1.942.205.526.478.972.923 1.417.444.445.89.719 1.416.923.51.198 1.09.333 1.942.372C5.555 15.99 5.827 16 8 16s2.444-.01 3.298-.048c.851-.04 1.434-.174 1.943-.372a3.916 3.916 0 0 0 1.416-.923c.445-.445.718-.891.923-1.417.197-.509.332-1.09.372-1.942C15.99 10.445 16 10.173 16 8s-.01-2.445-.048-3.299c-.04-.851-.175-1.433-.372-1.941a3.926 3.926 0 0 0-.923-1.417A3.911 3.911 0 0 0 13.24.42c-.51-.198-1.092-.333-1.943-.372C10.443.01 10.172 0 7.998 0h.003zm-.717 1.442h.718c2.136 0 2.389.007 3.232.046.78.035 1.204.166 1.486.275.373.145.64.319.92.599.28.28.453.546.598.92.11.281.24.705.275 1.485.039.843.047 1.096.047 3.231s-.008 2.389-.047 3.232c-.035.78-.166 1.203-.275 1.485a2.47 2.47 0 0 1-.599.919c-.28.28-.546.453-.92.598-.28.11-.704.24-1.485.276-.843.038-1.096.047-3.232.047s-2.39-.009-3.233-.047c-.78-.036-1.203-.166-1.485-.276a2.478 2.478 0 0 1-.92-.598 2.48 2.48 0 0 1-.6-.92c-.109-.281-.24-.705-.275-1.485-.038-.843-.046-1.096-.046-3.233 0-2.136.008-2.388.046-3.231.036-.78.166-1.204.276-1.486.145-.373.319-.64.599-.92.28-.28.546-.453.92-.598.282-.11.705-.24 1.485-.276.738-.034 1.024-.044 2.515-.045v.002zm4.988 1.328a.96.96 0 1 0 0 1.92.96.96 0 0 0 0-1.92zm-4.27 1.122a4.109 4.109 0 1 0 0 8.217 4.109 4.109 0 0 0 0-8.217zm0 1.441a2.667 2.667 0 1 1 0 5.334 2.667 2.667 0 0 1 0-5.334" />
                        </svg></a>
                </div>


            </div>

            <div>
                <span>Need help?</span>
                <a href="mailto:info@redragonzone.pk">info@redragonzone.pk</a>
            </div>

        </div>

        <div class="d-flex justify-content-between  align-items-center box1 ">
            <div><img src="picc/redragon.png" width="130px" height="90px" alt=""></div>

            <div>
      <a href="cart.php"> <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-cart"
        viewBox="0 0 16 16">
        <path
          d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .491.592l-1.5 8A.5.5 0 0 1 13 12H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5M3.102 4l1.313 7h8.17l1.313-7H3.102zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4m7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4m-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2m7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2" />
      </svg></a>
  
    </div>
        </div>


        <div>
            <div class="d-flex justify-content-between box2 p-3">
                <div>
                    <p><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                            class="bi bi-truck" viewBox="0 0 16 16">
                            <path
                                d="M0 3.5A1.5 1.5 0 0 1 1.5 2h9A1.5 1.5 0 0 1 12 3.5V5h1.02a1.5 1.5 0 0 1 1.17.563l1.481 1.85a1.5 1.5 0 0 1 .329.938V10.5a1.5 1.5 0 0 1-1.5 1.5H14a2 2 0 1 1-4 0H5a2 2 0 1 1-3.998-.085A1.5 1.5 0 0 1 0 10.5zm1.294 7.456A1.999 1.999 0 0 1 4.732 11h5.536a2.01 2.01 0 0 1 .732-.732V3.5a.5.5 0 0 0-.5-.5h-9a.5.5 0 0 0-.5.5v7a.5.5 0 0 0 .294.456M12 10a2 2 0 0 1 1.732 1h.768a.5.5 0 0 0 .5-.5V8.35a.5.5 0 0 0-.11-.312l-1.48-1.85A.5.5 0 0 0 13.02 6H12zm-9 1a1 1 0 1 0 0 2 1 1 0 0 0 0-2m9 0a1 1 0 1 0 0 2 1 1 0 0 0 0-2" />
                        </svg>
                        NATIONWIDE SHIPPING</p>
                </div>

                <div>
                    <p> <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                            class="bi bi-box2" viewBox="0 0 16 16">
                            <path
                                d="M2.95.4a1 1 0 0 1 .8-.4h8.5a1 1 0 0 1 .8.4l2.85 3.8a.5.5 0 0 1 .1.3V15a1 1 0 0 1-1 1H1a1 1 0 0 1-1-1V4.5a.5.5 0 0 1 .1-.3L2.95.4ZM7.5 1H3.75L1.5 4h6zm1 0v3h6l-2.25-3zM15 5H1v10h14z" />
                        </svg>
                        GENUINE,BOX PACKED PRODUCTS</p>
                </div>

                <div>
                    <p><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                            class="bi bi-shield-shaded" viewBox="0 0 16 16">
                            <path fill-rule="evenodd"
                                d="M8 14.933a.615.615 0 0 0 .1-.025c.076-.023.174-.061.294-.118.24-.113.547-.29.893-.533a10.726 10.726 0 0 0 2.287-2.233c1.527-1.997 2.807-5.031 2.253-9.188a.48.48 0 0 0-.328-.39c-.651-.213-1.75-.56-2.837-.855C9.552 1.29 8.531 1.067 8 1.067zM5.072.56C6.157.265 7.31 0 8 0s1.843.265 2.928.56c1.11.3 2.229.655 2.887.87a1.54 1.54 0 0 1 1.044 1.262c.596 4.477-.787 7.795-2.465 9.99a11.775 11.775 0 0 1-2.517 2.453 7.159 7.159 0 0 1-1.048.625c-.28.132-.581.24-.829.24s-.548-.108-.829-.24a7.158 7.158 0 0 1-1.048-.625 11.777 11.777 0 0 1-2.517-2.453C1.928 10.487.545 7.169 1.141 2.692A1.54 1.54 0 0 1 2.185 1.43 62.456 62.456 0 0 1 5.072.56z" />
                        </svg>
                        COMPREHENSIVE BRAND SUPPORT</p>
                </div>
            </div>
        </div>
    </header>
    <img alt="splash-img-tpt" id="splash-img-tpt"
        style="pointer-events: none; position: absolute; top: 0; left: 0; width: 96vw; height: 96vh;"
        src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48c3ZnIHdpZHRoPSI5OTk5OXB4IiBoZWlnaHQ9Ijk5OTk5cHgiIHZpZXdCb3g9IjAgMCA5OTk5OSA5OTk5OSIgdmVyc2lvbj0iMS4xIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIj48ZyBzdHJva2U9Im5vbmUiIGZpbGw9Im5vbmUiIGZpbGwtb3BhY2l0eT0iMCI+PHJlY3QgeD0iMCIgeT0iMCIgd2lkdGg9Ijk5OTk5IiBoZWlnaHQ9Ijk5OTk5Ij48L3JlY3Q+IDwvZz4gPC9zdmc+">

    <div id="page-body" class="breadcrumb-color wide">
        <div id="body-content">
            <!-------------------------------main c-------------------------------------->
            <div class="main-content" id="main-content">
                <div class="wrap-breadcrumb bw-color ">
                    <div id="breadcrumb" class="breadcrumb-holder container">
                        <ul class="breadcrumb">
                            <li itemscope itemtype="http://data-vocabulary.org/Breadcrumb">
                                <a itemprop="url" href="/">
                                    <span itemprop="title" class="d-none">RedragonZone.PK</span>Home
                                </a>
                            </li>
                            <li itemscope itemtype="http://data-vocabulary.org/Breadcrumb" class="d-none">
                                <a href="/collections/gaming-mouse-price-in-pakistan" itemprop="url">
                                    <span itemprop="title">COMBO</span>
                                </a>
                            </li>
                            <li class="active">COMBO</li>
                        </ul>
                    </div>
                </div>
                <div class="page-cata active-sidebar" data-logic="false">
                    <div class="container">
                        <div class="row">
                            <div id="sidebar" class="left-column-container col-lg-3 col-md-12">
                                <div class="f-close d-lg-none" title="Close">
                                    <i class="demo-icon icon-close">
                                    </i>
                                </div>
                                <div class="sb-widget d-none d-lg-block">
                                    <div class="sb-menu">
                                        <h5 class="sb-title">SHOP</h5>
                                        <ul class="categories-menu">
                                            <li>
                                                <a href="combo.php">COMBO</a>
                                            </li>
                                            <li>
                                                <a href="headset.php">HEADSET</a>
                                            </li>
                                            <li>
                                                <a href="keyboard.php">KEYBOARD</a>
                                            </li>
                                            <li>
                                                <a href="mouse.php">MOUSE</a>
                                            </li>
                                            <li>
                                                <a href="mousepad.php">MOUSE PAD</a>
                                            </li>
                                            <li>
                                                <a href="stand1.php">HEADSET STAND</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="sb-widget d-none d-lg-block">
                                    <div class="sb-banner">
                                        <a href="/products/redragon-k530-rgb-draconic-gaming-keyboard-white">
                                            <span class="image-lazysize" style="position:relative;padding-top:100.0%;">
                                                <img class="img-lazy "
                                                    src="//redragonzone.pk/cdn/shop/files/redragon-k530-draconic-gaming-keyboard-redragonzone-pk-redragon-pakistan_330x.jpg?v=1691194943"
                                                    alt="redragon k530 draconic gaming keyboard at redragonzone.pk redragon pakistan" />
                                            </span>
                                        </a>
                                    </div>
                                </div>
                                <div class="sb-widget d-none d-lg-block">
                                    <div class="sb-banner">
                                        <a href="/products/redragon-k552-rgb-1-kumara-mechanical-gaming-keyboard">
                                            <span class="image-lazysize"
                                                style="position:relative;padding-top:73.33333333333334%;">
                                                <img class="img-lazy "
                                                    src="//redragonzone.pk/cdn/shop/files/redragon-k552-redragonzone-pk-redragon-pakistan-banner-mobile_330x.jpg?v=1691192420" />
                                            </span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="main-cata-page col-lg-9 col-md-12 col-sm-12 col-12">
                                <div class="block-banner subcollections-three-banners">
                                    <div class="row">
                                    </div>
                                </div>
                                <div class="cata-toolbar">
                                    <div class="group-toolbar">
                                        <div class="cata-title">
                                            <h1>COMBO</h1>
                                        </div>
                                        <div class="grid-list">
                                            <span class="text">View</span>
                                        </div>
                                        <div class="sort-by bc-toggle">
                                            <div class="sort-by-inner">

                                                <label class="d-none d-md-block">Products</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!--------------------------------------------------------------------------------------------------------------->

                                <div id="col-main">


                                    <div class="cata-product cp-grid">




                                        <div class="product-grid-item mode-view-item">







                                            <div class="product-wrapper effect-overlay ">

                                                <div class="product-head">
                                                    <div class="product-image">

                                                        <div class="featured-img product-ratio-auto">
                                                            <a
                                                                href="/collections/gaming-combo-price-in-pakistan/products/redragon-s101-ba-2-wired-gaming-4-in-1-combo">










                                                                <span class="image-lazysize">
                                                                    <!-- noscript pattern -->
                                                                    <noscript>
                                                                        <img class="img-lazy product-ratio-auto featured-image front"
                                                                            src="//redragonzone.pk/cdn/shop/products/IihnWnqjZXHBk0IRqLLlill0qB21VtoXVYYX6Ue4_420x.png?v=1596877368"
                                                                            alt="Redragon S101-BA-2 Wired Gaming Keyboard, Mouse, Headset, Mousepad Combo Set - Redragon Pakistan" />
                                                                    </noscript>

                                                                    <img class="featured-image front img-lazy blur-up auto-crop-false lazyautosizes lazyloaded"
                                                                        data-widths="[180, 320, 540, 720, 1080, 1366, 1920, 2048] "
                                                                        data-aspectratio="1.0" data-sizes="auto"
                                                                        data-parent-fit="cover"
                                                                        alt="Redragon S101-BA-2 Wired Gaming Keyboard, Mouse, Headset, Mousepad Combo Set - Redragon Pakistan"
                                                                        data-srcset="//redragonzone.pk/cdn/shop/products/IihnWnqjZXHBk0IRqLLlill0qB21VtoXVYYX6Ue4_180x.png?v=1596877368 180w, //redragonzone.pk/cdn/shop/products/IihnWnqjZXHBk0IRqLLlill0qB21VtoXVYYX6Ue4_320x.png?v=1596877368 320w, //redragonzone.pk/cdn/shop/products/IihnWnqjZXHBk0IRqLLlill0qB21VtoXVYYX6Ue4_540x.png?v=1596877368 540w, //redragonzone.pk/cdn/shop/products/IihnWnqjZXHBk0IRqLLlill0qB21VtoXVYYX6Ue4_720x.png?v=1596877368 720w, //redragonzone.pk/cdn/shop/products/IihnWnqjZXHBk0IRqLLlill0qB21VtoXVYYX6Ue4_1080x.png?v=1596877368 1080w, //redragonzone.pk/cdn/shop/products/IihnWnqjZXHBk0IRqLLlill0qB21VtoXVYYX6Ue4_1366x.png?v=1596877368 1366w, //redragonzone.pk/cdn/shop/products/IihnWnqjZXHBk0IRqLLlill0qB21VtoXVYYX6Ue4_1920x.png?v=1596877368 1920w, //redragonzone.pk/cdn/shop/products/IihnWnqjZXHBk0IRqLLlill0qB21VtoXVYYX6Ue4_2048x.png?v=1596877368 2048w"
                                                                        sizes="197px"
                                                                        srcset="//redragonzone.pk/cdn/shop/products/IihnWnqjZXHBk0IRqLLlill0qB21VtoXVYYX6Ue4_180x.png?v=1596877368 180w, //redragonzone.pk/cdn/shop/products/IihnWnqjZXHBk0IRqLLlill0qB21VtoXVYYX6Ue4_320x.png?v=1596877368 320w, //redragonzone.pk/cdn/shop/products/IihnWnqjZXHBk0IRqLLlill0qB21VtoXVYYX6Ue4_540x.png?v=1596877368 540w, //redragonzone.pk/cdn/shop/products/IihnWnqjZXHBk0IRqLLlill0qB21VtoXVYYX6Ue4_720x.png?v=1596877368 720w, //redragonzone.pk/cdn/shop/products/IihnWnqjZXHBk0IRqLLlill0qB21VtoXVYYX6Ue4_1080x.png?v=1596877368 1080w, //redragonzone.pk/cdn/shop/products/IihnWnqjZXHBk0IRqLLlill0qB21VtoXVYYX6Ue4_1366x.png?v=1596877368 1366w, //redragonzone.pk/cdn/shop/products/IihnWnqjZXHBk0IRqLLlill0qB21VtoXVYYX6Ue4_1920x.png?v=1596877368 1920w, //redragonzone.pk/cdn/shop/products/IihnWnqjZXHBk0IRqLLlill0qB21VtoXVYYX6Ue4_2048x.png?v=1596877368 2048w">
                                                                </span>














                                                                <span class="product-label flex">







                                                                    <span class="label-new">
                                                                        <span class="new-text">New</span>
                                                                    </span>




















                                                                </span>

                                                            </a>
                                                        </div>



                                                        

                                                    </div>


                                                    

                                                </div>

                                                <div class="product-content">
                                                    <div class="pc-inner">


                                                        <div class="list-v2-label">
                                                            
                                                        </div>


                                                        <div class="product-group-vendor-name">
                                                            <div class="product-vendor"><a
                                                                    href="/collections/vendors?q=REDRAGON"
                                                                    title="REDRAGON">REDRAGON</a></div>
                                                            <h5 class="product-name balance-false"><a
                                                                    href="combo1.php">Redragon
                                                                    S101-BA-2 Wired Gaming Keyboard, Mouse, Headset,
                                                                    Mousepad Combo Set (4 in 1)</a></h5>

                                                            <div class="product-review">

                                                                <span class="shopify-product-reviews-badge"
                                                                    data-id="5496033575063"></span>

                                                            </div>

                                                        </div>






                                                        <div class="product-price notranslate">

                                                            <span class="price">Rs. <?php $ComboRow = mysqli_fetch_assoc($ComboPricesResult); echo $ComboRow['Price']; ?></span>

                                                        </div>



                                                        <div class="product-list-mode-content">


                                                            



                                                        </div>

                                                    </div>
                                                </div>

                                                <div class="product-list-mode-content-v2">
                                                    <div class="list-v2-inner">
                                                        


                                                    </div>
                                                </div>

                                            </div>


                                        </div>

                                        <div class="product-grid-item mode-view-item">







                                            <div class="product-wrapper effect-overlay ">

                                                <div class="product-head">
                                                    <div class="product-image">

                                                        <div class="featured-img product-ratio-auto">
                                                            <a
                                                                href="/collections/gaming-combo-price-in-pakistan/products/redragon-one-handed-gaming-keyboard-and-m721-pro-rgb-mouse-combo-k585-ba">










                                                                <span class="image-lazysize">
                                                                    <!-- noscript pattern -->
                                                                    <noscript>
                                                                        <img class="img-lazy product-ratio-auto featured-image front"
                                                                            src="//redragonzone.pk/cdn/shop/products/Redragon_K585_Combo-removebg-preview_420x.png?v=1593432460"
                                                                            alt="Redragon K585 BA RGB One-Handed Gaming Keyboard & M721-Pro RGB Gaming Mouse Combo Set - Redragon Pakistan" />
                                                                    </noscript>

                                                                    <img class="featured-image front img-lazy blur-up auto-crop-false lazyautosizes lazyloaded"
                                                                        data-widths="[180, 320, 540, 720, 1080, 1366, 1920, 2048] "
                                                                        data-aspectratio="1.0020242914979758"
                                                                        data-sizes="auto" data-parent-fit="cover"
                                                                        alt="Redragon K585 BA RGB One-Handed Gaming Keyboard &amp; M721-Pro RGB Gaming Mouse Combo Set - Redragon Pakistan"
                                                                        data-srcset="//redragonzone.pk/cdn/shop/products/Redragon_K585_Combo-removebg-preview_180x.png?v=1593432460 180w, //redragonzone.pk/cdn/shop/products/Redragon_K585_Combo-removebg-preview_320x.png?v=1593432460 320w, //redragonzone.pk/cdn/shop/products/Redragon_K585_Combo-removebg-preview_540x.png?v=1593432460 540w, //redragonzone.pk/cdn/shop/products/Redragon_K585_Combo-removebg-preview_720x.png?v=1593432460 720w, //redragonzone.pk/cdn/shop/products/Redragon_K585_Combo-removebg-preview_1080x.png?v=1593432460 1080w, //redragonzone.pk/cdn/shop/products/Redragon_K585_Combo-removebg-preview_1366x.png?v=1593432460 1366w, //redragonzone.pk/cdn/shop/products/Redragon_K585_Combo-removebg-preview_1920x.png?v=1593432460 1920w, //redragonzone.pk/cdn/shop/products/Redragon_K585_Combo-removebg-preview_2048x.png?v=1593432460 2048w"
                                                                        sizes="197px"
                                                                        srcset="//redragonzone.pk/cdn/shop/products/Redragon_K585_Combo-removebg-preview_180x.png?v=1593432460 180w, //redragonzone.pk/cdn/shop/products/Redragon_K585_Combo-removebg-preview_320x.png?v=1593432460 320w, //redragonzone.pk/cdn/shop/products/Redragon_K585_Combo-removebg-preview_540x.png?v=1593432460 540w, //redragonzone.pk/cdn/shop/products/Redragon_K585_Combo-removebg-preview_720x.png?v=1593432460 720w, //redragonzone.pk/cdn/shop/products/Redragon_K585_Combo-removebg-preview_1080x.png?v=1593432460 1080w, //redragonzone.pk/cdn/shop/products/Redragon_K585_Combo-removebg-preview_1366x.png?v=1593432460 1366w, //redragonzone.pk/cdn/shop/products/Redragon_K585_Combo-removebg-preview_1920x.png?v=1593432460 1920w, //redragonzone.pk/cdn/shop/products/Redragon_K585_Combo-removebg-preview_2048x.png?v=1593432460 2048w">
                                                                </span>














                                                                <span class="product-label flex">







                                                                    <span class="label-new">
                                                                        <span class="new-text">New</span>
                                                                    </span>




















                                                                </span>

                                                            </a>
                                                        </div>



                                                       

                                                    </div>


                                                   

                                                </div>

                                                <div class="product-content">
                                                    <div class="pc-inner">


                                                        <div class="list-v2-label">
                                                           
                                                        </div>


                                                        <div class="product-group-vendor-name">
                                                            <div class="product-vendor"><a
                                                                    href="/collections/vendors?q=REDRAGON"
                                                                    title="REDRAGON">REDRAGON</a></div>
                                                            <h5 class="product-name balance-false"><a
                                                                    href="combo2.php">Redragon
                                                                    K585-BA RGB One-Handed Gaming Keyboard &amp;
                                                                    M721-Pro RGB Gaming Mouse Combo Set (2 in 1)</a>
                                                            </h5>

                                                            <div class="product-review">

                                                                <span class="shopify-product-reviews-badge"
                                                                    data-id="5321598992535"></span>

                                                            </div>

                                                        </div>






                                                        <div class="product-price notranslate">

                                                            <span class="price">Rs. <?php $ComboRow = mysqli_fetch_assoc($ComboPricesResult); echo $ComboRow['Price']; ?></span>

                                                        </div>



                                                        <div class="product-list-mode-content">


                                                            




                                                        </div>

                                                    </div>
                                                </div>

                                                <div class="product-list-mode-content-v2">
                                                    <div class="list-v2-inner">
                                                        
                                                    </div>
                                                </div>

                                            </div>


                                        </div>

                                        <div class="product-grid-item mode-view-item">







                                            <div class="product-wrapper effect-overlay ">

                                                <div class="product-head">
                                                    <div class="product-image">

                                                        <div class="featured-img product-ratio-auto">
                                                            <a
                                                                href="/collections/gaming-combo-price-in-pakistan/products/redragon-gaming-k552-rgb-keyboard-m-607-mouse-2-in-1-combo">










                                                                <span class="image-lazysize">
                                                                    <!-- noscript pattern -->
                                                                    <noscript>
                                                                        <img class="img-lazy product-ratio-auto featured-image front"
                                                                            src="//redragonzone.pk/cdn/shop/files/redragon_k552_rgb_2_in_1_combo_-_mechanical_gaming_keyboard_mouse_redragonzone-pk-01_420x.jpg?v=1691758104"
                                                                            alt="Redragon K552 RGB Keyboard & M607 Mouse Combo Set - Redragon Pakistan" />
                                                                    </noscript>

                                                                    <img class="featured-image front img-lazy blur-up auto-crop-false lazyautosizes lazyloaded"
                                                                        data-widths="[180, 320, 540, 720, 1080, 1366, 1920, 2048] "
                                                                        data-aspectratio="1.0" data-sizes="auto"
                                                                        data-parent-fit="cover"
                                                                        alt="Redragon K552 RGB Keyboard &amp; M607 Mouse Combo Set - Redragon Pakistan"
                                                                        data-srcset="//redragonzone.pk/cdn/shop/files/redragon_k552_rgb_2_in_1_combo_-_mechanical_gaming_keyboard_mouse_redragonzone-pk-01_180x.jpg?v=1691758104 180w, //redragonzone.pk/cdn/shop/files/redragon_k552_rgb_2_in_1_combo_-_mechanical_gaming_keyboard_mouse_redragonzone-pk-01_320x.jpg?v=1691758104 320w, //redragonzone.pk/cdn/shop/files/redragon_k552_rgb_2_in_1_combo_-_mechanical_gaming_keyboard_mouse_redragonzone-pk-01_540x.jpg?v=1691758104 540w, //redragonzone.pk/cdn/shop/files/redragon_k552_rgb_2_in_1_combo_-_mechanical_gaming_keyboard_mouse_redragonzone-pk-01_720x.jpg?v=1691758104 720w, //redragonzone.pk/cdn/shop/files/redragon_k552_rgb_2_in_1_combo_-_mechanical_gaming_keyboard_mouse_redragonzone-pk-01_1080x.jpg?v=1691758104 1080w, //redragonzone.pk/cdn/shop/files/redragon_k552_rgb_2_in_1_combo_-_mechanical_gaming_keyboard_mouse_redragonzone-pk-01_1366x.jpg?v=1691758104 1366w, //redragonzone.pk/cdn/shop/files/redragon_k552_rgb_2_in_1_combo_-_mechanical_gaming_keyboard_mouse_redragonzone-pk-01_1920x.jpg?v=1691758104 1920w, //redragonzone.pk/cdn/shop/files/redragon_k552_rgb_2_in_1_combo_-_mechanical_gaming_keyboard_mouse_redragonzone-pk-01_2048x.jpg?v=1691758104 2048w"
                                                                        sizes="197px"
                                                                        srcset="//redragonzone.pk/cdn/shop/files/redragon_k552_rgb_2_in_1_combo_-_mechanical_gaming_keyboard_mouse_redragonzone-pk-01_180x.jpg?v=1691758104 180w, //redragonzone.pk/cdn/shop/files/redragon_k552_rgb_2_in_1_combo_-_mechanical_gaming_keyboard_mouse_redragonzone-pk-01_320x.jpg?v=1691758104 320w, //redragonzone.pk/cdn/shop/files/redragon_k552_rgb_2_in_1_combo_-_mechanical_gaming_keyboard_mouse_redragonzone-pk-01_540x.jpg?v=1691758104 540w, //redragonzone.pk/cdn/shop/files/redragon_k552_rgb_2_in_1_combo_-_mechanical_gaming_keyboard_mouse_redragonzone-pk-01_720x.jpg?v=1691758104 720w, //redragonzone.pk/cdn/shop/files/redragon_k552_rgb_2_in_1_combo_-_mechanical_gaming_keyboard_mouse_redragonzone-pk-01_1080x.jpg?v=1691758104 1080w, //redragonzone.pk/cdn/shop/files/redragon_k552_rgb_2_in_1_combo_-_mechanical_gaming_keyboard_mouse_redragonzone-pk-01_1366x.jpg?v=1691758104 1366w, //redragonzone.pk/cdn/shop/files/redragon_k552_rgb_2_in_1_combo_-_mechanical_gaming_keyboard_mouse_redragonzone-pk-01_1920x.jpg?v=1691758104 1920w, //redragonzone.pk/cdn/shop/files/redragon_k552_rgb_2_in_1_combo_-_mechanical_gaming_keyboard_mouse_redragonzone-pk-01_2048x.jpg?v=1691758104 2048w">
                                                                </span>










                                                            </a>
                                                        </div>



                                                        

                                                    </div>


                                                   

                                                </div>

                                                <div class="product-content">
                                                    <div class="pc-inner">


                                                        <div class="list-v2-label">
                                                            
                                                        </div>


                                                        <div class="product-group-vendor-name">
                                                            <div class="product-vendor"><a
                                                                    href="/collections/vendors?q=REDRAGON"
                                                                    title="REDRAGON">REDRAGON</a></div>
                                                            <h5 class="product-name balance-false"><a
                                                                    href="combo3.php">Redragon
                                                                    K552 RGB Keyboard &amp; M607 Mouse Combo Set (2 in
                                                                    1)</a></h5>

                                                            <div class="product-review">

                                                                <span class="shopify-product-reviews-badge"
                                                                    data-id="5390618951831"></span>

                                                            </div>

                                                        </div>






                                                        <div class="product-price notranslate">

                                                            <span class="price">Rs. <?php $ComboRow = mysqli_fetch_assoc($ComboPricesResult); echo $ComboRow['Price']; ?></span>

                                                        </div>



                                                        <div class="product-list-mode-content">



                                                           



                                                        </div>

                                                    </div>
                                                </div>

                                                <div class="product-list-mode-content-v2">
                                                    <div class="list-v2-inner">
                                                        


                                                    </div>
                                                </div>

                                            </div>


                                        </div>

                                        <div class="product-grid-item mode-view-item">







                                            <div class="product-wrapper effect-overlay ">

                                                <div class="product-head">
                                                    <div class="product-image">

                                                        <div class="featured-img product-ratio-auto">
                                                            <a
                                                                href="/collections/gaming-combo-price-in-pakistan/products/redragon-combo-3-in-1-k552">










                                                                <span class="image-lazysize">
                                                                    <!-- noscript pattern -->
                                                                    <noscript>
                                                                        <img class="img-lazy product-ratio-auto featured-image front"
                                                                            src="//redragonzone.pk/cdn/shop/products/552-ba-2-700x700_420x.jpg?v=1601377404"
                                                                            alt="Redragon K552-BA-2 Keyboard, M601 Mouse, P001 XL Mousepad Combo Set - Redragon Pakistan" />
                                                                    </noscript>

                                                                    <img class="featured-image front img-lazy blur-up auto-crop-false lazyautosizes lazyloaded"
                                                                        data-widths="[180, 320, 540, 720, 1080, 1366, 1920, 2048] "
                                                                        data-aspectratio="1.0" data-sizes="auto"
                                                                        data-parent-fit="cover"
                                                                        alt="Redragon K552-BA-2 Keyboard, M601 Mouse, P001 XL Mousepad Combo Set - Redragon Pakistan"
                                                                        data-srcset="//redragonzone.pk/cdn/shop/products/552-ba-2-700x700_180x.jpg?v=1601377404 180w, //redragonzone.pk/cdn/shop/products/552-ba-2-700x700_320x.jpg?v=1601377404 320w, //redragonzone.pk/cdn/shop/products/552-ba-2-700x700_540x.jpg?v=1601377404 540w, //redragonzone.pk/cdn/shop/products/552-ba-2-700x700_720x.jpg?v=1601377404 720w, //redragonzone.pk/cdn/shop/products/552-ba-2-700x700_1080x.jpg?v=1601377404 1080w, //redragonzone.pk/cdn/shop/products/552-ba-2-700x700_1366x.jpg?v=1601377404 1366w, //redragonzone.pk/cdn/shop/products/552-ba-2-700x700_1920x.jpg?v=1601377404 1920w, //redragonzone.pk/cdn/shop/products/552-ba-2-700x700_2048x.jpg?v=1601377404 2048w"
                                                                        sizes="197px"
                                                                        srcset="//redragonzone.pk/cdn/shop/products/552-ba-2-700x700_180x.jpg?v=1601377404 180w, //redragonzone.pk/cdn/shop/products/552-ba-2-700x700_320x.jpg?v=1601377404 320w, //redragonzone.pk/cdn/shop/products/552-ba-2-700x700_540x.jpg?v=1601377404 540w, //redragonzone.pk/cdn/shop/products/552-ba-2-700x700_720x.jpg?v=1601377404 720w, //redragonzone.pk/cdn/shop/products/552-ba-2-700x700_1080x.jpg?v=1601377404 1080w, //redragonzone.pk/cdn/shop/products/552-ba-2-700x700_1366x.jpg?v=1601377404 1366w, //redragonzone.pk/cdn/shop/products/552-ba-2-700x700_1920x.jpg?v=1601377404 1920w, //redragonzone.pk/cdn/shop/products/552-ba-2-700x700_2048x.jpg?v=1601377404 2048w">
                                                                </span>










                                                            </a>
                                                        </div>



                                                        

                                                    </div>


                                                   

                                                </div>

                                                <div class="product-content">
                                                    <div class="pc-inner">


                                                        <div class="list-v2-label">
                                                            
                                                        </div>


                                                        <div class="product-group-vendor-name">
                                                            <div class="product-vendor"><a
                                                                    href="/collections/vendors?q=REDRAGON"
                                                                    title="REDRAGON">REDRAGON</a></div>
                                                            <h5 class="product-name balance-false"><a
                                                                    href="combo4.php">Redragon
                                                                    K552-BA-2 Keyboard, M601 Mouse, P001 XL Mousepad
                                                                    Combo Set (3 in 1)</a></h5>

                                                            <div class="product-review">

                                                                <span class="shopify-product-reviews-badge"
                                                                    data-id="5767344160919"></span>

                                                            </div>

                                                        </div>






                                                        <div class="product-price notranslate">

                                                            <span class="price">Rs. <?php $ComboRow = mysqli_fetch_assoc($ComboPricesResult); echo $ComboRow['Price']; ?></span>

                                                        </div>



                                                        <div class="product-list-mode-content">


                                                            



                                                        </div>

                                                    </div>
                                                </div>

                                                <div class="product-list-mode-content-v2">
                                                    <div class="list-v2-inner">
                                                       



                                                    </div>
                                                </div>

                                            </div>


                                        </div>

                                        <div class="product-grid-item mode-view-item">







                                            <div class="product-wrapper effect-overlay ">

                                                <div class="product-head">
                                                    <div class="product-image">

                                                        <div class="featured-img product-ratio-auto">
                                                            <a
                                                                href="/collections/gaming-combo-price-in-pakistan/products/redragon-s129w-3-in-1-keyboard-mouse-and-headsets-wired-combo-white">










                                                                <span class="image-lazysize">
                                                                    <!-- noscript pattern -->
                                                                    <noscript>
                                                                        <img class="img-lazy product-ratio-auto featured-image front"
                                                                            src="//redragonzone.pk/cdn/shop/products/72151-1_420x.jpg?v=1677747628"
                                                                            alt="Redragon S129W Keyboard Mouse and Headsets Combo Set - Redragon Pakistan" />
                                                                    </noscript>

                                                                    <img class="featured-image front img-lazy blur-up auto-crop-false lazyautosizes lazyloaded"
                                                                        data-widths="[180, 320, 540, 720, 1080, 1366, 1920, 2048] "
                                                                        data-aspectratio="1.0" data-sizes="auto"
                                                                        data-parent-fit="cover"
                                                                        alt="Redragon S129W Keyboard Mouse and Headsets Combo Set - Redragon Pakistan"
                                                                        data-srcset="//redragonzone.pk/cdn/shop/products/72151-1_180x.jpg?v=1677747628 180w, //redragonzone.pk/cdn/shop/products/72151-1_320x.jpg?v=1677747628 320w, //redragonzone.pk/cdn/shop/products/72151-1_540x.jpg?v=1677747628 540w, //redragonzone.pk/cdn/shop/products/72151-1_720x.jpg?v=1677747628 720w, //redragonzone.pk/cdn/shop/products/72151-1_1080x.jpg?v=1677747628 1080w, //redragonzone.pk/cdn/shop/products/72151-1_1366x.jpg?v=1677747628 1366w, //redragonzone.pk/cdn/shop/products/72151-1_1920x.jpg?v=1677747628 1920w, //redragonzone.pk/cdn/shop/products/72151-1_2048x.jpg?v=1677747628 2048w"
                                                                        sizes="197px"
                                                                        srcset="//redragonzone.pk/cdn/shop/products/72151-1_180x.jpg?v=1677747628 180w, //redragonzone.pk/cdn/shop/products/72151-1_320x.jpg?v=1677747628 320w, //redragonzone.pk/cdn/shop/products/72151-1_540x.jpg?v=1677747628 540w, //redragonzone.pk/cdn/shop/products/72151-1_720x.jpg?v=1677747628 720w, //redragonzone.pk/cdn/shop/products/72151-1_1080x.jpg?v=1677747628 1080w, //redragonzone.pk/cdn/shop/products/72151-1_1366x.jpg?v=1677747628 1366w, //redragonzone.pk/cdn/shop/products/72151-1_1920x.jpg?v=1677747628 1920w, //redragonzone.pk/cdn/shop/products/72151-1_2048x.jpg?v=1677747628 2048w">
                                                                </span>










                                                            </a>
                                                        </div>




                                                    </div>


                                                  

                                                </div>

                                                <div class="product-content">
                                                    <div class="pc-inner">


                                                        <div class="list-v2-label">
                                                            
                                                        </div>


                                                        <div class="product-group-vendor-name">
                                                            <div class="product-vendor"><a
                                                                    href="/collections/vendors?q=REDRAGON"
                                                                    title="REDRAGON">REDRAGON</a></div>
                                                            <h5 class="product-name balance-false"><a
                                                                    href="combo5.php">Redragon
                                                                    S129W Keyboard Mouse and Headsets Combo Set (3-in-1,
                                                                    White)</a></h5>

                                                            <div class="product-review">

                                                                <span class="shopify-product-reviews-badge"
                                                                    data-id="7943760314519"></span>

                                                            </div>

                                                        </div>






                                                        <div class="product-price notranslate">

                                                            <span class="price">Rs. <?php $ComboRow = mysqli_fetch_assoc($ComboPricesResult); echo $ComboRow['Price']; ?></span>

                                                        </div>



                                                        <div class="product-list-mode-content">




                                                            



                                                        </div>

                                                    </div>
                                                </div>

                                                <div class="product-list-mode-content-v2">
                                                    <div class="list-v2-inner">
                                                



                                                    </div>
                                                </div>

                                            </div>


                                        </div>



                                    </div>


                                </div>


                                <!--------------------------------------------------------------------------------------------------------------->
                            </div>
                            <div style="margin-bottom: 90px;"></div>
                        </div>
                    </div>
                </div>
            </div>
            <!-------------------------------main e---------------------------->
        </div>
    </div>
    </div>
    <!-- footer -->
    <footer>
        <div class="d-flex flex-wrap p-3 box6">
            <div class="flex-fill">
                <p>INFO@REDRAGONZONE.PK</p>
                <div class="top">
                    <a href="index.php"><img src="picc/redragon.png" width="210px" height="190px" alt=""></a>
                </div>
                <p>CUSTOMER CARE CENTER</p>
                <p>314 - AL-HAFEEZ SHOPPING MALL, GULBERG III,<br>
                    MAIN BOULEVARD, LAHORE - PAKISTAN</p>
                <p>(+92) 3111 000 135</p>
            </div>
            <div class="flex-fill">
                <p>PRODUCTS</p>
                <ul>
                    <a href="keyboard.php">
                        <li>KEYBOARD</li>
                    </a>

                    <a href="mouse.php">
                        <li>MOUSE</li>
                    </a>

                    <a href="combo.php">
                        <li>COMBO</li>
                    </a>

                    <a href="mousepad.php">
                        <li>MOUSE PAD</li>
                    </a>

                    <a href="headset.php">
                        <li>HEADSET</li>
                    </a>

                    <a href="stand1.php">
                        <li>ACCESSORIES</li>
                    </a>

                </ul>
            </div>

            <div class="flex-fill">
                <p> INFORMATION</p>
                <ul>
                    <li> <a href="Warranty.php">WARRANTY POLICY</a></li>
                    <li> <a href="payment.php">PAYMENT INFO</a></li>
                    <li> <a href="return.php">RETURN POLICY</a></li>
                </ul>

            </div>

            <div>
                <p>JOIN FOR EXCLUSIVE BENEFITS</p>
                <form action="/action_page.php">
                    <div class="d-flex box7">

                        <input type="email" class="form-control" id="email" placeholder="Your email address"
                            name="email">

                        <button type="submit" class="btn btn-danger ">Submit</button>
                    </div>
                </form>
            </div>

        </div>
    </footer>
</body>

</html>