<?php include("Connection.php");

$KeyboardPricesResult = mysqli_query($_SESSION["conn"], "SELECT * FROM product_catalogue WHERE Product_Category = 'KEYBOARD';");
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <link rel="shortcut icon" href="//redragonzone.pk/cdn/shop/files/Redragon-pakistan-380x380_32x32.png?v=1615319941"
        type="image/png">
    <meta charset="UTF-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport"
        content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=0" />
    <meta name='HandheldFriendly' content='True'>
    <meta name='MobileOptimized' content='375'>
    <meta http-equiv="cleartype" content="on">
    <meta name="theme-color" content="#e60012">
    <link rel="canonical" href="https://redragonzone.pk/collections/gaming-keyboard-price-in-pakistan" />

    <title>Shop Now - Redragon Gaming Keyboard - Pakistan</title>
    <meta name="description"
        content="Buy Redragon Gaming Keyboard in Pakistan. Latest &amp; wide range of gaming keyboards at best prices with official support. Nationwide shipping. Cash on delivery.">
   
    <meta property="og:site_name" content="RedragonZone.PK">
    <meta property="og:url" content="https://redragonzone.pk/collections/gaming-keyboard-price-in-pakistan">
    <meta property="og:title" content="KEYBOARD">
    <meta property="og:type" content="product.group">
    <meta property="og:description"
        content="Buy Redragon Gaming Keyboard in Pakistan. Latest &amp; wide range of gaming keyboards at best prices with official support. Nationwide shipping. Cash on delivery.">





    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="KEYBOARD">
    <meta name="twitter:description"
        content="Buy Redragon Gaming Keyboard in Pakistan. Latest &amp; wide range of gaming keyboards at best prices with official support. Nationwide shipping. Cash on delivery.">


    <link rel="canonical" href="https://redragonzone.pk/collections/gaming-keyboard-price-in-pakistan" />
    <link rel="preconnect dns-prefetch" href="https://cdn.shopify.com">
    <link rel="preconnect dns-prefetch" href="https://v.shopify.com">
    <link rel="preconnect dns-prefetch" href="https://cdn.shopifycloud.com">
    <link rel="preload" href="//redragonzone.pk/cdn/shop/t/5/assets/styles.scss.css?v=124980048740926497851703348189"
        as="style">
    <link rel="preload" href="//redragonzone.pk/cdn/shop/t/5/assets/themes.scss.css?v=58698413482323688401703348188"
        as="style">
    <link rel="preload" href="//redragonzone.pk/cdn/shop/t/5/assets/global.scss.css?v=125076772181967553861703348189"
        as="style">
    <link rel="preload" href="//redragonzone.pk/cdn/shop/t/5/assets/vendor.css?v=87675270813913945401581608572"
        as="style">
    <link rel="preload" href="//redragonzone.pk/cdn/shop/t/5/assets/arenafont.css?v=75023525835272796541703348189"
        as="style">
    <!-- header-css-file  ================================================== -->
    <link href="//redragonzone.pk/cdn/shop/t/5/assets/arenafont.css?v=75023525835272796541703348189" rel="stylesheet"
        type="text/css" media="all">
    <link href="//redragonzone.pk/cdn/shop/t/5/assets/vendor.css?v=87675270813913945401581608572" rel="stylesheet"
        type="text/css" media="all">
    <link href="//redragonzone.pk/cdn/shop/t/5/assets/styles.scss.css?v=124980048740926497851703348189" rel="stylesheet"
        type="text/css" media="all">
    <link href="//redragonzone.pk/cdn/shop/t/5/assets/themes.scss.css?v=58698413482323688401703348188" rel="stylesheet"
        type="text/css" media="all">
    <link href="//redragonzone.pk/cdn/shop/t/5/assets/global.scss.css?v=125076772181967553861703348189" rel="stylesheet"
        type="text/css" media="all">
    <link href="https://fonts.googleapis.com/css?family=Caveat:300,400,500,600,700&display=swap" rel='stylesheet'
        type='text/css'>

   

    <link href="//redragonzone.pk/cdn/shop/t/5/assets/bc_wl_cp_style.scss.css?v=172879242641943902421581608571"
        rel="stylesheet" type="text/css" media="all" />
    <script crossorigin="anonymous"
        src="//redragonzone.pk/cdn/shop/t/5/assets/lazysizes.min.js?v=68594089956960822201581608511" async></script>
    <script crossorigin="anonymous"
        src="//redragonzone.pk/cdn/shop/t/5/assets/jquery-1.11.0.min.js?v=58211863146907186831581608499"></script>
    <script crossorigin="anonymous"
        src="//redragonzone.pk/cdn/shop/t/5/assets/cookies.js?v=124176070287646777851581608481"></script>


    <script crossorigin="anonymous"
        src="//redragonzone.pk/cdn/shop/t/5/assets/bootstrap.4x.min.js?v=35271929837704850651581608476" defer></script>


    <meta name="google-site-verification" content="EWwwu38a_jv79ixFO-aQvD5pgJmEfotJ5jJy_vcPpQ4">
    <meta id="shopify-digital-wallet" name="shopify-digital-wallet" content="/33233961099/digital_wallets/dialog">
    <link rel="alternate" type="application/atom+xml" title="Feed"
        href="/collections/gaming-keyboard-price-in-pakistan.atom" />
    <link rel="next" href="/collections/gaming-keyboard-price-in-pakistan?page=2">
    <link rel="alternate" type="application/json+oembed"
        href="https://redragonzone.pk/collections/gaming-keyboard-price-in-pakistan.oembed">
   
    <!-- END app app block -->
    <meta property="og:image"
        content="https://cdn.shopify.com/s/files/1/0332/3396/1099/files/redragon-pakistan-theme_63345c37-7358-4be7-83ce-fc84683d1de1.jpg?v=1600006452" />
    <meta property="og:image:secure_url"
        content="https://cdn.shopify.com/s/files/1/0332/3396/1099/files/redragon-pakistan-theme_63345c37-7358-4be7-83ce-fc84683d1de1.jpg?v=1600006452" />
    <meta property="og:image:width" content="3840" />
    <meta property="og:image:height" content="2160" />
    <link href="https://monorail-edge.shopifysvc.com" rel="dns-prefetch">
   
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="icon" href="picc/redragon.png" type="image/x-icon">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="smile.css">
</head>


<body data-rtl="false" class="templateCollection mobile-bar-outside category-mode-false cata-grid-4 lazy-loading-img ">
    <!----header-->
    <header>
        <div class="top-bar-list  ">

            <p> DUE TO LARGE NUMBER OF ORDERS, PLEASE EXPECT 1 TO 2 DAYS DELAY IN DELIVERY</p>

        </div>


        <div class="d-flex justify-content-between top-bar-right">
            <div class="d-flex hello">
                <div>
                    <a href="https://redragonzone.pk/"> <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20"
                            fill="currentColor" class="bi bi-facebook" viewBox="0 0 16 16">
                            <path
                                d="M16 8.049c0-4.446-3.582-8.05-8-8.05C3.58 0-.002 3.603-.002 8.05c0 4.017 2.926 7.347 6.75 7.951v-5.625h-2.03V8.05H6.75V6.275c0-2.017 1.195-3.131 3.022-3.131.876 0 1.791.157 1.791.157v1.98h-1.009c-.993 0-1.303.621-1.303 1.258v1.51h2.218l-.354 2.326H9.25V16c3.824-.604 6.75-3.934 6.75-7.951" />
                        </svg></a>
                </div>

                <div>
                    <a href="https://redragonzone.pk/"> <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20"
                            fill="currentColor" class="bi bi-twitter" viewBox="0 0 16 16">
                            <path
                                d="M5.026 15c6.038 0 9.341-5.003 9.341-9.334 0-.14 0-.282-.006-.422A6.685 6.685 0 0 0 16 3.542a6.658 6.658 0 0 1-1.889.518 3.301 3.301 0 0 0 1.447-1.817 6.533 6.533 0 0 1-2.087.793A3.286 3.286 0 0 0 7.875 6.03a9.325 9.325 0 0 1-6.767-3.429 3.289 3.289 0 0 0 1.018 4.382A3.323 3.323 0 0 1 .64 6.575v.045a3.288 3.288 0 0 0 2.632 3.218 3.203 3.203 0 0 1-.865.115 3.23 3.23 0 0 1-.614-.057 3.283 3.283 0 0 0 3.067 2.277A6.588 6.588 0 0 1 .78 13.58a6.32 6.32 0 0 1-.78-.045A9.344 9.344 0 0 0 5.026 15" />
                        </svg></a>
                </div>

                <div>
                    <a href="https://redragonzone.pk/"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20"
                            fill="currentColor" class="bi bi-pinterest" viewBox="0 0 16 16">
                            <path
                                d="M8 0a8 8 0 0 0-2.915 15.452c-.07-.633-.134-1.606.027-2.297.146-.625.938-3.977.938-3.977s-.239-.479-.239-1.187c0-1.113.645-1.943 1.448-1.943.682 0 1.012.512 1.012 1.127 0 .686-.437 1.712-.663 2.663-.188.796.4 1.446 1.185 1.446 1.422 0 2.515-1.5 2.515-3.664 0-1.915-1.377-3.254-3.342-3.254-2.276 0-3.612 1.707-3.612 3.471 0 .688.265 1.425.595 1.826a.24.24 0 0 1 .056.23c-.061.252-.196.796-.222.907-.035.146-.116.177-.268.107-1-.465-1.624-1.926-1.624-3.1 0-2.523 1.834-4.84 5.286-4.84 2.775 0 4.932 1.977 4.932 4.62 0 2.757-1.739 4.976-4.151 4.976-.811 0-1.573-.421-1.834-.919l-.498 1.902c-.181.695-.669 1.566-.995 2.097A8 8 0 1 0 8 0" />
                        </svg></a>
                </div>
                <div>
                    <a href="https://redragonzone.pk/"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20"
                            fill="currentColor" class="bi bi-instagram" viewBox="0 0 16 16">
                            <path
                                d="M8 0C5.829 0 5.556.01 4.703.048 3.85.088 3.269.222 2.76.42a3.917 3.917 0 0 0-1.417.923A3.927 3.927 0 0 0 .42 2.76C.222 3.268.087 3.85.048 4.7.01 5.555 0 5.827 0 8.001c0 2.172.01 2.444.048 3.297.04.852.174 1.433.372 1.942.205.526.478.972.923 1.417.444.445.89.719 1.416.923.51.198 1.09.333 1.942.372C5.555 15.99 5.827 16 8 16s2.444-.01 3.298-.048c.851-.04 1.434-.174 1.943-.372a3.916 3.916 0 0 0 1.416-.923c.445-.445.718-.891.923-1.417.197-.509.332-1.09.372-1.942C15.99 10.445 16 10.173 16 8s-.01-2.445-.048-3.299c-.04-.851-.175-1.433-.372-1.941a3.926 3.926 0 0 0-.923-1.417A3.911 3.911 0 0 0 13.24.42c-.51-.198-1.092-.333-1.943-.372C10.443.01 10.172 0 7.998 0h.003zm-.717 1.442h.718c2.136 0 2.389.007 3.232.046.78.035 1.204.166 1.486.275.373.145.64.319.92.599.28.28.453.546.598.92.11.281.24.705.275 1.485.039.843.047 1.096.047 3.231s-.008 2.389-.047 3.232c-.035.78-.166 1.203-.275 1.485a2.47 2.47 0 0 1-.599.919c-.28.28-.546.453-.92.598-.28.11-.704.24-1.485.276-.843.038-1.096.047-3.232.047s-2.39-.009-3.233-.047c-.78-.036-1.203-.166-1.485-.276a2.478 2.478 0 0 1-.92-.598 2.48 2.48 0 0 1-.6-.92c-.109-.281-.24-.705-.275-1.485-.038-.843-.046-1.096-.046-3.233 0-2.136.008-2.388.046-3.231.036-.78.166-1.204.276-1.486.145-.373.319-.64.599-.92.28-.28.546-.453.92-.598.282-.11.705-.24 1.485-.276.738-.034 1.024-.044 2.515-.045v.002zm4.988 1.328a.96.96 0 1 0 0 1.92.96.96 0 0 0 0-1.92zm-4.27 1.122a4.109 4.109 0 1 0 0 8.217 4.109 4.109 0 0 0 0-8.217zm0 1.441a2.667 2.667 0 1 1 0 5.334 2.667 2.667 0 0 1 0-5.334" />
                        </svg></a>
                </div>


            </div>

            <div>
                <span>Need help?</span>
                <a href="mailto:info@redragonzone.pk">info@redragonzone.pk</a>
            </div>

        </div>

        <div class="d-flex justify-content-between  align-items-center box1 ">
            <div><img src="picc/redragon.png" width="130px" height="90px" alt=""></div>

            <div>
      <a href="cart.php"> <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-cart"
        viewBox="0 0 16 16">
        <path
          d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .491.592l-1.5 8A.5.5 0 0 1 13 12H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5M3.102 4l1.313 7h8.17l1.313-7H3.102zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4m7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4m-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2m7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2" />
      </svg></a>
  
    </div>
        </div>


        <div>
            <div class="d-flex justify-content-between box2 p-3">
                <div>
                    <p><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                            class="bi bi-truck" viewBox="0 0 16 16">
                            <path
                                d="M0 3.5A1.5 1.5 0 0 1 1.5 2h9A1.5 1.5 0 0 1 12 3.5V5h1.02a1.5 1.5 0 0 1 1.17.563l1.481 1.85a1.5 1.5 0 0 1 .329.938V10.5a1.5 1.5 0 0 1-1.5 1.5H14a2 2 0 1 1-4 0H5a2 2 0 1 1-3.998-.085A1.5 1.5 0 0 1 0 10.5zm1.294 7.456A1.999 1.999 0 0 1 4.732 11h5.536a2.01 2.01 0 0 1 .732-.732V3.5a.5.5 0 0 0-.5-.5h-9a.5.5 0 0 0-.5.5v7a.5.5 0 0 0 .294.456M12 10a2 2 0 0 1 1.732 1h.768a.5.5 0 0 0 .5-.5V8.35a.5.5 0 0 0-.11-.312l-1.48-1.85A.5.5 0 0 0 13.02 6H12zm-9 1a1 1 0 1 0 0 2 1 1 0 0 0 0-2m9 0a1 1 0 1 0 0 2 1 1 0 0 0 0-2" />
                        </svg>
                        NATIONWIDE SHIPPING</p>
                </div>

                <div>
                    <p> <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                            class="bi bi-box2" viewBox="0 0 16 16">
                            <path
                                d="M2.95.4a1 1 0 0 1 .8-.4h8.5a1 1 0 0 1 .8.4l2.85 3.8a.5.5 0 0 1 .1.3V15a1 1 0 0 1-1 1H1a1 1 0 0 1-1-1V4.5a.5.5 0 0 1 .1-.3L2.95.4ZM7.5 1H3.75L1.5 4h6zm1 0v3h6l-2.25-3zM15 5H1v10h14z" />
                        </svg>
                        GENUINE,BOX PACKED PRODUCTS</p>
                </div>

                <div>
                    <p><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                            class="bi bi-shield-shaded" viewBox="0 0 16 16">
                            <path fill-rule="evenodd"
                                d="M8 14.933a.615.615 0 0 0 .1-.025c.076-.023.174-.061.294-.118.24-.113.547-.29.893-.533a10.726 10.726 0 0 0 2.287-2.233c1.527-1.997 2.807-5.031 2.253-9.188a.48.48 0 0 0-.328-.39c-.651-.213-1.75-.56-2.837-.855C9.552 1.29 8.531 1.067 8 1.067zM5.072.56C6.157.265 7.31 0 8 0s1.843.265 2.928.56c1.11.3 2.229.655 2.887.87a1.54 1.54 0 0 1 1.044 1.262c.596 4.477-.787 7.795-2.465 9.99a11.775 11.775 0 0 1-2.517 2.453 7.159 7.159 0 0 1-1.048.625c-.28.132-.581.24-.829.24s-.548-.108-.829-.24a7.158 7.158 0 0 1-1.048-.625 11.777 11.777 0 0 1-2.517-2.453C1.928 10.487.545 7.169 1.141 2.692A1.54 1.54 0 0 1 2.185 1.43 62.456 62.456 0 0 1 5.072.56z" />
                        </svg>
                        COMPREHENSIVE BRAND SUPPORT</p>
                </div>
            </div>
        </div>
    </header>
    <img alt="splash-img-tpt" id="splash-img-tpt"
        style="pointer-events: none; position: absolute; top: 0; left: 0; width: 96vw; height: 96vh;"
        src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48c3ZnIHdpZHRoPSI5OTk5OXB4IiBoZWlnaHQ9Ijk5OTk5cHgiIHZpZXdCb3g9IjAgMCA5OTk5OSA5OTk5OSIgdmVyc2lvbj0iMS4xIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIj48ZyBzdHJva2U9Im5vbmUiIGZpbGw9Im5vbmUiIGZpbGwtb3BhY2l0eT0iMCI+PHJlY3QgeD0iMCIgeT0iMCIgd2lkdGg9Ijk5OTk5IiBoZWlnaHQ9Ijk5OTk5Ij48L3JlY3Q+IDwvZz4gPC9zdmc+">

    <div id="page-body" class="breadcrumb-color wide">
        <div id="body-content">
            <!-------------------------------main c-------------------------------------->
            <div class="main-content" id="main-content">
                <div class="wrap-breadcrumb bw-color ">
                    <div id="breadcrumb" class="breadcrumb-holder container">
                        <ul class="breadcrumb">
                            <li itemscope itemtype="http://data-vocabulary.org/Breadcrumb">
                                <a itemprop="url" href="/">
                                    <span itemprop="title" class="d-none">RedragonZone.PK</span>Home
                                </a>
                            </li>
                            <li itemscope itemtype="http://data-vocabulary.org/Breadcrumb" class="d-none">
                                <a href="/collections/gaming-mouse-price-in-pakistan" itemprop="url">
                                    <span itemprop="title">KEYBOARD</span>
                                </a>
                            </li>
                            <li class="active">KEYBOARD</li>
                        </ul>
                    </div>
                </div>
                <div class="page-cata active-sidebar" data-logic="false">
                    <div class="container">
                        <div class="row">
                            <div id="sidebar" class="left-column-container col-lg-3 col-md-12">
                                <div class="f-close d-lg-none" title="Close">
                                    <i class="demo-icon icon-close">
                                    </i>
                                </div>
                                <div class="sb-widget d-none d-lg-block">
                                    <div class="sb-menu">
                                        <h5 class="sb-title">SHOP</h5>
                                        <ul class="categories-menu">
                                            <li>
                                                <a href="combo.php">COMBO</a>
                                            </li>
                                            <li>
                                                <a href="headset.php">HEADSET</a>
                                            </li>
                                            <li>
                                                <a href="keyboard.php">KEYBOARD</a>
                                            </li>
                                            <li>
                                                <a href="mouse.php">MOUSE</a>
                                            </li>
                                            <li>
                                                <a href="mousepad.php">MOUSE PAD</a>
                                            </li>
                                            <li>
                                                <a href="stand1.php">HEADSET STAND</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="sb-widget d-none d-lg-block">
                                    <div class="sb-banner">
                                        <a href="/products/redragon-k530-rgb-draconic-gaming-keyboard-white">
                                            <span class="image-lazysize" style="position:relative;padding-top:100.0%;">
                                                <img class="img-lazy "
                                                    src="//redragonzone.pk/cdn/shop/files/redragon-k530-draconic-gaming-keyboard-redragonzone-pk-redragon-pakistan_330x.jpg?v=1691194943"
                                                    alt="redragon k530 draconic gaming keyboard at redragonzone.pk redragon pakistan" />
                                            </span>
                                        </a>
                                    </div>
                                </div>
                                <div class="sb-widget d-none d-lg-block">
                                    <div class="sb-banner">
                                        <a href="/products/redragon-k552-rgb-1-kumara-mechanical-gaming-keyboard">
                                            <span class="image-lazysize"
                                                style="position:relative;padding-top:73.33333333333334%;">
                                                <img class="img-lazy "
                                                    src="//redragonzone.pk/cdn/shop/files/redragon-k552-redragonzone-pk-redragon-pakistan-banner-mobile_330x.jpg?v=1691192420" />
                                            </span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="main-cata-page col-lg-9 col-md-12 col-sm-12 col-12">
                                <div class="block-banner subcollections-three-banners">
                                    <div class="row">
                                    </div>
                                </div>
                                <div class="cata-toolbar">
                                    <div class="group-toolbar">
                                        <div class="cata-title">
                                            <h1>KEYBOARD</h1>
                                        </div>
                                        <div class="grid-list">
                                            <span class="text">View</span>
                                        </div>
                                        <div class="sort-by bc-toggle">
                                            <div class="sort-by-inner">

                                                <label class="d-none d-md-block">Products</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
<!--------------------------------------------------------------------------------------------------------------->

                                <div id="col-main">


                                    <div class="cata-product cp-grid">




                                        <div class="product-grid-item mode-view-item">







                                            <div class="product-wrapper effect-overlay ">

                                                <div class="product-head">
                                                    <div class="product-image">

                                                        <div class="featured-img product-ratio-auto">
                                                            <a
                                                                href="/collections/gaming-keyboard-price-in-pakistan/products/redragon-k530-rgb-draconic-gaming-keyboard">










                                                                <span class="image-lazysize">
                                                                    <!-- noscript pattern -->
                                                                    <noscript>
                                                                        <img class="img-lazy product-ratio-auto featured-image front"
                                                                            src="//redragonzone.pk/cdn/shop/products/K530_RGB_1_450x450_b6e4a45d-c1be-4067-9552-8f70b8760c1c_420x.png?v=1627590664"
                                                                            alt="Redragon K530 RGB Draconic Wireless Mechanical Gaming Keyboard with Tactile Brown Switches - Redragon Pakistan" />
                                                                    </noscript>

                                                                    <img class="featured-image front img-lazy blur-up auto-crop-false lazyautosizes lazyloaded"
                                                                        data-widths="[180, 320, 540, 720, 1080, 1366, 1920, 2048] "
                                                                        data-aspectratio="1.0" data-sizes="auto"
                                                                        data-parent-fit="cover"
                                                                        alt="Redragon K530 RGB Draconic Wireless Mechanical Gaming Keyboard with Tactile Brown Switches - Redragon Pakistan"
                                                                        data-srcset="//redragonzone.pk/cdn/shop/products/K530_RGB_1_450x450_b6e4a45d-c1be-4067-9552-8f70b8760c1c_180x.png?v=1627590664 180w, //redragonzone.pk/cdn/shop/products/K530_RGB_1_450x450_b6e4a45d-c1be-4067-9552-8f70b8760c1c_320x.png?v=1627590664 320w, //redragonzone.pk/cdn/shop/products/K530_RGB_1_450x450_b6e4a45d-c1be-4067-9552-8f70b8760c1c_540x.png?v=1627590664 540w, //redragonzone.pk/cdn/shop/products/K530_RGB_1_450x450_b6e4a45d-c1be-4067-9552-8f70b8760c1c_720x.png?v=1627590664 720w, //redragonzone.pk/cdn/shop/products/K530_RGB_1_450x450_b6e4a45d-c1be-4067-9552-8f70b8760c1c_1080x.png?v=1627590664 1080w, //redragonzone.pk/cdn/shop/products/K530_RGB_1_450x450_b6e4a45d-c1be-4067-9552-8f70b8760c1c_1366x.png?v=1627590664 1366w, //redragonzone.pk/cdn/shop/products/K530_RGB_1_450x450_b6e4a45d-c1be-4067-9552-8f70b8760c1c_1920x.png?v=1627590664 1920w, //redragonzone.pk/cdn/shop/products/K530_RGB_1_450x450_b6e4a45d-c1be-4067-9552-8f70b8760c1c_2048x.png?v=1627590664 2048w"
                                                                        sizes="197px"
                                                                        srcset="//redragonzone.pk/cdn/shop/products/K530_RGB_1_450x450_b6e4a45d-c1be-4067-9552-8f70b8760c1c_180x.png?v=1627590664 180w, //redragonzone.pk/cdn/shop/products/K530_RGB_1_450x450_b6e4a45d-c1be-4067-9552-8f70b8760c1c_320x.png?v=1627590664 320w, //redragonzone.pk/cdn/shop/products/K530_RGB_1_450x450_b6e4a45d-c1be-4067-9552-8f70b8760c1c_540x.png?v=1627590664 540w, //redragonzone.pk/cdn/shop/products/K530_RGB_1_450x450_b6e4a45d-c1be-4067-9552-8f70b8760c1c_720x.png?v=1627590664 720w, //redragonzone.pk/cdn/shop/products/K530_RGB_1_450x450_b6e4a45d-c1be-4067-9552-8f70b8760c1c_1080x.png?v=1627590664 1080w, //redragonzone.pk/cdn/shop/products/K530_RGB_1_450x450_b6e4a45d-c1be-4067-9552-8f70b8760c1c_1366x.png?v=1627590664 1366w, //redragonzone.pk/cdn/shop/products/K530_RGB_1_450x450_b6e4a45d-c1be-4067-9552-8f70b8760c1c_1920x.png?v=1627590664 1920w, //redragonzone.pk/cdn/shop/products/K530_RGB_1_450x450_b6e4a45d-c1be-4067-9552-8f70b8760c1c_2048x.png?v=1627590664 2048w">
                                                                </span>



                                                            </a>
                                                        </div>

                                                    </div>


                                                    

                                                </div>

                                                <div class="product-content">
                                                    <div class="pc-inner">

                                                        <div class="product-group-vendor-name">
                                                            <div class="product-vendor"><a
                                                                    href="/collections/vendors?q=REDRAGON"
                                                                    title="REDRAGON">REDRAGON</a></div>
                                                            <h5 class="product-name balance-false"><a
                                                                    href="key1.php">Redragon
                                                                    K530 RGB Draconic Wireless Mechanical Gaming
                                                                    Keyboard with Tactile Brown Switches (Black)</a>
                                                            </h5>

                                                            <div class="product-review">

                                                                <span class="shopify-product-reviews-badge"
                                                                    data-id="5319943553175"></span>

                                                            </div>

                                                        </div>


                                                        <div class="product-price notranslate">

                                                            <span class="price">Rs. <?php $KeyboardRow = mysqli_fetch_assoc($KeyboardPricesResult); echo $KeyboardRow['Price']; ?></span>

                                                        </div>



                                                        <div class="product-list-mode-content">


                                                        </div>

                                                    </div>
                                                </div>

                                                <div class="product-list-mode-content-v2">
                                                    <div class="list-v2-inner">
                                                        



                                                    </div>
                                                </div>

                                            </div>


                                        </div>

                                        <div class="product-grid-item mode-view-item">







                                            <div class="product-wrapper effect-overlay ">

                                                <div class="product-head">
                                                    <div class="product-image">

                                                        <div class="featured-img product-ratio-auto">
                                                            <a
                                                                href="/collections/gaming-keyboard-price-in-pakistan/products/redragon-k530-rgb-draconic-gaming-keyboard-white">

                                                                <span class="image-lazysize">
                                                                    <!-- noscript pattern -->
                                                                    <noscript>
                                                                        <img class="img-lazy product-ratio-auto featured-image front"
                                                                            src="//redragonzone.pk/cdn/shop/products/61mIZxjXL0L._AC_SX522_420x.jpg?v=1608720303"
                                                                            alt="Redragon K530 RGB Draconic Wireless Mechanical Gaming Keyboard with Tactile Brown Switches - Redragon Pakistan" />
                                                                    </noscript>

                                                                    <img class="featured-image front img-lazy blur-up auto-crop-false lazyautosizes lazyloaded"
                                                                        data-widths="[180, 320, 540, 720, 1080, 1366, 1920, 2048] "
                                                                        data-aspectratio="1.0" data-sizes="auto"
                                                                        data-parent-fit="cover"
                                                                        alt="Redragon K530 RGB Draconic Wireless Mechanical Gaming Keyboard with Tactile Brown Switches - Redragon Pakistan"
                                                                        data-srcset="//redragonzone.pk/cdn/shop/products/61mIZxjXL0L._AC_SX522_180x.jpg?v=1608720303 180w, //redragonzone.pk/cdn/shop/products/61mIZxjXL0L._AC_SX522_320x.jpg?v=1608720303 320w, //redragonzone.pk/cdn/shop/products/61mIZxjXL0L._AC_SX522_540x.jpg?v=1608720303 540w, //redragonzone.pk/cdn/shop/products/61mIZxjXL0L._AC_SX522_720x.jpg?v=1608720303 720w, //redragonzone.pk/cdn/shop/products/61mIZxjXL0L._AC_SX522_1080x.jpg?v=1608720303 1080w, //redragonzone.pk/cdn/shop/products/61mIZxjXL0L._AC_SX522_1366x.jpg?v=1608720303 1366w, //redragonzone.pk/cdn/shop/products/61mIZxjXL0L._AC_SX522_1920x.jpg?v=1608720303 1920w, //redragonzone.pk/cdn/shop/products/61mIZxjXL0L._AC_SX522_2048x.jpg?v=1608720303 2048w"
                                                                        sizes="197px"
                                                                        srcset="//redragonzone.pk/cdn/shop/products/61mIZxjXL0L._AC_SX522_180x.jpg?v=1608720303 180w, //redragonzone.pk/cdn/shop/products/61mIZxjXL0L._AC_SX522_320x.jpg?v=1608720303 320w, //redragonzone.pk/cdn/shop/products/61mIZxjXL0L._AC_SX522_540x.jpg?v=1608720303 540w, //redragonzone.pk/cdn/shop/products/61mIZxjXL0L._AC_SX522_720x.jpg?v=1608720303 720w, //redragonzone.pk/cdn/shop/products/61mIZxjXL0L._AC_SX522_1080x.jpg?v=1608720303 1080w, //redragonzone.pk/cdn/shop/products/61mIZxjXL0L._AC_SX522_1366x.jpg?v=1608720303 1366w, //redragonzone.pk/cdn/shop/products/61mIZxjXL0L._AC_SX522_1920x.jpg?v=1608720303 1920w, //redragonzone.pk/cdn/shop/products/61mIZxjXL0L._AC_SX522_2048x.jpg?v=1608720303 2048w">
                                                                </span>


                                                            </a>
                                                        </div>



                                                        

                                                    </div>


                                                    

                                                </div>

                                                <div class="product-content">
                                                    <div class="pc-inner">


                                                        


                                                        <div class="product-group-vendor-name">
                                                            <div class="product-vendor"><a
                                                                    href="/collections/vendors?q=REDRAGON"
                                                                    title="REDRAGON">REDRAGON</a></div>
                                                            <h5 class="product-name balance-false"><a
                                                                    href="key2.php">Redragon
                                                                    K530 RGB Draconic Wireless Mechanical Gaming
                                                                    Keyboard with Tactile Brown Switches (White)</a>
                                                            </h5>

                                                            <div class="product-review">

                                                                <span class="shopify-product-reviews-badge"
                                                                    data-id="6242679685271"></span>

                                                            </div>

                                                        </div>






                                                        <div class="product-price notranslate">

                                                            <span class="price">Rs. <?php $KeyboardRow = mysqli_fetch_assoc($KeyboardPricesResult); echo $KeyboardRow['Price']; ?></span>

                                                        </div>



                                                        <div class="product-list-mode-content">


                                                            


                                                            




                                                        </div>

                                                    </div>
                                                </div>

                                                <div class="product-list-mode-content-v2">
                                                    <div class="list-v2-inner">
                                                        


                                                    </div>
                                                </div>

                                            </div>


                                        </div>

                                        <div class="product-grid-item mode-view-item">







                                            <div class="product-wrapper effect-overlay ">

                                                <div class="product-head">
                                                    <div class="product-image">

                                                        <div class="featured-img product-ratio-auto">
                                                            <a
                                                                href="/collections/gaming-keyboard-price-in-pakistan/products/redragon-k630-dragonborn-rgb-gaming-keyboard-white">










                                                                <span class="image-lazysize">
                                                                    <!-- noscript pattern -->
                                                                    <noscript>
                                                                        <img class="img-lazy product-ratio-auto featured-image front"
                                                                            src="//redragonzone.pk/cdn/shop/products/K630WT_450x450_ec9dfae5-3a55-4c1b-a0c9-764cece47e19_420x.png?v=1627737275"
                                                                            alt="Redragon K630 Dragonborn RGB Mechanical Gaming Keyboard - Redragon Pakistan" />
                                                                    </noscript>

                                                                    <img class="featured-image front img-lazy blur-up auto-crop-false lazyautosizes lazyloaded"
                                                                        data-widths="[180, 320, 540, 720, 1080, 1366, 1920, 2048] "
                                                                        data-aspectratio="1.0" data-sizes="auto"
                                                                        data-parent-fit="cover"
                                                                        alt="Redragon K630 Dragonborn RGB Mechanical Gaming Keyboard - Redragon Pakistan"
                                                                        data-srcset="//redragonzone.pk/cdn/shop/products/K630WT_450x450_ec9dfae5-3a55-4c1b-a0c9-764cece47e19_180x.png?v=1627737275 180w, //redragonzone.pk/cdn/shop/products/K630WT_450x450_ec9dfae5-3a55-4c1b-a0c9-764cece47e19_320x.png?v=1627737275 320w, //redragonzone.pk/cdn/shop/products/K630WT_450x450_ec9dfae5-3a55-4c1b-a0c9-764cece47e19_540x.png?v=1627737275 540w, //redragonzone.pk/cdn/shop/products/K630WT_450x450_ec9dfae5-3a55-4c1b-a0c9-764cece47e19_720x.png?v=1627737275 720w, //redragonzone.pk/cdn/shop/products/K630WT_450x450_ec9dfae5-3a55-4c1b-a0c9-764cece47e19_1080x.png?v=1627737275 1080w, //redragonzone.pk/cdn/shop/products/K630WT_450x450_ec9dfae5-3a55-4c1b-a0c9-764cece47e19_1366x.png?v=1627737275 1366w, //redragonzone.pk/cdn/shop/products/K630WT_450x450_ec9dfae5-3a55-4c1b-a0c9-764cece47e19_1920x.png?v=1627737275 1920w, //redragonzone.pk/cdn/shop/products/K630WT_450x450_ec9dfae5-3a55-4c1b-a0c9-764cece47e19_2048x.png?v=1627737275 2048w"
                                                                        sizes="197px"
                                                                        srcset="//redragonzone.pk/cdn/shop/products/K630WT_450x450_ec9dfae5-3a55-4c1b-a0c9-764cece47e19_180x.png?v=1627737275 180w, //redragonzone.pk/cdn/shop/products/K630WT_450x450_ec9dfae5-3a55-4c1b-a0c9-764cece47e19_320x.png?v=1627737275 320w, //redragonzone.pk/cdn/shop/products/K630WT_450x450_ec9dfae5-3a55-4c1b-a0c9-764cece47e19_540x.png?v=1627737275 540w, //redragonzone.pk/cdn/shop/products/K630WT_450x450_ec9dfae5-3a55-4c1b-a0c9-764cece47e19_720x.png?v=1627737275 720w, //redragonzone.pk/cdn/shop/products/K630WT_450x450_ec9dfae5-3a55-4c1b-a0c9-764cece47e19_1080x.png?v=1627737275 1080w, //redragonzone.pk/cdn/shop/products/K630WT_450x450_ec9dfae5-3a55-4c1b-a0c9-764cece47e19_1366x.png?v=1627737275 1366w, //redragonzone.pk/cdn/shop/products/K630WT_450x450_ec9dfae5-3a55-4c1b-a0c9-764cece47e19_1920x.png?v=1627737275 1920w, //redragonzone.pk/cdn/shop/products/K630WT_450x450_ec9dfae5-3a55-4c1b-a0c9-764cece47e19_2048x.png?v=1627737275 2048w">
                                                                </span>



                                                                <span class="product-label flex">

                                                                    <span class="label-new">
                                                                        <span class="new-text">New</span>
                                                                    </span>


                                                                    <span class="label-sale">

                                                                        <span class="sale-text">Sale</span>

                                                                    </span>

                                                                </span>

                                                            </a>
                                                        </div>

                                                    </div>


                                                    

                                                </div>

                                                <div class="product-content">
                                                    <div class="pc-inner">


                                                       

                                                        <div class="product-group-vendor-name">
                                                            <div class="product-vendor"><a
                                                                    href="/collections/vendors?q=REDRAGON"
                                                                    title="REDRAGON">REDRAGON</a></div>
                                                            <h5 class="product-name balance-false"><a
                                                                    href="key3.php">Redragon
                                                                    K630 Dragonborn RGB Mechanical Gaming Keyboard
                                                                    (White)</a></h5>

                                                            <div class="product-review">

                                                                <span class="shopify-product-reviews-badge"
                                                                    data-id="6907211677847"></span>

                                                            </div>

                                                        </div>






                                                        <div class="product-price notranslate">

                                                            <span class="price-compare">Rs. 10,780</span>
                                                            <span class="price-sale">Rs. <?php $KeyboardRow = mysqli_fetch_assoc($KeyboardPricesResult); echo $KeyboardRow['Price']; ?></span>

                                                        </div>



                                                        <div class="product-list-mode-content">


                                                            


                                                           



                                                        </div>

                                                    </div>
                                                </div>

                                                <div class="product-list-mode-content-v2">
                                                    <div class="list-v2-inner">
                                                       



                                                    </div>
                                                </div>

                                            </div>


                                        </div>

                                        <div class="product-grid-item mode-view-item">







                                            <div class="product-wrapper effect-overlay ">

                                                <div class="product-head">
                                                    <div class="product-image">

                                                        <div class="featured-img product-ratio-auto">
                                                            <a
                                                                href="/collections/gaming-keyboard-price-in-pakistan/products/redragon-k552-rgb-1-kumara-mechanical-gaming-keyboard">


                                                                <span class="image-lazysize">
                                                                    <!-- noscript pattern -->
                                                                    <noscript>
                                                                        <img class="img-lazy product-ratio-auto featured-image front"
                                                                            src="//redragonzone.pk/cdn/shop/products/K552R-2-1_450x450_4c61c8f6-ee5f-4115-a091-b99b99b3f68a_420x.png?v=1627644298"
                                                                            alt="Redragon K552 RGB-1 KUMARA Full Anti Ghosting Mechanical Gaming Keyboard, 87 Keys - Redragon Pakistan" />
                                                                    </noscript>

                                                                    <img class="featured-image front img-lazy blur-up auto-crop-false lazyautosizes lazyloaded"
                                                                        data-widths="[180, 320, 540, 720, 1080, 1366, 1920, 2048] "
                                                                        data-aspectratio="1.0" data-sizes="auto"
                                                                        data-parent-fit="cover"
                                                                        alt="Redragon K552 RGB-1 KUMARA Full Anti Ghosting Mechanical Gaming Keyboard, 87 Keys - Redragon Pakistan"
                                                                        data-srcset="//redragonzone.pk/cdn/shop/products/K552R-2-1_450x450_4c61c8f6-ee5f-4115-a091-b99b99b3f68a_180x.png?v=1627644298 180w, //redragonzone.pk/cdn/shop/products/K552R-2-1_450x450_4c61c8f6-ee5f-4115-a091-b99b99b3f68a_320x.png?v=1627644298 320w, //redragonzone.pk/cdn/shop/products/K552R-2-1_450x450_4c61c8f6-ee5f-4115-a091-b99b99b3f68a_540x.png?v=1627644298 540w, //redragonzone.pk/cdn/shop/products/K552R-2-1_450x450_4c61c8f6-ee5f-4115-a091-b99b99b3f68a_720x.png?v=1627644298 720w, //redragonzone.pk/cdn/shop/products/K552R-2-1_450x450_4c61c8f6-ee5f-4115-a091-b99b99b3f68a_1080x.png?v=1627644298 1080w, //redragonzone.pk/cdn/shop/products/K552R-2-1_450x450_4c61c8f6-ee5f-4115-a091-b99b99b3f68a_1366x.png?v=1627644298 1366w, //redragonzone.pk/cdn/shop/products/K552R-2-1_450x450_4c61c8f6-ee5f-4115-a091-b99b99b3f68a_1920x.png?v=1627644298 1920w, //redragonzone.pk/cdn/shop/products/K552R-2-1_450x450_4c61c8f6-ee5f-4115-a091-b99b99b3f68a_2048x.png?v=1627644298 2048w"
                                                                        sizes="197px"
                                                                        srcset="//redragonzone.pk/cdn/shop/products/K552R-2-1_450x450_4c61c8f6-ee5f-4115-a091-b99b99b3f68a_180x.png?v=1627644298 180w, //redragonzone.pk/cdn/shop/products/K552R-2-1_450x450_4c61c8f6-ee5f-4115-a091-b99b99b3f68a_320x.png?v=1627644298 320w, //redragonzone.pk/cdn/shop/products/K552R-2-1_450x450_4c61c8f6-ee5f-4115-a091-b99b99b3f68a_540x.png?v=1627644298 540w, //redragonzone.pk/cdn/shop/products/K552R-2-1_450x450_4c61c8f6-ee5f-4115-a091-b99b99b3f68a_720x.png?v=1627644298 720w, //redragonzone.pk/cdn/shop/products/K552R-2-1_450x450_4c61c8f6-ee5f-4115-a091-b99b99b3f68a_1080x.png?v=1627644298 1080w, //redragonzone.pk/cdn/shop/products/K552R-2-1_450x450_4c61c8f6-ee5f-4115-a091-b99b99b3f68a_1366x.png?v=1627644298 1366w, //redragonzone.pk/cdn/shop/products/K552R-2-1_450x450_4c61c8f6-ee5f-4115-a091-b99b99b3f68a_1920x.png?v=1627644298 1920w, //redragonzone.pk/cdn/shop/products/K552R-2-1_450x450_4c61c8f6-ee5f-4115-a091-b99b99b3f68a_2048x.png?v=1627644298 2048w">
                                                                </span>














                                                                <span class="product-label flex">







                                                                    <span class="label-new">
                                                                        <span class="new-text">New</span>
                                                                    </span>


                                                                </span>

                                                            </a>
                                                        </div>



                                                        

                                                    </div>


                                                    

                                                </div>

                                                <div class="product-content">
                                                    <div class="pc-inner">


                                                        


                                                        <div class="product-group-vendor-name">
                                                            <div class="product-vendor"><a
                                                                    href="/collections/vendors?q=REDRAGON"
                                                                    title="REDRAGON">REDRAGON</a></div>
                                                            <h5 class="product-name balance-false"><a
                                                                    href="key4.php">Redragon
                                                                    K552 RGB-1 KUMARA Full Anti Ghosting Mechanical
                                                                    Gaming Keyboard, 87 Keys</a></h5>

                                                            <div class="product-review">

                                                                <span class="shopify-product-reviews-badge"
                                                                    data-id="6473988669591"></span>

                                                            </div>

                                                        </div>






                                                        <div class="product-price notranslate">

                                                            <span class="price">Rs. <?php $KeyboardRow = mysqli_fetch_assoc($KeyboardPricesResult); echo $KeyboardRow['Price']; ?></span>

                                                        </div>



                                                        <div class="product-list-mode-content">


                                                            






                                                           


                                                            




                                                        </div>

                                                    </div>
                                                </div>

                                                <div class="product-list-mode-content-v2">
                                                    <div class="list-v2-inner">
                                                        



                                                    </div>
                                                </div>

                                            </div>


                                        </div>

                                        <div class="product-grid-item mode-view-item">







                                            <div class="product-wrapper effect-overlay ">

                                                <div class="product-head">
                                                    <div class="product-image">

                                                        <div class="featured-img product-ratio-auto">
                                                            <a
                                                                href="/collections/gaming-keyboard-price-in-pakistan/products/redragon-k512-shiva-rgb-gaming-keyboard">










                                                                <span class="image-lazysize">
                                                                    <!-- noscript pattern -->
                                                                    <noscript>
                                                                        <img class="img-lazy product-ratio-auto featured-image front"
                                                                            src="//redragonzone.pk/cdn/shop/products/K512RGB-1_450x450_6ef1cfaa-87b2-429e-914e-9f7422ae21c5_420x.png?v=1627589792"
                                                                            alt="Redragon K512 SHIVA RGB Backlit Membrane Gaming Keyboard - Redragon Pakistan" />
                                                                    </noscript>

                                                                    <img class="featured-image front img-lazy blur-up auto-crop-false lazyautosizes lazyloaded"
                                                                        data-widths="[180, 320, 540, 720, 1080, 1366, 1920, 2048] "
                                                                        data-aspectratio="1.0" data-sizes="auto"
                                                                        data-parent-fit="cover"
                                                                        alt="Redragon K512 SHIVA RGB Backlit Membrane Gaming Keyboard - Redragon Pakistan"
                                                                        data-srcset="//redragonzone.pk/cdn/shop/products/K512RGB-1_450x450_6ef1cfaa-87b2-429e-914e-9f7422ae21c5_180x.png?v=1627589792 180w, //redragonzone.pk/cdn/shop/products/K512RGB-1_450x450_6ef1cfaa-87b2-429e-914e-9f7422ae21c5_320x.png?v=1627589792 320w, //redragonzone.pk/cdn/shop/products/K512RGB-1_450x450_6ef1cfaa-87b2-429e-914e-9f7422ae21c5_540x.png?v=1627589792 540w, //redragonzone.pk/cdn/shop/products/K512RGB-1_450x450_6ef1cfaa-87b2-429e-914e-9f7422ae21c5_720x.png?v=1627589792 720w, //redragonzone.pk/cdn/shop/products/K512RGB-1_450x450_6ef1cfaa-87b2-429e-914e-9f7422ae21c5_1080x.png?v=1627589792 1080w, //redragonzone.pk/cdn/shop/products/K512RGB-1_450x450_6ef1cfaa-87b2-429e-914e-9f7422ae21c5_1366x.png?v=1627589792 1366w, //redragonzone.pk/cdn/shop/products/K512RGB-1_450x450_6ef1cfaa-87b2-429e-914e-9f7422ae21c5_1920x.png?v=1627589792 1920w, //redragonzone.pk/cdn/shop/products/K512RGB-1_450x450_6ef1cfaa-87b2-429e-914e-9f7422ae21c5_2048x.png?v=1627589792 2048w"
                                                                        sizes="197px"
                                                                        srcset="//redragonzone.pk/cdn/shop/products/K512RGB-1_450x450_6ef1cfaa-87b2-429e-914e-9f7422ae21c5_180x.png?v=1627589792 180w, //redragonzone.pk/cdn/shop/products/K512RGB-1_450x450_6ef1cfaa-87b2-429e-914e-9f7422ae21c5_320x.png?v=1627589792 320w, //redragonzone.pk/cdn/shop/products/K512RGB-1_450x450_6ef1cfaa-87b2-429e-914e-9f7422ae21c5_540x.png?v=1627589792 540w, //redragonzone.pk/cdn/shop/products/K512RGB-1_450x450_6ef1cfaa-87b2-429e-914e-9f7422ae21c5_720x.png?v=1627589792 720w, //redragonzone.pk/cdn/shop/products/K512RGB-1_450x450_6ef1cfaa-87b2-429e-914e-9f7422ae21c5_1080x.png?v=1627589792 1080w, //redragonzone.pk/cdn/shop/products/K512RGB-1_450x450_6ef1cfaa-87b2-429e-914e-9f7422ae21c5_1366x.png?v=1627589792 1366w, //redragonzone.pk/cdn/shop/products/K512RGB-1_450x450_6ef1cfaa-87b2-429e-914e-9f7422ae21c5_1920x.png?v=1627589792 1920w, //redragonzone.pk/cdn/shop/products/K512RGB-1_450x450_6ef1cfaa-87b2-429e-914e-9f7422ae21c5_2048x.png?v=1627589792 2048w">
                                                                </span>


                                                                <span class="product-label flex">

                                                                    <span class="label-new">
                                                                        <span class="new-text">New</span>
                                                                    </span>


                                                                </span>

                                                            </a>
                                                        </div>



                                                        

                                                    </div>


                                                    

                                                </div>

                                                <div class="product-content">
                                                    <div class="pc-inner">


                                                        


                                                        <div class="product-group-vendor-name">
                                                            <div class="product-vendor"><a
                                                                    href="/collections/vendors?q=REDRAGON"
                                                                    title="REDRAGON">REDRAGON</a></div>
                                                            <h5 class="product-name balance-false"><a
                                                                    href="key5.php">Redragon
                                                                    K512 SHIVA RGB Backlit Membrane Gaming Keyboard</a>
                                                            </h5>

                                                            <div class="product-review">

                                                                <span class="shopify-product-reviews-badge"
                                                                    data-id="6473952297111"></span>

                                                            </div>

                                                        </div>






                                                        <div class="product-price notranslate">

                                                            <span class="price">Rs. <?php $KeyboardRow = mysqli_fetch_assoc($KeyboardPricesResult); echo $KeyboardRow['Price']; ?></span>

                                                        </div>



                                                        <div class="product-list-mode-content">

                                                        </div>

                                                    </div>
                                                </div>

                                                <div class="product-list-mode-content-v2">
                                                    <div class="list-v2-inner">
                                                        



                                                    </div>
                                                </div>

                                            </div>


                                        </div>

                                        <div class="product-grid-item mode-view-item">


                                            <div class="product-wrapper effect-overlay ">

                                                <div class="product-head">
                                                    <div class="product-image">

                                                        <div class="featured-img product-ratio-auto">
                                                            <a
                                                                href="/collections/gaming-keyboard-price-in-pakistan/products/redragon-surara-k582-pro-rgb-gaming-keyboard">



                                                                <span class="image-lazysize">
                                                                    <!-- noscript pattern -->
                                                                    <noscript>
                                                                        <img class="img-lazy product-ratio-auto featured-image front"
                                                                            src="//redragonzone.pk/cdn/shop/products/Redragon_SURARA_K582-PRO_RGB_Mechanical_Gaming_Keyboard-1_420x.png?v=1628076547"
                                                                            alt="Redragon K582 SURARA RGB LED Backlit Mechanical Gaming Keyboard - Redragon Pakistan" />
                                                                    </noscript>

                                                                    <img class="featured-image front img-lazy blur-up auto-crop-false lazyautosizes lazyloaded"
                                                                        data-widths="[180, 320, 540, 720, 1080, 1366, 1920, 2048] "
                                                                        data-aspectratio="1.0" data-sizes="auto"
                                                                        data-parent-fit="cover"
                                                                        alt="Redragon K582 SURARA RGB LED Backlit Mechanical Gaming Keyboard - Redragon Pakistan"
                                                                        data-srcset="//redragonzone.pk/cdn/shop/products/Redragon_SURARA_K582-PRO_RGB_Mechanical_Gaming_Keyboard-1_180x.png?v=1628076547 180w, //redragonzone.pk/cdn/shop/products/Redragon_SURARA_K582-PRO_RGB_Mechanical_Gaming_Keyboard-1_320x.png?v=1628076547 320w, //redragonzone.pk/cdn/shop/products/Redragon_SURARA_K582-PRO_RGB_Mechanical_Gaming_Keyboard-1_540x.png?v=1628076547 540w, //redragonzone.pk/cdn/shop/products/Redragon_SURARA_K582-PRO_RGB_Mechanical_Gaming_Keyboard-1_720x.png?v=1628076547 720w, //redragonzone.pk/cdn/shop/products/Redragon_SURARA_K582-PRO_RGB_Mechanical_Gaming_Keyboard-1_1080x.png?v=1628076547 1080w, //redragonzone.pk/cdn/shop/products/Redragon_SURARA_K582-PRO_RGB_Mechanical_Gaming_Keyboard-1_1366x.png?v=1628076547 1366w, //redragonzone.pk/cdn/shop/products/Redragon_SURARA_K582-PRO_RGB_Mechanical_Gaming_Keyboard-1_1920x.png?v=1628076547 1920w, //redragonzone.pk/cdn/shop/products/Redragon_SURARA_K582-PRO_RGB_Mechanical_Gaming_Keyboard-1_2048x.png?v=1628076547 2048w"
                                                                        sizes="197px"
                                                                        srcset="//redragonzone.pk/cdn/shop/products/Redragon_SURARA_K582-PRO_RGB_Mechanical_Gaming_Keyboard-1_180x.png?v=1628076547 180w, //redragonzone.pk/cdn/shop/products/Redragon_SURARA_K582-PRO_RGB_Mechanical_Gaming_Keyboard-1_320x.png?v=1628076547 320w, //redragonzone.pk/cdn/shop/products/Redragon_SURARA_K582-PRO_RGB_Mechanical_Gaming_Keyboard-1_540x.png?v=1628076547 540w, //redragonzone.pk/cdn/shop/products/Redragon_SURARA_K582-PRO_RGB_Mechanical_Gaming_Keyboard-1_720x.png?v=1628076547 720w, //redragonzone.pk/cdn/shop/products/Redragon_SURARA_K582-PRO_RGB_Mechanical_Gaming_Keyboard-1_1080x.png?v=1628076547 1080w, //redragonzone.pk/cdn/shop/products/Redragon_SURARA_K582-PRO_RGB_Mechanical_Gaming_Keyboard-1_1366x.png?v=1628076547 1366w, //redragonzone.pk/cdn/shop/products/Redragon_SURARA_K582-PRO_RGB_Mechanical_Gaming_Keyboard-1_1920x.png?v=1628076547 1920w, //redragonzone.pk/cdn/shop/products/Redragon_SURARA_K582-PRO_RGB_Mechanical_Gaming_Keyboard-1_2048x.png?v=1628076547 2048w">
                                                                </span>


                                                            </a>
                                                        </div>



                                                        

                                                    </div>


                                                    
                                                </div>

                                                <div class="product-content">
                                                    <div class="pc-inner">


                                                        


                                                        <div class="product-group-vendor-name">
                                                            <div class="product-vendor"><a
                                                                    href="/collections/vendors?q=REDRAGON"
                                                                    title="REDRAGON">REDRAGON</a></div>
                                                            <h5 class="product-name balance-false"><a
                                                                    href="key6.php">Redragon
                                                                    K582 SURARA RGB LED Backlit Mechanical Gaming
                                                                    Keyboard</a></h5>

                                                            <div class="product-review">

                                                                <span class="shopify-product-reviews-badge"
                                                                    data-id="4543152947339"></span>

                                                            </div>

                                                        </div>






                                                        <div class="product-price notranslate">

                                                            <span class="price">Rs. <?php $KeyboardRow = mysqli_fetch_assoc($KeyboardPricesResult); echo $KeyboardRow['Price']; ?></span>

                                                        </div>



                                                        <div class="product-list-mode-content">


                                                        </div>

                                                    </div>
                                                </div>

                                                <div class="product-list-mode-content-v2">
                                                    <div class="list-v2-inner">
                                                        



                                                    </div>
                                                </div>

                                            </div>


                                        </div>

                                        <div class="product-grid-item mode-view-item">



                                            <div class="product-wrapper effect-overlay ">

                                                <div class="product-head">
                                                    <div class="product-image">

                                                        <div class="featured-img product-ratio-auto">
                                                            <a
                                                                href="/collections/gaming-keyboard-price-in-pakistan/products/redragon-devarajas-k556-mechanical-gaming-keyboard">










                                                                <span class="image-lazysize">
                                                                    <!-- noscript pattern -->
                                                                    <noscript>
                                                                        <img class="img-lazy product-ratio-auto featured-image front"
                                                                            src="//redragonzone.pk/cdn/shop/products/K556_450x450_fab7acb4-3706-47d8-8b79-a84bf5255bf2_420x.png?v=1635937177"
                                                                            alt="Redragon K556 DEVARAJAS RGB Mechanical Gaming Keyboard with Brown Switches - Redragon Pakistan" />
                                                                    </noscript>

                                                                    <img class="featured-image front img-lazy blur-up auto-crop-false lazyautosizes lazyloaded"
                                                                        data-widths="[180, 320, 540, 720, 1080, 1366, 1920, 2048] "
                                                                        data-aspectratio="1.0" data-sizes="auto"
                                                                        data-parent-fit="cover"
                                                                        alt="Redragon K556 DEVARAJAS RGB Mechanical Gaming Keyboard with Brown Switches - Redragon Pakistan"
                                                                        data-srcset="//redragonzone.pk/cdn/shop/products/K556_450x450_fab7acb4-3706-47d8-8b79-a84bf5255bf2_180x.png?v=1635937177 180w, //redragonzone.pk/cdn/shop/products/K556_450x450_fab7acb4-3706-47d8-8b79-a84bf5255bf2_320x.png?v=1635937177 320w, //redragonzone.pk/cdn/shop/products/K556_450x450_fab7acb4-3706-47d8-8b79-a84bf5255bf2_540x.png?v=1635937177 540w, //redragonzone.pk/cdn/shop/products/K556_450x450_fab7acb4-3706-47d8-8b79-a84bf5255bf2_720x.png?v=1635937177 720w, //redragonzone.pk/cdn/shop/products/K556_450x450_fab7acb4-3706-47d8-8b79-a84bf5255bf2_1080x.png?v=1635937177 1080w, //redragonzone.pk/cdn/shop/products/K556_450x450_fab7acb4-3706-47d8-8b79-a84bf5255bf2_1366x.png?v=1635937177 1366w, //redragonzone.pk/cdn/shop/products/K556_450x450_fab7acb4-3706-47d8-8b79-a84bf5255bf2_1920x.png?v=1635937177 1920w, //redragonzone.pk/cdn/shop/products/K556_450x450_fab7acb4-3706-47d8-8b79-a84bf5255bf2_2048x.png?v=1635937177 2048w"
                                                                        sizes="197px"
                                                                        srcset="//redragonzone.pk/cdn/shop/products/K556_450x450_fab7acb4-3706-47d8-8b79-a84bf5255bf2_180x.png?v=1635937177 180w, //redragonzone.pk/cdn/shop/products/K556_450x450_fab7acb4-3706-47d8-8b79-a84bf5255bf2_320x.png?v=1635937177 320w, //redragonzone.pk/cdn/shop/products/K556_450x450_fab7acb4-3706-47d8-8b79-a84bf5255bf2_540x.png?v=1635937177 540w, //redragonzone.pk/cdn/shop/products/K556_450x450_fab7acb4-3706-47d8-8b79-a84bf5255bf2_720x.png?v=1635937177 720w, //redragonzone.pk/cdn/shop/products/K556_450x450_fab7acb4-3706-47d8-8b79-a84bf5255bf2_1080x.png?v=1635937177 1080w, //redragonzone.pk/cdn/shop/products/K556_450x450_fab7acb4-3706-47d8-8b79-a84bf5255bf2_1366x.png?v=1635937177 1366w, //redragonzone.pk/cdn/shop/products/K556_450x450_fab7acb4-3706-47d8-8b79-a84bf5255bf2_1920x.png?v=1635937177 1920w, //redragonzone.pk/cdn/shop/products/K556_450x450_fab7acb4-3706-47d8-8b79-a84bf5255bf2_2048x.png?v=1635937177 2048w">
                                                                </span>





                                                            </a>
                                                        </div>



                                                        

                                                    </div>


                                                    

                                                </div>

                                                <div class="product-content">
                                                    <div class="pc-inner">

                                                        <div class="product-group-vendor-name">
                                                            <div class="product-vendor"><a
                                                                    href="/collections/vendors?q=REDRAGON"
                                                                    title="REDRAGON">REDRAGON</a></div>
                                                            <h5 class="product-name balance-false"><a
                                                                    href="key7.php">Redragon
                                                                    K556 DEVARAJAS RGB Mechanical Gaming Keyboard with
                                                                    Brown Switches</a></h5>

                                                            <div class="product-review">

                                                                <span class="shopify-product-reviews-badge"
                                                                    data-id="4543145934987"></span>

                                                            </div>

                                                        </div>






                                                        <div class="product-price notranslate">

                                                            <span class="price">Rs. <?php $KeyboardRow = mysqli_fetch_assoc($KeyboardPricesResult); echo $KeyboardRow['Price']; ?></span>

                                                        </div>



                                                        <div class="product-list-mode-content">


                                                            




                                                        </div>

                                                    </div>
                                                </div>

                                                <div class="product-list-mode-content-v2">
                                                    <div class="list-v2-inner">
                                                        



                                                    </div>
                                                </div>

                                            </div>


                                        </div>

                                        <div class="product-grid-item mode-view-item">







                                            <div class="product-wrapper effect-overlay ">

                                                <div class="product-head">
                                                    <div class="product-image">

                                                        <div class="featured-img product-ratio-auto">
                                                            <a
                                                                href="/collections/gaming-keyboard-price-in-pakistan/products/redragon-k568-dark-avenger-gaming-keyboard">










                                                                <span class="image-lazysize">
                                                                    <!-- noscript pattern -->
                                                                    <noscript>
                                                                        <img class="img-lazy product-ratio-auto featured-image front"
                                                                            src="//redragonzone.pk/cdn/shop/products/Redragon_Dark_Avengers_K568_420x.png?v=1627547263"
                                                                            alt="Redragon K568 DARK AVENGER RGB Backlit Mechanical Gaming Keyboard, 87 Keys - Redragon Pakistan" />
                                                                    </noscript>

                                                                    <img class="featured-image front img-lazy blur-up auto-crop-false lazyautosizes lazyloaded"
                                                                        data-widths="[180, 320, 540, 720, 1080, 1366, 1920, 2048] "
                                                                        data-aspectratio="1.0" data-sizes="auto"
                                                                        data-parent-fit="cover"
                                                                        alt="Redragon&nbsp;K568 DARK AVENGER RGB Backlit Mechanical Gaming Keyboard, 87 Keys - Redragon Pakistan"
                                                                        data-srcset="//redragonzone.pk/cdn/shop/products/Redragon_Dark_Avengers_K568_180x.png?v=1627547263 180w, //redragonzone.pk/cdn/shop/products/Redragon_Dark_Avengers_K568_320x.png?v=1627547263 320w, //redragonzone.pk/cdn/shop/products/Redragon_Dark_Avengers_K568_540x.png?v=1627547263 540w, //redragonzone.pk/cdn/shop/products/Redragon_Dark_Avengers_K568_720x.png?v=1627547263 720w, //redragonzone.pk/cdn/shop/products/Redragon_Dark_Avengers_K568_1080x.png?v=1627547263 1080w, //redragonzone.pk/cdn/shop/products/Redragon_Dark_Avengers_K568_1366x.png?v=1627547263 1366w, //redragonzone.pk/cdn/shop/products/Redragon_Dark_Avengers_K568_1920x.png?v=1627547263 1920w, //redragonzone.pk/cdn/shop/products/Redragon_Dark_Avengers_K568_2048x.png?v=1627547263 2048w"
                                                                        sizes="197px"
                                                                        srcset="//redragonzone.pk/cdn/shop/products/Redragon_Dark_Avengers_K568_180x.png?v=1627547263 180w, //redragonzone.pk/cdn/shop/products/Redragon_Dark_Avengers_K568_320x.png?v=1627547263 320w, //redragonzone.pk/cdn/shop/products/Redragon_Dark_Avengers_K568_540x.png?v=1627547263 540w, //redragonzone.pk/cdn/shop/products/Redragon_Dark_Avengers_K568_720x.png?v=1627547263 720w, //redragonzone.pk/cdn/shop/products/Redragon_Dark_Avengers_K568_1080x.png?v=1627547263 1080w, //redragonzone.pk/cdn/shop/products/Redragon_Dark_Avengers_K568_1366x.png?v=1627547263 1366w, //redragonzone.pk/cdn/shop/products/Redragon_Dark_Avengers_K568_1920x.png?v=1627547263 1920w, //redragonzone.pk/cdn/shop/products/Redragon_Dark_Avengers_K568_2048x.png?v=1627547263 2048w">
                                                                </span>










                                                            </a>
                                                        </div>



                                                        

                                                    </div>


                                                    

                                                </div>

                                                <div class="product-content">
                                                    <div class="pc-inner">


                                                        


                                                        <div class="product-group-vendor-name">
                                                            <div class="product-vendor"><a
                                                                    href="/collections/vendors?q=REDRAGON"
                                                                    title="REDRAGON">REDRAGON</a></div>
                                                            <h5 class="product-name balance-false"><a
                                                                    href="key8.php">Redragon&nbsp;K568
                                                                    DARK AVENGER RGB Backlit Mechanical Gaming Keyboard,
                                                                    87 Keys</a></h5>

                                                            <div class="product-review">

                                                                <span class="shopify-product-reviews-badge"
                                                                    data-id="5319978221719"></span>

                                                            </div>

                                                        </div>






                                                        <div class="product-price notranslate">

                                                            <span class="price">Rs. <?php $KeyboardRow = mysqli_fetch_assoc($KeyboardPricesResult); echo $KeyboardRow['Price']; ?></span>

                                                        </div>



                                                        <div class="product-list-mode-content">


                                                            

                                                            




                                                        </div>

                                                    </div>
                                                </div>

                                                <div class="product-list-mode-content-v2">
                                                    <div class="list-v2-inner">
                                                        


                                                    </div>
                                                </div>

                                            </div>


                                        </div>

                                        <div class="product-grid-item mode-view-item">







                                            <div class="product-wrapper effect-overlay ">

                                                <div class="product-head">
                                                    <div class="product-image">

                                                        <div class="featured-img product-ratio-auto">
                                                            <a
                                                                href="/collections/gaming-keyboard-price-in-pakistan/products/redragon-k585-diti-one-handed-rgb-mechanical-gaming-keyboard-k585rgb">










                                                                <span class="image-lazysize">
                                                                    <!-- noscript pattern -->
                                                                    <noscript>
                                                                        <img class="img-lazy product-ratio-auto featured-image front"
                                                                            src="//redragonzone.pk/cdn/shop/products/Redragon_K585_DITI_One-Handed_RGB_Mechanical_Gaming_Keyboard_-_K585RGB-1_420x.jpg?v=1627648640"
                                                                            alt="Redragon K585 DITI One-Handed RGB Mechanical Wired Gaming Keyboard with Blue Switches - Redragon Pakistan" />
                                                                    </noscript>

                                                                    <img class="featured-image front img-lazy blur-up auto-crop-false lazyautosizes lazyloaded"
                                                                        data-widths="[180, 320, 540, 720, 1080, 1366, 1920, 2048] "
                                                                        data-aspectratio="1.0" data-sizes="auto"
                                                                        data-parent-fit="cover"
                                                                        alt="Redragon K585 DITI One-Handed RGB Mechanical Wired Gaming Keyboard with Blue Switches - Redragon Pakistan"
                                                                        data-srcset="//redragonzone.pk/cdn/shop/products/Redragon_K585_DITI_One-Handed_RGB_Mechanical_Gaming_Keyboard_-_K585RGB-1_180x.jpg?v=1627648640 180w, //redragonzone.pk/cdn/shop/products/Redragon_K585_DITI_One-Handed_RGB_Mechanical_Gaming_Keyboard_-_K585RGB-1_320x.jpg?v=1627648640 320w, //redragonzone.pk/cdn/shop/products/Redragon_K585_DITI_One-Handed_RGB_Mechanical_Gaming_Keyboard_-_K585RGB-1_540x.jpg?v=1627648640 540w, //redragonzone.pk/cdn/shop/products/Redragon_K585_DITI_One-Handed_RGB_Mechanical_Gaming_Keyboard_-_K585RGB-1_720x.jpg?v=1627648640 720w, //redragonzone.pk/cdn/shop/products/Redragon_K585_DITI_One-Handed_RGB_Mechanical_Gaming_Keyboard_-_K585RGB-1_1080x.jpg?v=1627648640 1080w, //redragonzone.pk/cdn/shop/products/Redragon_K585_DITI_One-Handed_RGB_Mechanical_Gaming_Keyboard_-_K585RGB-1_1366x.jpg?v=1627648640 1366w, //redragonzone.pk/cdn/shop/products/Redragon_K585_DITI_One-Handed_RGB_Mechanical_Gaming_Keyboard_-_K585RGB-1_1920x.jpg?v=1627648640 1920w, //redragonzone.pk/cdn/shop/products/Redragon_K585_DITI_One-Handed_RGB_Mechanical_Gaming_Keyboard_-_K585RGB-1_2048x.jpg?v=1627648640 2048w"
                                                                        sizes="197px"
                                                                        srcset="//redragonzone.pk/cdn/shop/products/Redragon_K585_DITI_One-Handed_RGB_Mechanical_Gaming_Keyboard_-_K585RGB-1_180x.jpg?v=1627648640 180w, //redragonzone.pk/cdn/shop/products/Redragon_K585_DITI_One-Handed_RGB_Mechanical_Gaming_Keyboard_-_K585RGB-1_320x.jpg?v=1627648640 320w, //redragonzone.pk/cdn/shop/products/Redragon_K585_DITI_One-Handed_RGB_Mechanical_Gaming_Keyboard_-_K585RGB-1_540x.jpg?v=1627648640 540w, //redragonzone.pk/cdn/shop/products/Redragon_K585_DITI_One-Handed_RGB_Mechanical_Gaming_Keyboard_-_K585RGB-1_720x.jpg?v=1627648640 720w, //redragonzone.pk/cdn/shop/products/Redragon_K585_DITI_One-Handed_RGB_Mechanical_Gaming_Keyboard_-_K585RGB-1_1080x.jpg?v=1627648640 1080w, //redragonzone.pk/cdn/shop/products/Redragon_K585_DITI_One-Handed_RGB_Mechanical_Gaming_Keyboard_-_K585RGB-1_1366x.jpg?v=1627648640 1366w, //redragonzone.pk/cdn/shop/products/Redragon_K585_DITI_One-Handed_RGB_Mechanical_Gaming_Keyboard_-_K585RGB-1_1920x.jpg?v=1627648640 1920w, //redragonzone.pk/cdn/shop/products/Redragon_K585_DITI_One-Handed_RGB_Mechanical_Gaming_Keyboard_-_K585RGB-1_2048x.jpg?v=1627648640 2048w">
                                                                </span>










                                                            </a>
                                                        </div>



                                                        
                                                    </div>


                                                    

                                                </div>

                                                <div class="product-content">
                                                    <div class="pc-inner">


                                                       


                                                        <div class="product-group-vendor-name">
                                                            <div class="product-vendor"><a
                                                                    href="/collections/vendors?q=REDRAGON"
                                                                    title="REDRAGON">REDRAGON</a></div>
                                                            <h5 class="product-name balance-false"><a
                                                                    href="key9.php">Redragon
                                                                    K585 DITI One-Handed RGB Mechanical Wired Gaming
                                                                    Keyboard with Blue Switches</a></h5>

                                                            <div class="product-review">

                                                                <span class="shopify-product-reviews-badge"
                                                                    data-id="4543156453515"></span>

                                                            </div>

                                                        </div>






                                                        <div class="product-price notranslate">

                                                            <span class="price">Rs. <?php $KeyboardRow = mysqli_fetch_assoc($KeyboardPricesResult); echo $KeyboardRow['Price']; ?></span>

                                                        </div>



                                                        <div class="product-list-mode-content">


                                                           


                                                           



                                                        </div>

                                                    </div>
                                                </div>

                                                <div class="product-list-mode-content-v2">
                                                    <div class="list-v2-inner">
                                                       



                                                    </div>
                                                </div>

                                            </div>


                                        </div>

                                        <div class="product-grid-item mode-view-item">







                                            <div class="product-wrapper effect-overlay ">

                                                <div class="product-head">
                                                    <div class="product-image">

                                                        <div class="featured-img product-ratio-auto">
                                                            <a
                                                                href="/collections/gaming-keyboard-price-in-pakistan/products/redragon-kumara-white-k552-rgb-mechanical-gaming-keyboard">










                                                                <span class="image-lazysize">
                                                                    <!-- noscript pattern -->
                                                                    <noscript>
                                                                        <img class="img-lazy product-ratio-auto featured-image front"
                                                                            src="//redragonzone.pk/cdn/shop/products/617RSxX2hCL._AC_SL1500_420x.jpg?v=1628068625"
                                                                            alt="Redragon K552 KUMARA RGB Mechanical Gaming Keyboard - Redragon Pakistan" />
                                                                    </noscript>

                                                                    <img class="featured-image front img-lazy blur-up auto-crop-false lazyautosizes lazyloaded"
                                                                        data-widths="[180, 320, 540, 720, 1080, 1366, 1920, 2048] "
                                                                        data-aspectratio="1.0" data-sizes="auto"
                                                                        data-parent-fit="cover"
                                                                        alt="Redragon K552 KUMARA RGB Mechanical Gaming Keyboard - Redragon Pakistan"
                                                                        data-srcset="//redragonzone.pk/cdn/shop/products/617RSxX2hCL._AC_SL1500_180x.jpg?v=1628068625 180w, //redragonzone.pk/cdn/shop/products/617RSxX2hCL._AC_SL1500_320x.jpg?v=1628068625 320w, //redragonzone.pk/cdn/shop/products/617RSxX2hCL._AC_SL1500_540x.jpg?v=1628068625 540w, //redragonzone.pk/cdn/shop/products/617RSxX2hCL._AC_SL1500_720x.jpg?v=1628068625 720w, //redragonzone.pk/cdn/shop/products/617RSxX2hCL._AC_SL1500_1080x.jpg?v=1628068625 1080w, //redragonzone.pk/cdn/shop/products/617RSxX2hCL._AC_SL1500_1366x.jpg?v=1628068625 1366w, //redragonzone.pk/cdn/shop/products/617RSxX2hCL._AC_SL1500_1920x.jpg?v=1628068625 1920w, //redragonzone.pk/cdn/shop/products/617RSxX2hCL._AC_SL1500_2048x.jpg?v=1628068625 2048w"
                                                                        sizes="197px"
                                                                        srcset="//redragonzone.pk/cdn/shop/products/617RSxX2hCL._AC_SL1500_180x.jpg?v=1628068625 180w, //redragonzone.pk/cdn/shop/products/617RSxX2hCL._AC_SL1500_320x.jpg?v=1628068625 320w, //redragonzone.pk/cdn/shop/products/617RSxX2hCL._AC_SL1500_540x.jpg?v=1628068625 540w, //redragonzone.pk/cdn/shop/products/617RSxX2hCL._AC_SL1500_720x.jpg?v=1628068625 720w, //redragonzone.pk/cdn/shop/products/617RSxX2hCL._AC_SL1500_1080x.jpg?v=1628068625 1080w, //redragonzone.pk/cdn/shop/products/617RSxX2hCL._AC_SL1500_1366x.jpg?v=1628068625 1366w, //redragonzone.pk/cdn/shop/products/617RSxX2hCL._AC_SL1500_1920x.jpg?v=1628068625 1920w, //redragonzone.pk/cdn/shop/products/617RSxX2hCL._AC_SL1500_2048x.jpg?v=1628068625 2048w">
                                                                </span>


                                                                <span class="product-label flex">







                                                                    <span class="label-new">
                                                                        <span class="new-text">New</span>
                                                                    </span>


                                                                </span>

                                                            </a>
                                                        </div>



                                                        

                                                    </div>


                                                    

                                                </div>

                                                <div class="product-content">
                                                    <div class="pc-inner">


                                                        


                                                        <div class="product-group-vendor-name">
                                                            <div class="product-vendor"><a
                                                                    href="/collections/vendors?q=REDRAGON"
                                                                    title="REDRAGON">REDRAGON</a></div>
                                                            <h5 class="product-name balance-false"><a
                                                                    href="key10.php">Redragon
                                                                    K552 KUMARA RGB Mechanical Gaming Keyboard
                                                                    (White)</a></h5>

                                                            <div class="product-review">

                                                                <span class="shopify-product-reviews-badge"
                                                                    data-id="6907194441879"></span>

                                                            </div>

                                                        </div>






                                                        <div class="product-price notranslate">

                                                            <span class="price">Rs. <?php $KeyboardRow = mysqli_fetch_assoc($KeyboardPricesResult); echo $KeyboardRow['Price']; ?></span>

                                                        </div>



                                                        <div class="product-list-mode-content">


                                                        </div>

                                                    </div>
                                                </div>

                                                <div class="product-list-mode-content-v2">
                                                    <div class="list-v2-inner">
                                                        



                                                    </div>
                                                </div>

                                            </div>


                                        </div>

                                        <div class="product-grid-item mode-view-item">







                                            <div class="product-wrapper effect-overlay ">

                                                <div class="product-head">
                                                    <div class="product-image">

                                                        <div class="featured-img product-ratio-auto">
                                                            <a
                                                                href="/collections/gaming-keyboard-price-in-pakistan/products/redragon-k580-vata-rgb-mechanical-gaming-keyboard">


                                                                <span class="image-lazysize">
                                                                    <!-- noscript pattern -->
                                                                    <noscript>
                                                                        <img class="img-lazy product-ratio-auto featured-image front"
                                                                            src="//redragonzone.pk/cdn/shop/products/Redragon-VATA_420x.png?v=1593380288"
                                                                            alt="Redragon K580 VATA RGB Backlit Mechanical Gaming Keyboard - Redragon Pakistan" />
                                                                    </noscript>

                                                                    <img class="featured-image front img-lazy blur-up auto-crop-false lazyautosizes lazyloaded"
                                                                        data-widths="[180, 320, 540, 720, 1080, 1366, 1920, 2048] "
                                                                        data-aspectratio="1.0" data-sizes="auto"
                                                                        data-parent-fit="cover"
                                                                        alt="Redragon K580 VATA RGB Backlit Mechanical Gaming Keyboard - Redragon Pakistan"
                                                                        data-srcset="//redragonzone.pk/cdn/shop/products/Redragon-VATA_180x.png?v=1593380288 180w, //redragonzone.pk/cdn/shop/products/Redragon-VATA_320x.png?v=1593380288 320w, //redragonzone.pk/cdn/shop/products/Redragon-VATA_540x.png?v=1593380288 540w, //redragonzone.pk/cdn/shop/products/Redragon-VATA_720x.png?v=1593380288 720w, //redragonzone.pk/cdn/shop/products/Redragon-VATA_1080x.png?v=1593380288 1080w, //redragonzone.pk/cdn/shop/products/Redragon-VATA_1366x.png?v=1593380288 1366w, //redragonzone.pk/cdn/shop/products/Redragon-VATA_1920x.png?v=1593380288 1920w, //redragonzone.pk/cdn/shop/products/Redragon-VATA_2048x.png?v=1593380288 2048w"
                                                                        sizes="197px"
                                                                        srcset="//redragonzone.pk/cdn/shop/products/Redragon-VATA_180x.png?v=1593380288 180w, //redragonzone.pk/cdn/shop/products/Redragon-VATA_320x.png?v=1593380288 320w, //redragonzone.pk/cdn/shop/products/Redragon-VATA_540x.png?v=1593380288 540w, //redragonzone.pk/cdn/shop/products/Redragon-VATA_720x.png?v=1593380288 720w, //redragonzone.pk/cdn/shop/products/Redragon-VATA_1080x.png?v=1593380288 1080w, //redragonzone.pk/cdn/shop/products/Redragon-VATA_1366x.png?v=1593380288 1366w, //redragonzone.pk/cdn/shop/products/Redragon-VATA_1920x.png?v=1593380288 1920w, //redragonzone.pk/cdn/shop/products/Redragon-VATA_2048x.png?v=1593380288 2048w">
                                                                </span>














                                                                <span class="product-label flex">







                                                                    <span class="label-new">
                                                                        <span class="new-text">New</span>
                                                                    </span>


                                                                </span>

                                                            </a>
                                                        </div>



                                                        

                                                    </div>


                                                    

                                                </div>

                                                <div class="product-content">
                                                    <div class="pc-inner">


                                                        


                                                        <div class="product-group-vendor-name">
                                                            <div class="product-vendor"><a
                                                                    href="/collections/vendors?q=REDRAGON"
                                                                    title="REDRAGON">REDRAGON</a></div>
                                                            <h5 class="product-name balance-false"><a
                                                                    href="key11.php">Redragon
                                                                    K580 VATA RGB Backlit Mechanical Gaming Keyboard</a>
                                                            </h5>

                                                            <div class="product-review">

                                                                <span class="shopify-product-reviews-badge"
                                                                    data-id="5319987822743"></span>

                                                            </div>

                                                        </div>






                                                        <div class="product-price notranslate">

                                                            <span class="price">Rs. <?php $KeyboardRow = mysqli_fetch_assoc($KeyboardPricesResult); echo $KeyboardRow['Price']; ?></span>

                                                        </div>



                                                        <div class="product-list-mode-content">


                                                            


                                                            




                                                        </div>

                                                    </div>
                                                </div>

                                                <div class="product-list-mode-content-v2">
                                                    <div class="list-v2-inner">
                                                        


                                                    </div>
                                                </div>

                                            </div>


                                        </div>

                                        <div class="product-grid-item mode-view-item">







                                            <div class="product-wrapper effect-overlay ">

                                                <div class="product-head">
                                                    <div class="product-image">

                                                        <div class="featured-img product-ratio-auto">
                                                            <a
                                                                href="/collections/gaming-keyboard-price-in-pakistan/products/redragon-k589-shrapnel-rgb-mechanical-gaming-keyboard">










                                                                <span class="image-lazysize">
                                                                    <!-- noscript pattern -->
                                                                    <noscript>
                                                                        <img class="img-lazy product-ratio-auto featured-image front"
                                                                            src="//redragonzone.pk/cdn/shop/products/K589-1_450x450_d72c1f2a-2548-405c-a178-4deb9df7ea6e_420x.png?v=1635933625"
                                                                            alt="Redragon K589 SHRAPNEL RGB Backlit Mechanical Gaming Keyboard 104 Keys Anti ghosting Red Switches - Redragon Pakistan" />
                                                                    </noscript>

                                                                    <img class="featured-image front img-lazy blur-up auto-crop-false lazyautosizes lazyloaded"
                                                                        data-widths="[180, 320, 540, 720, 1080, 1366, 1920, 2048] "
                                                                        data-aspectratio="1.0" data-sizes="auto"
                                                                        data-parent-fit="cover"
                                                                        alt="Redragon K589 SHRAPNEL RGB Backlit Mechanical Gaming Keyboard 104 Keys Anti ghosting Red Switches - Redragon Pakistan"
                                                                        data-srcset="//redragonzone.pk/cdn/shop/products/K589-1_450x450_d72c1f2a-2548-405c-a178-4deb9df7ea6e_180x.png?v=1635933625 180w, //redragonzone.pk/cdn/shop/products/K589-1_450x450_d72c1f2a-2548-405c-a178-4deb9df7ea6e_320x.png?v=1635933625 320w, //redragonzone.pk/cdn/shop/products/K589-1_450x450_d72c1f2a-2548-405c-a178-4deb9df7ea6e_540x.png?v=1635933625 540w, //redragonzone.pk/cdn/shop/products/K589-1_450x450_d72c1f2a-2548-405c-a178-4deb9df7ea6e_720x.png?v=1635933625 720w, //redragonzone.pk/cdn/shop/products/K589-1_450x450_d72c1f2a-2548-405c-a178-4deb9df7ea6e_1080x.png?v=1635933625 1080w, //redragonzone.pk/cdn/shop/products/K589-1_450x450_d72c1f2a-2548-405c-a178-4deb9df7ea6e_1366x.png?v=1635933625 1366w, //redragonzone.pk/cdn/shop/products/K589-1_450x450_d72c1f2a-2548-405c-a178-4deb9df7ea6e_1920x.png?v=1635933625 1920w, //redragonzone.pk/cdn/shop/products/K589-1_450x450_d72c1f2a-2548-405c-a178-4deb9df7ea6e_2048x.png?v=1635933625 2048w"
                                                                        sizes="197px"
                                                                        srcset="//redragonzone.pk/cdn/shop/products/K589-1_450x450_d72c1f2a-2548-405c-a178-4deb9df7ea6e_180x.png?v=1635933625 180w, //redragonzone.pk/cdn/shop/products/K589-1_450x450_d72c1f2a-2548-405c-a178-4deb9df7ea6e_320x.png?v=1635933625 320w, //redragonzone.pk/cdn/shop/products/K589-1_450x450_d72c1f2a-2548-405c-a178-4deb9df7ea6e_540x.png?v=1635933625 540w, //redragonzone.pk/cdn/shop/products/K589-1_450x450_d72c1f2a-2548-405c-a178-4deb9df7ea6e_720x.png?v=1635933625 720w, //redragonzone.pk/cdn/shop/products/K589-1_450x450_d72c1f2a-2548-405c-a178-4deb9df7ea6e_1080x.png?v=1635933625 1080w, //redragonzone.pk/cdn/shop/products/K589-1_450x450_d72c1f2a-2548-405c-a178-4deb9df7ea6e_1366x.png?v=1635933625 1366w, //redragonzone.pk/cdn/shop/products/K589-1_450x450_d72c1f2a-2548-405c-a178-4deb9df7ea6e_1920x.png?v=1635933625 1920w, //redragonzone.pk/cdn/shop/products/K589-1_450x450_d72c1f2a-2548-405c-a178-4deb9df7ea6e_2048x.png?v=1635933625 2048w">
                                                                </span>














                                                                <span class="product-label flex">







                                                                    <span class="label-new">
                                                                        <span class="new-text">New</span>
                                                                    </span>



                                                                </span>

                                                            </a>
                                                        </div>



                                                        

                                                    </div>


                                                    

                                                </div>

                                                <div class="product-content">
                                                    <div class="pc-inner">


                                                        


                                                        <div class="product-group-vendor-name">
                                                            <div class="product-vendor"><a
                                                                    href="/collections/vendors?q=REDRAGON"
                                                                    title="REDRAGON">REDRAGON</a></div>
                                                            <h5 class="product-name balance-false"><a
                                                                    href="key12.php">Redragon
                                                                    K589 SHRAPNEL RGB Backlit Mechanical Gaming Keyboard
                                                                    104 Keys Anti-ghosting Red Switches</a></h5>

                                                            <div class="product-review">

                                                                <span class="shopify-product-reviews-badge"
                                                                    data-id="6474018750615"></span>

                                                            </div>

                                                        </div>






                                                        <div class="product-price notranslate">

                                                            <span class="price">Rs. <?php $KeyboardRow = mysqli_fetch_assoc($KeyboardPricesResult); echo $KeyboardRow['Price']; ?></span>

                                                        </div>



                                                        <div class="product-list-mode-content">


                                                            

                                                            




                                                        </div>

                                                    </div>
                                                </div>

                                                <div class="product-list-mode-content-v2">
                                                    <div class="list-v2-inner">
                                                        



                                                    </div>
                                                </div>

                                            </div>


                                        </div>

                                        <div class="product-grid-item mode-view-item">







                                            <div class="product-wrapper effect-overlay ">

                                                <div class="product-head">
                                                    <div class="product-image">

                                                        <div class="featured-img product-ratio-auto">
                                                            <a
                                                                href="/collections/gaming-keyboard-price-in-pakistan/products/redragon-k621-horus-tkl-wireless-rgb-mechanical-gaming-keyboard-5-0-bt2-4-ghzwired-3-modes-80-ultra-thin-low-profile-bluetooth-keyboard-wdedicated-media-control-linear-red-switches">










                                                                <span class="image-lazysize">
                                                                    <!-- noscript pattern -->
                                                                    <noscript>
                                                                        <img class="img-lazy product-ratio-auto featured-image front"
                                                                            src="//redragonzone.pk/cdn/shop/products/redragonk621tklwirelesslowprofilekeyboard_450x450_72fa7f18-438d-4662-884c-116451275b46_420x.png?v=1646981159"
                                                                            alt="Redragon K621 HORUS TKL RGB Wireless Mechanical Gaming Keyboard - Redragon Pakistan" />
                                                                    </noscript>

                                                                    <img class="featured-image front img-lazy blur-up auto-crop-false lazyautosizes lazyloaded"
                                                                        data-widths="[180, 320, 540, 720, 1080, 1366, 1920, 2048] "
                                                                        data-aspectratio="1.0" data-sizes="auto"
                                                                        data-parent-fit="cover"
                                                                        alt="Redragon K621 HORUS TKL RGB Wireless Mechanical Gaming Keyboard - Redragon Pakistan"
                                                                        data-srcset="//redragonzone.pk/cdn/shop/products/redragonk621tklwirelesslowprofilekeyboard_450x450_72fa7f18-438d-4662-884c-116451275b46_180x.png?v=1646981159 180w, //redragonzone.pk/cdn/shop/products/redragonk621tklwirelesslowprofilekeyboard_450x450_72fa7f18-438d-4662-884c-116451275b46_320x.png?v=1646981159 320w, //redragonzone.pk/cdn/shop/products/redragonk621tklwirelesslowprofilekeyboard_450x450_72fa7f18-438d-4662-884c-116451275b46_540x.png?v=1646981159 540w, //redragonzone.pk/cdn/shop/products/redragonk621tklwirelesslowprofilekeyboard_450x450_72fa7f18-438d-4662-884c-116451275b46_720x.png?v=1646981159 720w, //redragonzone.pk/cdn/shop/products/redragonk621tklwirelesslowprofilekeyboard_450x450_72fa7f18-438d-4662-884c-116451275b46_1080x.png?v=1646981159 1080w, //redragonzone.pk/cdn/shop/products/redragonk621tklwirelesslowprofilekeyboard_450x450_72fa7f18-438d-4662-884c-116451275b46_1366x.png?v=1646981159 1366w, //redragonzone.pk/cdn/shop/products/redragonk621tklwirelesslowprofilekeyboard_450x450_72fa7f18-438d-4662-884c-116451275b46_1920x.png?v=1646981159 1920w, //redragonzone.pk/cdn/shop/products/redragonk621tklwirelesslowprofilekeyboard_450x450_72fa7f18-438d-4662-884c-116451275b46_2048x.png?v=1646981159 2048w"
                                                                        sizes="197px"
                                                                        srcset="//redragonzone.pk/cdn/shop/products/redragonk621tklwirelesslowprofilekeyboard_450x450_72fa7f18-438d-4662-884c-116451275b46_180x.png?v=1646981159 180w, //redragonzone.pk/cdn/shop/products/redragonk621tklwirelesslowprofilekeyboard_450x450_72fa7f18-438d-4662-884c-116451275b46_320x.png?v=1646981159 320w, //redragonzone.pk/cdn/shop/products/redragonk621tklwirelesslowprofilekeyboard_450x450_72fa7f18-438d-4662-884c-116451275b46_540x.png?v=1646981159 540w, //redragonzone.pk/cdn/shop/products/redragonk621tklwirelesslowprofilekeyboard_450x450_72fa7f18-438d-4662-884c-116451275b46_720x.png?v=1646981159 720w, //redragonzone.pk/cdn/shop/products/redragonk621tklwirelesslowprofilekeyboard_450x450_72fa7f18-438d-4662-884c-116451275b46_1080x.png?v=1646981159 1080w, //redragonzone.pk/cdn/shop/products/redragonk621tklwirelesslowprofilekeyboard_450x450_72fa7f18-438d-4662-884c-116451275b46_1366x.png?v=1646981159 1366w, //redragonzone.pk/cdn/shop/products/redragonk621tklwirelesslowprofilekeyboard_450x450_72fa7f18-438d-4662-884c-116451275b46_1920x.png?v=1646981159 1920w, //redragonzone.pk/cdn/shop/products/redragonk621tklwirelesslowprofilekeyboard_450x450_72fa7f18-438d-4662-884c-116451275b46_2048x.png?v=1646981159 2048w">
                                                                </span>














                                                                <span class="product-label flex">



                                                                    <span class="label-new">
                                                                        <span class="new-text">New</span>
                                                                    </span>



                                                                </span>

                                                            </a>
                                                        </div>



                                                       

                                                    </div>


                                                    

                                                </div>

                                                <div class="product-content">
                                                    <div class="pc-inner">


                                                        

                                                        <div class="product-group-vendor-name">
                                                            <div class="product-vendor"><a
                                                                    href="/collections/vendors?q=REDRAGON"
                                                                    title="REDRAGON">REDRAGON</a></div>
                                                            <h5 class="product-name balance-false"><a
                                                                    href="key13.php">Redragon
                                                                    K621 HORUS TKL RGB Wireless Mechanical Gaming
                                                                    Keyboard</a></h5>

                                                            <div class="product-review">

                                                                <span class="shopify-product-reviews-badge"
                                                                    data-id="7468302860439"></span>

                                                            </div>

                                                        </div>






                                                        <div class="product-price notranslate">

                                                            <span class="price">Rs. <?php $KeyboardRow = mysqli_fetch_assoc($KeyboardPricesResult); echo $KeyboardRow['Price']; ?></span>

                                                        </div>



                                                        <div class="product-list-mode-content">


                                                        </div>

                                                    </div>
                                                </div>

                                                <div class="product-list-mode-content-v2">
                                                    <div class="list-v2-inner">
                                                        



                                                    </div>
                                                </div>

                                            </div>


                                        </div>

                                        <div class="product-grid-item mode-view-item">







                                            <div class="product-wrapper effect-overlay ">

                                                <div class="product-head">
                                                    <div class="product-image">

                                                        <div class="featured-img product-ratio-auto">
                                                            <a
                                                                href="/collections/gaming-keyboard-price-in-pakistan/products/redragon-k596-vishnu-2-4g-wireless-wired-rgb-mechanical-gaming-keyboard">



                                                                <span class="image-lazysize">
                                                                    <!-- noscript pattern -->
                                                                    <noscript>
                                                                        <img class="img-lazy product-ratio-auto featured-image front"
                                                                            src="//redragonzone.pk/cdn/shop/products/K596RGB-1_450x450_0b19fdb0-278a-4916-921b-c3cb6411181b_420x.png?v=1627721925"
                                                                            alt="Redragon K596 VISHNU RGB Wireless Mechanical Gaming Keyboard, 87 Keys TKL - Redragon Pakistan" />
                                                                    </noscript>

                                                                    <img class="featured-image front img-lazy blur-up auto-crop-false lazyautosizes lazyloaded"
                                                                        data-widths="[180, 320, 540, 720, 1080, 1366, 1920, 2048] "
                                                                        data-aspectratio="1.0" data-sizes="auto"
                                                                        data-parent-fit="cover"
                                                                        alt="Redragon K596 VISHNU RGB Wireless Mechanical Gaming Keyboard, 87 Keys TKL - Redragon Pakistan"
                                                                        data-srcset="//redragonzone.pk/cdn/shop/products/K596RGB-1_450x450_0b19fdb0-278a-4916-921b-c3cb6411181b_180x.png?v=1627721925 180w, //redragonzone.pk/cdn/shop/products/K596RGB-1_450x450_0b19fdb0-278a-4916-921b-c3cb6411181b_320x.png?v=1627721925 320w, //redragonzone.pk/cdn/shop/products/K596RGB-1_450x450_0b19fdb0-278a-4916-921b-c3cb6411181b_540x.png?v=1627721925 540w, //redragonzone.pk/cdn/shop/products/K596RGB-1_450x450_0b19fdb0-278a-4916-921b-c3cb6411181b_720x.png?v=1627721925 720w, //redragonzone.pk/cdn/shop/products/K596RGB-1_450x450_0b19fdb0-278a-4916-921b-c3cb6411181b_1080x.png?v=1627721925 1080w, //redragonzone.pk/cdn/shop/products/K596RGB-1_450x450_0b19fdb0-278a-4916-921b-c3cb6411181b_1366x.png?v=1627721925 1366w, //redragonzone.pk/cdn/shop/products/K596RGB-1_450x450_0b19fdb0-278a-4916-921b-c3cb6411181b_1920x.png?v=1627721925 1920w, //redragonzone.pk/cdn/shop/products/K596RGB-1_450x450_0b19fdb0-278a-4916-921b-c3cb6411181b_2048x.png?v=1627721925 2048w"
                                                                        sizes="197px"
                                                                        srcset="//redragonzone.pk/cdn/shop/products/K596RGB-1_450x450_0b19fdb0-278a-4916-921b-c3cb6411181b_180x.png?v=1627721925 180w, //redragonzone.pk/cdn/shop/products/K596RGB-1_450x450_0b19fdb0-278a-4916-921b-c3cb6411181b_320x.png?v=1627721925 320w, //redragonzone.pk/cdn/shop/products/K596RGB-1_450x450_0b19fdb0-278a-4916-921b-c3cb6411181b_540x.png?v=1627721925 540w, //redragonzone.pk/cdn/shop/products/K596RGB-1_450x450_0b19fdb0-278a-4916-921b-c3cb6411181b_720x.png?v=1627721925 720w, //redragonzone.pk/cdn/shop/products/K596RGB-1_450x450_0b19fdb0-278a-4916-921b-c3cb6411181b_1080x.png?v=1627721925 1080w, //redragonzone.pk/cdn/shop/products/K596RGB-1_450x450_0b19fdb0-278a-4916-921b-c3cb6411181b_1366x.png?v=1627721925 1366w, //redragonzone.pk/cdn/shop/products/K596RGB-1_450x450_0b19fdb0-278a-4916-921b-c3cb6411181b_1920x.png?v=1627721925 1920w, //redragonzone.pk/cdn/shop/products/K596RGB-1_450x450_0b19fdb0-278a-4916-921b-c3cb6411181b_2048x.png?v=1627721925 2048w">
                                                                </span>





                                                                <span class="product-label flex">







                                                                    <span class="label-new">
                                                                        <span class="new-text">New</span>
                                                                    </span>


                                                                </span>

                                                            </a>
                                                        </div>



                                                

                                                    </div>


                                                </div>

                                                <div class="product-content">
                                                    <div class="pc-inner">



                                                        <div class="product-group-vendor-name">
                                                            <div class="product-vendor"><a
                                                                    href="/collections/vendors?q=REDRAGON"
                                                                    title="REDRAGON">REDRAGON</a></div>
                                                            <h5 class="product-name balance-false"><a
                                                                    href="key14.php">Redragon
                                                                    K596 VISHNU RGB Wireless Mechanical Gaming Keyboard,
                                                                    87 Keys TKL</a></h5>

                                                            <div class="product-review">

                                                                <span class="shopify-product-reviews-badge"
                                                                    data-id="6969483559063"></span>

                                                            </div>

                                                        </div>




                                                        <div class="product-price notranslate">

                                                            <span class="price">Rs. <?php $KeyboardRow = mysqli_fetch_assoc($KeyboardPricesResult); echo $KeyboardRow['Price']; ?></span>

                                                        </div>



                                                        
                                                    </div>
                                                </div>

                                                
                                            </div>


                                        </div>

                                        <div class="product-grid-item mode-view-item">



                                            <div class="product-wrapper effect-overlay ">

                                                <div class="product-head">
                                                    <div class="product-image">

                                                        <div class="featured-img product-ratio-auto">
                                                            <a
                                                                href="/collections/gaming-keyboard-price-in-pakistan/products/redragon-k616-fizz-pro-black-rgb-usb-bluetooth-wireless-gaming-keyboard">


                                                                <span class="image-lazysize">
                                                                    <!-- noscript pattern -->
                                                                    <noscript>
                                                                        <img class="img-lazy product-ratio-auto featured-image front"
                                                                            src="//redragonzone.pk/cdn/shop/products/redragon-fizz-pro-k616-2-1_420x.jpg?v=1635936431"
                                                                            alt="Redragon K616 FIZZ PRO RGB Mechanical Gaming Keyboard - Redragon Pakistan" />
                                                                    </noscript>

                                                                    <img class="featured-image front img-lazy blur-up auto-crop-false lazyautosizes lazyloaded"
                                                                        data-widths="[180, 320, 540, 720, 1080, 1366, 1920, 2048] "
                                                                        data-aspectratio="1.0" data-sizes="auto"
                                                                        data-parent-fit="cover"
                                                                        alt="Redragon K616 FIZZ PRO RGB Mechanical Gaming Keyboard - Redragon Pakistan"
                                                                        data-srcset="//redragonzone.pk/cdn/shop/products/redragon-fizz-pro-k616-2-1_180x.jpg?v=1635936431 180w, //redragonzone.pk/cdn/shop/products/redragon-fizz-pro-k616-2-1_320x.jpg?v=1635936431 320w, //redragonzone.pk/cdn/shop/products/redragon-fizz-pro-k616-2-1_540x.jpg?v=1635936431 540w, //redragonzone.pk/cdn/shop/products/redragon-fizz-pro-k616-2-1_720x.jpg?v=1635936431 720w, //redragonzone.pk/cdn/shop/products/redragon-fizz-pro-k616-2-1_1080x.jpg?v=1635936431 1080w, //redragonzone.pk/cdn/shop/products/redragon-fizz-pro-k616-2-1_1366x.jpg?v=1635936431 1366w, //redragonzone.pk/cdn/shop/products/redragon-fizz-pro-k616-2-1_1920x.jpg?v=1635936431 1920w, //redragonzone.pk/cdn/shop/products/redragon-fizz-pro-k616-2-1_2048x.jpg?v=1635936431 2048w"
                                                                        sizes="197px"
                                                                        srcset="//redragonzone.pk/cdn/shop/products/redragon-fizz-pro-k616-2-1_180x.jpg?v=1635936431 180w, //redragonzone.pk/cdn/shop/products/redragon-fizz-pro-k616-2-1_320x.jpg?v=1635936431 320w, //redragonzone.pk/cdn/shop/products/redragon-fizz-pro-k616-2-1_540x.jpg?v=1635936431 540w, //redragonzone.pk/cdn/shop/products/redragon-fizz-pro-k616-2-1_720x.jpg?v=1635936431 720w, //redragonzone.pk/cdn/shop/products/redragon-fizz-pro-k616-2-1_1080x.jpg?v=1635936431 1080w, //redragonzone.pk/cdn/shop/products/redragon-fizz-pro-k616-2-1_1366x.jpg?v=1635936431 1366w, //redragonzone.pk/cdn/shop/products/redragon-fizz-pro-k616-2-1_1920x.jpg?v=1635936431 1920w, //redragonzone.pk/cdn/shop/products/redragon-fizz-pro-k616-2-1_2048x.jpg?v=1635936431 2048w">
                                                                </span>


                                                                <span class="product-label flex">

                                                                    <span class="label-new">
                                                                        <span class="new-text">New</span>
                                                                    </span>

                                                                </span>

                                                            </a>
                                                        </div>


                                                    </div>

                                                </div>

                                                <div class="product-content">
                                                    <div class="pc-inner">


                                                        <div class="product-group-vendor-name">
                                                            <div class="product-vendor"><a
                                                                    href="/collections/vendors?q=REDRAGON"
                                                                    title="REDRAGON">REDRAGON</a></div>
                                                            <h5 class="product-name balance-false"><a
                                                                    href="key15.php">Redragon
                                                                    K616 FIZZ PRO RGB Mechanical Gaming Keyboard
                                                                    (Black)</a></h5>

                                                            <div class="product-review">

                                                                <span class="shopify-product-reviews-badge"
                                                                    data-id="7253489516695"></span>

                                                            </div>

                                                        </div>






                                                        <div class="product-price notranslate">

                                                            <span class="price">Rs. <?php $KeyboardRow = mysqli_fetch_assoc($KeyboardPricesResult); echo $KeyboardRow['Price']; ?></span>

                                                        </div>



                                                       

                                                    </div>
                                                </div>


                                            </div>


                                        </div>

                                        <div class="product-grid-item mode-view-item">


                                            <div class="product-wrapper effect-overlay ">

                                                <div class="product-head">
                                                    <div class="product-image">

                                                        <div class="featured-img product-ratio-auto">
                                                            <a
                                                                href="/collections/gaming-keyboard-price-in-pakistan/products/redragon-kala-rgb-mechanical-gaming-keyboard-k557">

                                                                <span class="image-lazysize">
                                                                    <!-- noscript pattern -->
                                                                    <noscript>
                                                                        <img class="img-lazy product-ratio-auto featured-image front"
                                                                            src="//redragonzone.pk/cdn/shop/products/Untitled-removebg-preview_420x.png?v=1628008750"
                                                                            alt="Redragon K557 KALA RGB Backlit Waterproof Mechanical Gaming Keyboard - Redragon Pakistan" />
                                                                    </noscript>

                                                                    <img class="featured-image front img-lazy blur-up auto-crop-false lazyautosizes lazyloaded"
                                                                        data-widths="[180, 320, 540, 720, 1080, 1366, 1920, 2048] "
                                                                        data-aspectratio="1.0" data-sizes="auto"
                                                                        data-parent-fit="cover"
                                                                        alt="Redragon K557 KALA RGB Backlit Waterproof Mechanical Gaming Keyboard - Redragon Pakistan"
                                                                        data-srcset="//redragonzone.pk/cdn/shop/products/Untitled-removebg-preview_180x.png?v=1628008750 180w, //redragonzone.pk/cdn/shop/products/Untitled-removebg-preview_320x.png?v=1628008750 320w, //redragonzone.pk/cdn/shop/products/Untitled-removebg-preview_540x.png?v=1628008750 540w, //redragonzone.pk/cdn/shop/products/Untitled-removebg-preview_720x.png?v=1628008750 720w, //redragonzone.pk/cdn/shop/products/Untitled-removebg-preview_1080x.png?v=1628008750 1080w, //redragonzone.pk/cdn/shop/products/Untitled-removebg-preview_1366x.png?v=1628008750 1366w, //redragonzone.pk/cdn/shop/products/Untitled-removebg-preview_1920x.png?v=1628008750 1920w, //redragonzone.pk/cdn/shop/products/Untitled-removebg-preview_2048x.png?v=1628008750 2048w"
                                                                        sizes="197px"
                                                                        srcset="//redragonzone.pk/cdn/shop/products/Untitled-removebg-preview_180x.png?v=1628008750 180w, //redragonzone.pk/cdn/shop/products/Untitled-removebg-preview_320x.png?v=1628008750 320w, //redragonzone.pk/cdn/shop/products/Untitled-removebg-preview_540x.png?v=1628008750 540w, //redragonzone.pk/cdn/shop/products/Untitled-removebg-preview_720x.png?v=1628008750 720w, //redragonzone.pk/cdn/shop/products/Untitled-removebg-preview_1080x.png?v=1628008750 1080w, //redragonzone.pk/cdn/shop/products/Untitled-removebg-preview_1366x.png?v=1628008750 1366w, //redragonzone.pk/cdn/shop/products/Untitled-removebg-preview_1920x.png?v=1628008750 1920w, //redragonzone.pk/cdn/shop/products/Untitled-removebg-preview_2048x.png?v=1628008750 2048w">
                                                                </span>

                                                                <span class="product-label flex">
                                                                    <span class="label-new">
                                                                        <span class="new-text">New</span>
                                                                    </span>

                                                                </span>

                                                            </a>
                                                        </div>

                                                    </div>


                                                </div>

                                                <div class="product-content">
                                                    <div class="pc-inner">


                                                        <div class="product-group-vendor-name">
                                                            <div class="product-vendor"><a
                                                                    href="/collections/vendors?q=REDRAGON"
                                                                    title="REDRAGON">REDRAGON</a></div>
                                                            <h5 class="product-name balance-false"><a
                                                                    href="key16.php">Redragon
                                                                    K557 KALA RGB Backlit Waterproof Mechanical Gaming
                                                                    Keyboard</a></h5>

                                                            <div class="product-review">

                                                                <span class="shopify-product-reviews-badge"
                                                                    data-id="5319962525847"></span>

                                                            </div>

                                                        </div>

                                                        <div class="product-price notranslate">

                                                            <span class="price">Rs. <?php $KeyboardRow = mysqli_fetch_assoc($KeyboardPricesResult); echo $KeyboardRow['Price']; ?></span>

                                                        </div>



                                                        

                                                    </div>
                                                </div>

                                                
                                            </div>


                                        </div>



                                    </div>


                                </div>

<!--------------------------------------------------------------------------------------------------------------->
                            </div>
                            <div style="margin-bottom: 90px;"></div>
                        </div>
                    </div>
                </div>
            </div>
            <!-------------------------------main e---------------------------->
        </div>
    </div>
    </div>

    <!-- footer -->
    <footer>
        <div class="d-flex flex-wrap p-3 box6">
            <div class="flex-fill">
                <p>INFO@REDRAGONZONE.PK</p>
                <div class="top">
                    <a href="index.php"><img src="picc/redragon.png" width="210px" height="190px" alt=""></a>
                </div>
                <p>CUSTOMER CARE CENTER</p>
                <p>314 - AL-HAFEEZ SHOPPING MALL, GULBERG III,<br>
                    MAIN BOULEVARD, LAHORE - PAKISTAN</p>
                <p>(+92) 3111 000 135</p>
            </div>
            <div class="flex-fill">
                <p>PRODUCTS</p>
                <ul>
                    <a href="keyboard.php">
                        <li>KEYBOARD</li>
                    </a>

                    <a href="mouse.php">
                        <li>MOUSE</li>
                    </a>

                    <a href="combo.php">
                        <li>COMBO</li>
                    </a>

                    <a href="mousepad.php">
                        <li>MOUSE PAD</li>
                    </a>

                    <a href="headset.php">
                        <li>HEADSET</li>
                    </a>

                    <a href="stand1.php">
                        <li>ACCESSORIES</li>
                    </a>

                </ul>
            </div>

            <div class="flex-fill">
                <p> INFORMATION</p>
                <ul>
                    <li> <a href="Warranty.php">WARRANTY POLICY</a></li>
                    <li> <a href="payment.php">PAYMENT INFO</a></li>
                    <li> <a href="return.php">RETURN POLICY</a></li>
                </ul>

            </div>

            <div>
                <p>JOIN FOR EXCLUSIVE BENEFITS</p>
                <form action="/action_page.php">
                    <div class="d-flex box7">

                        <input type="email" class="form-control" id="email" placeholder="Your email address"
                            name="email">

                        <button type="submit" class="btn btn-danger ">Submit</button>
                    </div>
                </form>
            </div>

        </div>
    </footer>
</body>

</html>