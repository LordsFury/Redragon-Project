<?php include("Connection.php");

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <title>Redragon-checkout</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="icon" href="picc/redragon.png" type="image/x-icon">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href="smile.css">
</head>

<body>
  <header class="ch-head p-1">
    <img src="picc//redragon.png" width="130px" height="90px" alt="redragon">
  </header>
  <hr style="color:#8b8989;">
  <main class="ch-main">
    <div class="d-flex justify-content-between p-3 ch-box">
      <div>
        <h2>Contact</h2>
      </div>
    </div>

    <form method="post" action="CheckoutInformation.php">
      <div class="mb-3 mt-3">
        <input type="email" class="form-control" id="email" placeholder="Enter email" name="email" required>
      </div>
      <div class="form-check">
        <input class="form-check-input" type="checkbox" id="check1" name="news" value="something" checked>
        <label class="form-check-label">Email me with news and offers</label>
      </div>
      <br>
      <h2>Delivery</h2>
      <label for="country">Choose a country:</label>
      <select class="form-select" name="select" required>
        <option>Pakistan</option>
      </select>
      <br>
      <div class="row">
        <div class="col">
          <input type="text" class="form-control" placeholder="First name" name="first_name" required>
        </div>
        <div class="col">
          <input type="text" class="form-control" placeholder="Last name" name="last_name" required>
        </div>
      </div>
      <br>
      <input type="text" class="form-control" id="Company" placeholder="Company(optional)" name="Company">
      <br>
      <input type="text" class="form-control" id="Address" placeholder="Address" name="Address" required>
      <br>
      <div class="row">
        <div class="col">
          <input type="text" class="form-control" placeholder="City" name="city" required>
        </div>
        <div class="col">
          <input type="text" class="form-control" placeholder="Province" name="province" required>
        </div>
      </div>
      <br>
      <input type="tel" class="form-control" id="phoneno" placeholder="phoneno" name="phoneno" pattern="[0]{1}[0-5]{3}[0-9]{7}" required>
      <br>
      <input type="text" class="form-control" id="Shipping method" placeholder="Express delievery" name="Ship_meth" disabled>
      <br>
      <h2>Payment</h2>
      <p>All transactions are secure and encrypted.</p>

      <select class="form-select" required>
        <option>Cash on Delivery</option>
      </select>
      <br>
      <h3>Billing address</h3>
      <div class="form-check">
        <input type="radio" class="form-check-input" id="same" name="address_type" value="same" checked>
        <label class="form-check-label" for="same">Same as shipping address</label><br>
        <input type="radio" class="form-check-input" id="billing" name="address_type" value="billing">
        <label class="form-check-label" for="billing">Use a different billing address</label>
      </div>
      <br>
      <h2>Alternate Billing</h2>
      <label for="altcountry">Choose a country:</label>
      <select class="form-select" name="altselect" required>
        <option>Pakistan</option>
      </select>
      <br>
      <div class="row">
        <div class="col">
          <input type="text" class="form-control" placeholder="First name" name="altfirst_name">
        </div>
        <div class="col">
          <input type="text" class="form-control" placeholder="Last name" name="altlast_name">
        </div>
      </div>
      <br>
      <input type="text" class="form-control" id="altCompany" placeholder="Company(optional)" name="altCompany">
      <br>
      <input type="text" class="form-control" id="altAddress" placeholder="Address" name="altAddress">
      <br>
      <div class="row">
        <div class="col">
          <input type="text" class="form-control" placeholder="City" name="altcity">
        </div>
        <div class="col">
          <input type="text" class="form-control" placeholder="Province" name="altprovince">
        </div>
      </div>
      <br>
      <input type="tel" class="form-control" id="altphoneno" placeholder="phoneno" name="altphoneno" pattern="[0]{1}[0-5]{3}[0-9]{7}">
      <br>

      <br>
      <button type="submit" class="btn btn-danger con4">
        Complete order
      </button>
    </form>


  </main>
</body>

</html>