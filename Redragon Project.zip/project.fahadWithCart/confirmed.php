<!DOCTYPE html>
<html lang="en">
<head>
  <title>Redragon-confirmation</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="icon" href="picc/redragon.png" type="image/x-icon">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href="smile.css">
</head>
<body>
    <header class="ch-head ">
    <img src="picc//redragon.png" width="170px" height="120px" alt="redragon">
    </header>
    <hr  style="color:#8b8989;">
    <main>
        <div class="d-flex  justify-content-center flex-wrap confirm">  

        <div class=" confirm1">
            <div class="d-flex">
            <div class="check">
                <svg xmlns="http://www.w3.org/2000/svg" width="27" height="27" fill="currentColor" class="bi bi-check-circle" viewBox="0 0 16 16">
                    <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14m0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16"/>
                    <path d="M10.97 4.97a.235.235 0 0 0-.02.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-1.071-1.05"/>
                  </svg>
            </div>
            <div>
                <p>Order </p>
                <h2>Thank you,Fahad!</h2>
           
            </div>
        </div>

        <div class="con1 p-2">
            <h2>Your order is confirmed</h2>
            <p>You@ll receive a confirmation email with your order no shortly.</p>
        </div>
<br>
<div class="d-flex con2 p-2">
 
<div>
    <h2>Order details</h2>
    <p>Contact information</p>
    <p>fahad@gmail.com</p>
    <br>
    <h3>Shipping address</h3>
    <p>Fahad Zia</p>
    <p>House#123,Street 3,gulberg</p>
    <p>Islamabad</p>
    <p>Pakistan</p>
    <p>03336798765</p>
    <br>
    <h2>Shipping method</h2>
    <p>Delievery charges</p>
</div>

<div class="con3">
    <h2>
        Payment method
    </h2>
    <p>Cash on delievery (COD)</p>
    <h3>Billing address</h3>
    <p>Fahad Zia</p>
    <p>House#123,Street 3,gulberg</p>
    <p>Islamabad</p>
    <p>Pakistan</p>
    <p>03336798765</p>
    <br>
</div>
</div>
<br>

<div class="d-flex justify-content-between">
    <div>
<p>Need help?Contact us</p>
</div>
<div class="con4">
    <button type="button" class="btn btn-danger "><a href="/">Continue shopping</a>
    </button>
</div>
</div>
        </div>   

        <div class="confirm2">
            <h2 class="p-4">Your cart</h2>
            <div class="d-flex justify-content-between p-2 con5">
             
                <div>
                    <h2>
                        Product
                    </h2>

                    <div class="d-flex ">
                        <div>           
             <a href=""><img src="picc/keyboard.webp" width="100" height="90" alt="">  </a>
                        </div>
                        <div class="p-4">      
                              <p>keyboard type</p>
                         </div>
                    </div>
                </div>


                <div>
                    <h2>Price</h2>
                    <p>2500</p>
                </div>
                <div>
                   <h2>Quantity</h2>
                   <p>2</p>
                </div>
        </div>

        <br>
        
        <div class="d-flex justify-content-between p-2 con5">
             
            <div>
                <h2>
                    Product
                </h2>

                <div class="d-flex ">
                    <div>           
         <a href=""><img src="picc/keyboard.webp" width="100" height="90" alt="">  </a>
                    </div>
                    <div class="p-4">      
                          <p>keyboard type</p>
                     </div>
                </div>
            </div>


            <div>
                <h2>Price</h2>
                <p>2500</p>
            </div>
            <div>
               <h2>Quantity</h2>
               <p>2</p>
            </div>
    </div>
        </div>

        </div>
    </main>
    </body>
    </html>