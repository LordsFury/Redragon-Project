<?php include("Connection.php");
if(isset($_SESSION['Finalstand1'])){
    echo $_SESSION['Finalstand1'];
}

?>