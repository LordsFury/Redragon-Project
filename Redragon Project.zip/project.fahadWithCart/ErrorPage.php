<?php include("db_connection.php");

?>
<!-- -------------------1---------------- -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="./same.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        table,thead,tr{
            border: 2px solid black;
        }
        
    </style>
</head>
<header class="ch-head p-1">
    <img src="redragon.png" width="130px" height="90px" alt="redragon">
    </header>
    <hr  style="color:#8b8989;">
    <main>
    <h1>ADMIN LOGIN</h1>
    <div>
        <div>
            <P>Username or Password Incorrect.</P>
        </div>
        <br>
        <br>
        <a href="AdminLogin.php" class="btn btn-danger con4">RETURN TO LOGIN PAGE!</a>

    </div>
    </main>
    <footer class='f'>
        <p>ALL RIGHTS RESERVED.</p>
    </footer>


</html>